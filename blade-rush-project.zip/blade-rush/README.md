# Blade Rush
Real-time 1v1 top-down arena duels (90 s, first to 100 energy), authoritative server, double-entry wallet, mobile-first client + Android shell.

```
server/bladerush/   Python 3.11+ stdlib server: config, db, sql/schema.sql, api.py, net/{httpd,ws,gameserver}.py, game/{sim,bot}.py, services/*
server/tests/       39 tests (simulation, wallet, compliance, risk, live WebSocket end-to-end)
client/web/         HTML/CSS/JS client (canvas, prediction, interpolation, WebAudio) – also the PWA
android/            Gradle project: WebView shell that bundles client/web
tools/              run_dev.sh, build_apk.sh        docs/  PROTOCOL, API, ARCHITECTURE, DEPLOYMENT, COMPLIANCE
```
Quick start: `./tools/run_dev.sh`, then open the printed LAN URL on your phone. Details: docs/DEPLOYMENT.md.

Mode is **sandbox** by default: new accounts get 500 Birr of play credits with no cash value; a clearly labelled house bot fills the queue after 12 s so a single tester can always play. Real-money mode is locked behind licence/provider/KYC gates (docs/COMPLIANCE.md).
Controls: left thumb = move (floating stick), BLADE = swing (steals 8), DASH = i-frame burst, POWER = stored power-up. Desktop: WASD/arrows, J attack, K dash, L power.
