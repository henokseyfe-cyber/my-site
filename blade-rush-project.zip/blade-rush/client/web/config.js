// Default game-server address baked into a build. Leave empty to use the page's own origin (browser)
// or the address the player types on the sign-in screen (APK). tools/build_apk.py can overwrite this file.
window.BR_DEFAULT_SERVER = "";
window.BR_BUILD = "web";
