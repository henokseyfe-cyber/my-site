/* Procedural sound effects (WebAudio) – no asset files needed. */
(function (g) {
  const BR = g.BR = g.BR || {};
  let ctx = null, master = null, muted = localStorage.getItem('br_mute') === '1';
  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = g.AudioContext || g.webkitAudioContext; if (!AC) return;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = muted ? 0 : 0.5; master.connect(ctx.destination);
  }
  function tone(f0, f1, dur, type, vol, delay) {
    if (!ctx || muted) return;
    const t = ctx.currentTime + (delay || 0), o = ctx.createOscillator(), gn = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.3, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, vol, fromHz, toHz, delay) {
    if (!ctx || muted) return;
    const t = ctx.currentTime + (delay || 0), n = Math.floor(ctx.sampleRate * dur), buf = ctx.createBuffer(1, n, ctx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = ctx.createBufferSource(); s.buffer = buf; const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.2;
    f.frequency.setValueAtTime(fromHz, t); f.frequency.exponentialRampToValueAtTime(toHz, t + dur);
    const gn = ctx.createGain(); gn.gain.value = vol; s.connect(f); f.connect(gn); gn.connect(master); s.start(t);
  }
  BR.audio = {
    init,
    get muted() { return muted; },
    toggle() { muted = !muted; localStorage.setItem('br_mute', muted ? '1' : '0'); if (master) master.gain.value = muted ? 0 : 0.5; return muted; },
    orb(big) { tone(big ? 520 : 760, big ? 1300 : 1100, big ? 0.28 : 0.12, 'triangle', 0.25); if (big) tone(780, 1560, 0.3, 'sine', 0.2, 0.05); },
    swing() { noise(0.16, 0.5, 2200, 500); },
    dash() { noise(0.2, 0.35, 900, 3200); tone(200, 90, 0.15, 'sawtooth', 0.12); },
    hit(mine) { tone(mine ? 110 : 160, 40, 0.25, 'square', 0.35); noise(0.12, 0.7, 1800, 200); },
    block() { tone(900, 300, 0.2, 'square', 0.25); tone(1400, 700, 0.15, 'triangle', 0.2); },
    dodge() { tone(500, 1500, 0.18, 'sine', 0.2); },
    powerup() { [523, 659, 784, 1046].forEach((f, i) => tone(f, f, 0.12, 'triangle', 0.22, i * 0.05)); },
    use() { tone(300, 900, 0.3, 'sawtooth', 0.15); },
    tick(n) { tone(n === 0 ? 1200 : 660, null, n === 0 ? 0.35 : 0.14, 'sine', 0.35); },
    win() { [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, f, 0.22, 'triangle', 0.25, i * 0.11)); },
    lose() { [440, 370, 311, 220].forEach((f, i) => tone(f, f * 0.97, 0.3, 'sawtooth', 0.15, i * 0.16)); },
    click() { tone(600, 800, 0.05, 'sine', 0.15); },
    warn() { tone(880, 880, 0.08, 'square', 0.12); },
  };
})(window);
