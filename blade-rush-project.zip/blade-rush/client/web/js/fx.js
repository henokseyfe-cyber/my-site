/* Particles, floating text, screen shake. */
(function (g) {
  const BR = g.BR = g.BR || {};
  class FX {
    constructor() { this.p = []; this.txt = []; this.shake = 0; this.flash = 0; this.rings = []; }
    burst(x, y, color, n, spd, life, size) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.283, s = (0.3 + Math.random()) * spd;
        this.p.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, max: life, c: color, s: size || 3 });
      }
      if (this.p.length > 600) this.p.splice(0, this.p.length - 600);
    }
    sparks(x, y, dx, dy, color, n) {
      const base = Math.atan2(dy, dx);
      for (let i = 0; i < n; i++) { const a = base + (Math.random() - 0.5) * 1.2, s = 150 + Math.random() * 350; this.p.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.4, max: 0.4, c: color, s: 2.5 }); }
    }
    ring(x, y, color, r1) { this.rings.push({ x, y, c: color, t: 0, r1: r1 || 70 }); }
    text(x, y, s, color, size) { this.txt.push({ x, y, s, c: color, t: 0, size: size || 20 }); }
    addShake(v) { this.shake = Math.min(14, Math.max(this.shake, v)); }
    update(dt) {
      for (const q of this.p) { q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94; q.life -= dt; }
      this.p = this.p.filter(q => q.life > 0);
      for (const t of this.txt) t.t += dt; this.txt = this.txt.filter(t => t.t < 0.9);
      for (const r of this.rings) r.t += dt; this.rings = this.rings.filter(r => r.t < 0.4);
      this.shake *= Math.pow(0.001, dt); if (this.shake < 0.2) this.shake = 0;
      this.flash = Math.max(0, this.flash - dt * 4);
    }
    draw(c) {
      c.save(); c.globalCompositeOperation = 'lighter';
      for (const q of this.p) { c.globalAlpha = Math.max(0, q.life / q.max); c.fillStyle = q.c; c.beginPath(); c.arc(q.x, q.y, q.s * (0.4 + 0.6 * q.life / q.max), 0, 6.283); c.fill(); }
      for (const r of this.rings) { const k = r.t / 0.4; c.globalAlpha = 1 - k; c.strokeStyle = r.c; c.lineWidth = 4 * (1 - k) + 1; c.beginPath(); c.arc(r.x, r.y, 10 + r.r1 * k, 0, 6.283); c.stroke(); }
      c.restore();
      c.save(); c.textAlign = 'center'; c.font = '900 20px system-ui,sans-serif';
      for (const t of this.txt) { const k = t.t / 0.9; c.globalAlpha = 1 - k * k; c.fillStyle = t.c; c.font = `900 ${t.size}px system-ui,sans-serif`; c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 3; c.strokeText(t.s, t.x, t.y - 40 * k - 12); c.fillText(t.s, t.x, t.y - 40 * k - 12); }
      c.restore();
    }
  }
  BR.FX = FX;
})(window);
