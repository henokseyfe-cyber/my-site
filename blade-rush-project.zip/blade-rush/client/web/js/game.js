/* Arena client: input → prediction → reconciliation; opponent interpolation; canvas rendering; audio/FX hooks.
   NOTHING here decides outcomes: energy, hits, orbs and the winner all come from the server. */
(function (g) {
  const BR = g.BR = g.BR || {};
  const CY = '#00e5ff', MG = '#ff2d8c', GOLD = '#ffd60a';
  const TWO_PI = Math.PI * 2;
  const glowCache = {};
  function glow(color, size) {
    const k = color + size; if (glowCache[k]) return glowCache[k];
    const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d');
    const gr = x.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    gr.addColorStop(0, color); gr.addColorStop(0.35, color + '88'); gr.addColorStop(1, color + '00');
    x.fillStyle = gr; x.fillRect(0, 0, size, size); return (glowCache[k] = c);
  }
  const lerp = (a, b, t) => a + (b - a) * t;
  const PU = { 2: { c: '#7fd0ff', n: 'SHIELD' }, 3: { c: GOLD, n: 'HASTE' }, 4: { c: '#ff5a3c', n: 'RAGE' } };

  class Game {
    constructor(canvas, hudEls) {
      this.cv = canvas; this.ctx = canvas.getContext('2d'); this.h = hudEls; this.fx = new BR.FX();
      this.active = false; this.raf = 0; this.dpr = 1; this.W = 360; this.H = 640;
      this.keys = {}; this.stick = { id: null, ox: 0, oy: 0, x: 0, y: 0 }; this.latch = { a: 0, d: 0, p: 0 };
      this.bindInput(); this.onResize = () => this.resize(); addEventListener('resize', this.onResize);
    }
    start(info) {
      this.info = info; this.R = info.rules; this.you = info.you; this.id = info.id; this.tier = info.tier;
      const a = this.R.arena;
      const mk = (x, fx) => ({ x, y: a / 2, fx, fy: 0, energy: 0, dash: 0, dx: fx, dy: 0, dcd: 0, atk: 0, stun: 0, kx: 0, ky: 0, haste: 0, shield: 0, rage: 0, inv: 0, pw: 0 });
      this.me = mk(this.you === 0 ? 150 : a - 150, this.you === 0 ? 1 : -1);
      this.prev = { x: this.me.x, y: this.me.y };
      this.opp = mk(this.you === 0 ? a - 150 : 150, this.you === 0 ? -1 : 1);
      this.err = { x: 0, y: 0 }; this.pending = []; this.seq = 0; this.buf = []; this.orbs = []; this.evq = [];
      this.latestTk = 0; this.tkOff = null; this.left = this.R.match_ticks; this.state = 'lobby';
      this.acc = 0; this.t = 0; this.trails = [[], []]; this.meRow = null;
      this.latch = { a: 0, d: 0, p: 0 }; this.fx = new BR.FX(); this.finished = false; this.lowWarned = -1; this.hudKey = '';
      this.h.me.textContent = info.me.name; this.h.op.textContent = info.opp.name + (info.opp.bot ? ' 🤖' : '');
      this.h.pot.textContent = this.tier ? `PRIZE ${(info.prize / 100).toFixed(2)} ETB · ENTRY ${(this.tier / 100)} ETB` : 'PRACTICE · NO STAKE';
      this.active = true; this.cw = -1; this.k = 0; cancelAnimationFrame(this.raf); this.last = performance.now(); this.loop(this.last);
    }
    stop() { this.active = false; cancelAnimationFrame(this.raf); this.keys = {}; this.releaseStick(); }
    setState(s) { this.state = s; }

    resize() {
      const r = this.cv.getBoundingClientRect(); if (!r.width || !this.R) return;
      this.dpr = Math.min(2, g.devicePixelRatio || 1);
      this.cv.width = Math.round(r.width * this.dpr); this.cv.height = Math.round(r.height * this.dpr);
      this.W = r.width; this.H = r.height;
      const portrait = this.H > this.W; const hudTop = portrait ? 104 : 58;
      let S = portrait ? Math.min(this.W - 8, this.H - hudTop - 250) : this.H - hudTop - 4;
      S = Math.max(220, S);
      this.S = S; this.ax = (this.W - S) / 2; this.ay = portrait ? hudTop + 6 : hudTop - 2; this.k = S / this.R.arena;
    }

    // ---------------- input ----------------
    bindInput() {
      const root = document.getElementById('s-game'), stickEl = document.getElementById('stick'), knob = stickEl.firstElementChild;
      const onBtn = (e) => e.target.closest && e.target.closest('button');
      root.addEventListener('pointerdown', (e) => {
        if (!this.active || onBtn(e) || this.stick.id !== null) return;
        if (this.W > this.H && e.clientX > this.W * 0.68) return;
        this.stick = { id: e.pointerId, ox: e.clientX, oy: e.clientY, x: 0, y: 0 };
        stickEl.style.left = e.clientX + 'px'; stickEl.style.top = e.clientY + 'px'; stickEl.classList.remove('hidden'); knob.style.transform = '';
        try { root.setPointerCapture(e.pointerId); } catch (x) {}
      });
      root.addEventListener('pointermove', (e) => {
        if (e.pointerId !== this.stick.id) return;
        let dx = e.clientX - this.stick.ox, dy = e.clientY - this.stick.oy; const m = Math.hypot(dx, dy), R = 52;
        if (m > R) { dx = dx / m * R; dy = dy / m * R; }
        this.stick.x = dx / R; this.stick.y = dy / R; knob.style.transform = `translate(${dx}px,${dy}px)`;
      });
      const up = (e) => { if (e.pointerId === this.stick.id) this.releaseStick(); };
      root.addEventListener('pointerup', up); root.addEventListener('pointercancel', up);
      this.releaseStick = () => { this.stick = { id: null, ox: 0, oy: 0, x: 0, y: 0 }; stickEl.classList.add('hidden'); };
      const btn = (id, fn) => { const el = document.getElementById(id);
        el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); el.classList.add('p'); fn(); });
        const off = () => el.classList.remove('p'); el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('pointerleave', off); };
      btn('b-atk', () => { this.latch.a = 4; }); btn('b-dash', () => { this.latch.d = 4; }); btn('b-pw', () => { this.latch.p = 3; });
      addEventListener('keydown', (e) => { if (!this.active) return; const k = e.key.toLowerCase(); this.keys[k] = true;
        if (k === 'j' || k === ' ') this.latch.a = 4; if (k === 'k' || k === 'shift') this.latch.d = 4; if (k === 'l' || k === 'e') this.latch.p = 3; });
      addEventListener('keyup', (e) => { this.keys[e.key.toLowerCase()] = false; });
    }
    readInput() {
      let mx = this.stick.x, my = this.stick.y; const K = this.keys;
      if (K.a || K.arrowleft) mx -= 1; if (K.d || K.arrowright) mx += 1; if (K.w || K.arrowup) my -= 1; if (K.s || K.arrowdown) my += 1;
      const m = Math.hypot(mx, my); if (m > 1) { mx /= m; my /= m; }
      let ax = this.me.fx, ay = this.me.fy; const dx = this.opp.x - this.me.x, dy = this.opp.y - this.me.y, d = Math.hypot(dx, dy);
      if (d < this.R.atk_range + 60 && d > 1) { ax = dx / d; ay = dy / d; } else if (m > 0.2) { ax = mx / m; ay = my / m; }
      return { mx: +mx.toFixed(3), my: +my.toFixed(3), ax: +ax.toFixed(3), ay: +ay.toFixed(3), a: this.latch.a > 0, d: this.latch.d > 0, p: this.latch.p > 0 && this.me.pw > 0 };
    }

    localTick() {
      const inp = this.readInput(); this.seq++;
      const wasAtk = this.me.atk, wasDash = this.me.dash;
      this.prev = { x: this.me.x, y: this.me.y };
      BR.stepPlayer(this.me, inp, this.R);
      if (this.me.atk === 1 && wasAtk === 0) BR.audio.swing();
      if (this.me.dash && !wasDash) { BR.audio.dash(); this.fx.burst(this.me.x, this.me.y, CY, 10, 120, 0.3, 3); }
      if (this.me.atk > 0) this.latch.a = 0; if (this.me.dash > 0) this.latch.d = 0;
      if (inp.p) { this.me.pw = 0; this.latch.p = 0; }
      for (const k of ['a', 'd', 'p']) if (this.latch[k] > 0) this.latch[k]--;
      this.pending.push({ seq: this.seq, inp }); if (this.pending.length > 150) this.pending.shift();
      BR.net.send({ t: 'in', seq: this.seq, mx: inp.mx, my: inp.my, ax: inp.ax, ay: inp.ay, a: inp.a, d: inp.d, p: inp.p });
    }

    // ---------------- network snapshots ----------------
    onSnapshot(m) {
      const now = performance.now(), R = this.R;
      this.latestTk = m.tk; this.left = m.left;
      const off = m.tk - now * R.tick / 1000;
      this.tkOff = this.tkOff === null ? off : this.tkOff + (off - this.tkOff) * (off > this.tkOff ? 0.5 : 0.02);
      this.buf.push({ tk: m.tk, rows: m.p.map(BR.fromRow) }); if (this.buf.length > 30) this.buf.shift();
      this.orbs = m.o;
      const srv = BR.fromRow(m.p[this.you]); this.meRow = srv;
      this.pending = this.pending.filter(i => i.seq > m.ack);
      const pr = Object.assign({}, srv); for (const i of this.pending) BR.stepPlayer(pr, i.inp, R);
      const ex = this.me.x - pr.x, ey = this.me.y - pr.y;
      if (Math.hypot(ex, ey) > 120) { this.err = { x: 0, y: 0 }; } else { this.err.x += ex; this.err.y += ey; }
      if (pr.stun > 0 && this.me.stun === 0) { this.err = { x: 0, y: 0 }; }
      this.me = pr; this.prev = { x: pr.x, y: pr.y }; this.me.pw = srv.pw;
      for (const ev of m.e) {
        const involvesMe = (ev.k === 'hit' && ev.b === this.you) || (ev.k === 'block' && ev.i === this.you);
        if (ev.k === 'end') this.finished = true;
        if (involvesMe || ev.k === 'end') this.fire(ev); else this.evq.push({ tk: m.tk - 1, ev });
      }
    }
    renderTick() { return performance.now() * this.R.tick / 1000 + (this.tkOff || 0) - 4; }

    fire(ev) {
      const fx = this.fx, you = this.you, mine = (i) => i === you, A = BR.audio;
      switch (ev.k) {
        case 'orb': { const c = mine(ev.i) ? CY : MG; fx.burst(ev.x, ev.y, c, ev.v > 5 ? 22 : 9, 140, 0.45, 3); fx.ring(ev.x, ev.y, c, ev.v > 5 ? 90 : 45);
          if (mine(ev.i)) { fx.text(ev.x, ev.y, '+' + ev.v, ev.v > 5 ? GOLD : CY, ev.v > 5 ? 28 : 20); A.orb(ev.v > 5); } break; }
        case 'pu': fx.burst(ev.x, ev.y, PU[ev.t].c, 20, 170, 0.5, 3); fx.ring(ev.x, ev.y, PU[ev.t].c, 80); if (mine(ev.i)) { A.powerup(); fx.text(ev.x, ev.y, PU[ev.t].n, PU[ev.t].c, 20); } break;
        case 'use': { const p = mine(ev.i) ? this.me : this.opp; fx.ring(p.x, p.y, PU[ev.t].c, 110); fx.burst(p.x, p.y, PU[ev.t].c, 18, 200, 0.5, 3); A.use(); break; }
        case 'hit': { const v = mine(ev.b); fx.burst(ev.x, ev.y, v ? MG : CY, 26, 330, 0.5, 3.5); fx.burst(ev.x, ev.y, '#ffffff', 10, 260, 0.25, 2);
          fx.text(ev.x, ev.y, '-' + ev.amt, MG, 26); if (mine(ev.a)) fx.text(this.me.x, this.me.y - 22, '+' + ev.amt, CY, 24);
          fx.addShake(v ? 10 : 6); fx.flash = v ? 0.5 : 0.2; A.hit(v); if (navigator.vibrate) navigator.vibrate(v ? 45 : 22); break; }
        case 'block': fx.ring(ev.x, ev.y, '#7fd0ff', 100); fx.burst(ev.x, ev.y, '#bfe6ff', 24, 300, 0.4, 3); fx.addShake(5); A.block(); fx.text(ev.x, ev.y, 'BLOCK', '#bfe6ff', 22); break;
        case 'dodge': fx.text(ev.x, ev.y, 'DODGE', CY, 20); A.dodge(); fx.ring(ev.x, ev.y, CY, 60); break;
        case 'swing': if (!mine(ev.i)) A.swing(); break;
        case 'dash': if (!mine(ev.i)) A.dash(); break;
        case 'end': this.setState('ended'); break;
      }
    }

    // ---------------- frame loop ----------------
    loop(now) {
      if (!this.active) return;
      this.raf = requestAnimationFrame((t) => this.loop(t));
      const dt = Math.min(0.1, (now - this.last) / 1000); this.last = now; this.t += dt;
      if (this.cv.clientWidth !== this.cw || this.cv.clientHeight !== this.ch) { this.cw = this.cv.clientWidth; this.ch = this.cv.clientHeight; this.resize(); }
      if (!this.k) return;      // canvas not laid out yet (screen hidden)
      const step = 1 / this.R.tick;
      if (this.state === 'playing') { this.acc += dt; let n = 0; while (this.acc >= step && n++ < 4) { this.acc -= step; this.localTick(); } if (n >= 4) this.acc = 0; }
      const e = Math.exp(-dt * 10); this.err.x *= e; this.err.y *= e;
      this.updateOpp(); this.processEvents(); this.fx.update(dt); this.draw(dt); this.updateHud();
    }
    processEvents() { const rt = this.renderTick(); while (this.evq.length && this.evq[0].tk <= rt) this.fire(this.evq.shift().ev); }
    updateOpp() {
      const b = this.buf; if (!b.length) return; const rt = this.renderTick(), oi = 1 - this.you;
      let i = b.length - 1; while (i > 0 && b[i - 1].tk > rt) i--;
      const B = b[i], A = i > 0 ? b[i - 1] : b[i];
      if (rt >= B.tk || A === B) { Object.assign(this.opp, B.rows[oi]); return; }
      const t = Math.max(0, Math.min(1, (rt - A.tk) / (B.tk - A.tk))), a = A.rows[oi], c = B.rows[oi], src = t < 0.5 ? a : c;
      Object.assign(this.opp, src); this.opp.x = lerp(a.x, c.x, t); this.opp.y = lerp(a.y, c.y, t); this.opp.fx = c.fx; this.opp.fy = c.fy; this.opp.energy = c.energy;
    }
    myPos() {
      const t = this.state === 'playing' ? Math.min(1, this.acc * this.R.tick) : 1;
      return { x: lerp(this.prev.x, this.me.x, t) + this.err.x, y: lerp(this.prev.y, this.me.y, t) + this.err.y };
    }

    // ---------------- drawing ----------------
    draw(dt) {
      const c = this.ctx, d = this.dpr; c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, this.W, this.H);
      const sh = this.fx.shake, R = this.R;
      c.save(); c.translate(this.ax + (Math.random() - 0.5) * sh, this.ay + (Math.random() - 0.5) * sh); c.scale(this.k, this.k);
      this.drawArena(c); this.drawOrbs(c);
      const mp = this.myPos(), me = Object.assign({}, this.me, mp);
      this.drawPlayer(c, this.opp, MG, false, dt); this.drawPlayer(c, me, CY, true, dt);
      this.fx.draw(c);
      c.restore();
      if (this.fx.flash > 0) { c.fillStyle = `rgba(255,45,140,${this.fx.flash * 0.35})`; c.fillRect(0, 0, this.W, this.H); }
      const left = this.left / R.tick;
      if (left < 10 && this.state === 'playing') { const a = (10 - left) / 10 * 0.35; const gr = c.createRadialGradient(this.W / 2, this.H / 2, this.H * 0.3, this.W / 2, this.H / 2, this.H * 0.8); gr.addColorStop(0, 'rgba(255,0,60,0)'); gr.addColorStop(1, `rgba(255,0,60,${a})`); c.fillStyle = gr; c.fillRect(0, 0, this.W, this.H); }
    }
    drawArena(c) {
      const A = this.R.arena, t = this.t;
      const bg = c.createLinearGradient(0, 0, A, A); bg.addColorStop(0, '#0d1230'); bg.addColorStop(1, '#170d2c'); c.fillStyle = bg; c.fillRect(0, 0, A, A);
      c.strokeStyle = 'rgba(120,150,255,.07)'; c.lineWidth = 1; c.beginPath();
      for (let i = 50; i < A; i += 50) { c.moveTo(i, 0); c.lineTo(i, A); c.moveTo(0, i); c.lineTo(A, i); } c.stroke();
      c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 3; c.beginPath(); c.arc(A / 2, A / 2, 90, 0, TWO_PI); c.moveTo(A / 2, 0); c.lineTo(A / 2, A); c.stroke();
      c.fillStyle = 'rgba(0,229,255,.06)'; c.fillRect(0, 0, A / 2, A); c.fillStyle = 'rgba(255,45,140,.05)'; c.fillRect(A / 2, 0, A / 2, A);
      for (const [x, y, r] of this.R.pillars) {
        c.drawImage(glow('#6a5cff', 128), x - r * 2, y - r * 2, r * 4, r * 4);
        c.beginPath(); for (let i = 0; i < 6; i++) { const a = i / 6 * TWO_PI + Math.PI / 6; c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } c.closePath();
        c.fillStyle = '#10143a'; c.fill(); c.strokeStyle = '#7b6cff'; c.lineWidth = 4; c.stroke();
      }
      const pulse = 0.6 + 0.4 * Math.sin(t * 3); c.strokeStyle = `rgba(0,229,255,${0.5 + 0.3 * pulse})`; c.lineWidth = 8; c.strokeRect(0, 0, A, A);
      c.strokeStyle = `rgba(255,45,140,${0.35 + 0.3 * pulse})`; c.lineWidth = 3; c.strokeRect(5, 5, A - 10, A - 10);
    }
    drawOrbs(c) {
      const t = this.t;
      for (const o of this.orbs) {
        const id = o[0], x = o[1], y = o[2], kind = o[3], p = 1 + 0.12 * Math.sin(t * 5 + id);
        if (kind === 0) { c.drawImage(glow(CY, 64), x - 26 * p, y - 26 * p, 52 * p, 52 * p); c.fillStyle = '#c9faff'; c.beginPath(); c.arc(x, y, 6 * p, 0, TWO_PI); c.fill(); }
        else if (kind === 1) { c.drawImage(glow(GOLD, 128), x - 56 * p, y - 56 * p, 112 * p, 112 * p); c.save(); c.translate(x, y); c.rotate(t * 1.5); c.fillStyle = '#fff3a0'; c.beginPath();
          for (let i = 0; i < 8; i++) { const r = i % 2 ? 7 : 17, a = i / 8 * TWO_PI; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); c.restore(); }
        else { const col = PU[kind].c; c.drawImage(glow(col, 96), x - 36 * p, y - 36 * p, 72 * p, 72 * p); c.fillStyle = '#0b0e22'; c.beginPath(); c.arc(x, y, 14, 0, TWO_PI); c.fill(); c.strokeStyle = col; c.lineWidth = 3; c.stroke();
          c.fillStyle = col; c.beginPath();
          if (kind === 2) { c.moveTo(x, y - 8); c.lineTo(x + 7, y - 4); c.lineTo(x + 5, y + 4); c.lineTo(x, y + 9); c.lineTo(x - 5, y + 4); c.lineTo(x - 7, y - 4); }
          else if (kind === 3) { c.moveTo(x + 2, y - 9); c.lineTo(x - 6, y + 2); c.lineTo(x, y + 2); c.lineTo(x - 2, y + 9); c.lineTo(x + 6, y - 2); c.lineTo(x, y - 2); }
          else { for (let i = 0; i < 6; i++) { const r = i % 2 ? 4 : 9, a = i / 6 * TWO_PI - Math.PI / 2; c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } }
          c.closePath(); c.fill(); }
      }
    }
    drawPlayer(c, p, col, isMe, dt) {
      const R = this.R, r = R.player_r, t = this.t, trail = this.trails[isMe ? 1 : 0];
      if (p.dash > 0) trail.push({ x: p.x, y: p.y, a: 0.6 });
      for (const q of trail) q.a -= dt * 3.5; while (trail.length && trail[0].a <= 0) trail.shift();
      for (const q of trail) { c.globalAlpha = Math.max(0, q.a); c.drawImage(glow(col, 64), q.x - 26, q.y - 26, 52, 52); } c.globalAlpha = 1;
      let x = p.x, y = p.y; if (p.stun > 0) { x += (Math.random() - 0.5) * 4; y += (Math.random() - 0.5) * 4; }
      c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(x, y + 8, r, r * 0.55, 0, 0, TWO_PI); c.fill();
      c.drawImage(glow(col, 128), x - 54, y - 54, 108, 108);
      if (p.rage > 0) { c.strokeStyle = `rgba(255,70,40,${0.6 + 0.3 * Math.sin(t * 14)})`; c.lineWidth = 4; c.beginPath(); c.arc(x, y, r + 8 + 2 * Math.sin(t * 14), 0, TWO_PI); c.stroke(); }
      if (p.haste > 0 && Math.random() < 0.5) this.fx.burst(x, y, GOLD, 1, 40, 0.3, 3);
      const ang = Math.atan2(p.fy, p.fx), reach = R.atk_range + r, half = Math.acos(R.atk_cos);
      if (p.atk > 0 && p.atk <= R.windup) { const k = p.atk / R.windup; c.fillStyle = col + Math.round(40 + 90 * k).toString(16).padStart(2, '0'); c.beginPath(); c.moveTo(x, y); c.arc(x, y, reach * (0.55 + 0.45 * k), ang - half, ang + half); c.closePath(); c.fill(); }
      else if (p.atk > R.windup) { const k = (p.atk - R.windup) / R.recover, a2 = ang - half + 2 * half * Math.min(1, k * 2.2); c.save(); c.globalCompositeOperation = 'lighter'; c.strokeStyle = `rgba(255,255,255,${1 - k})`; c.lineWidth = 10 * (1 - k) + 2; c.beginPath(); c.arc(x, y, reach * 0.92, ang - half, a2); c.stroke(); c.strokeStyle = col; c.lineWidth = 18 * (1 - k); c.globalAlpha = 0.6 * (1 - k); c.stroke(); c.restore(); }
      c.globalAlpha = p.inv > 0 && Math.floor(t * 20) % 2 ? 0.55 : 1;
      const gr = c.createRadialGradient(x - 5, y - 6, 2, x, y, r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.35, col); gr.addColorStop(1, '#10143a');
      c.fillStyle = p.stun > 0 ? '#ffffff' : gr; c.beginPath(); c.arc(x, y, r, 0, TWO_PI); c.fill();
      c.strokeStyle = col; c.lineWidth = 3; c.stroke();
      c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x + Math.cos(ang) * (r + 9), y + Math.sin(ang) * (r + 9)); c.lineTo(x + Math.cos(ang + 2.5) * (r - 2), y + Math.sin(ang + 2.5) * (r - 2)); c.lineTo(x + Math.cos(ang - 2.5) * (r - 2), y + Math.sin(ang - 2.5) * (r - 2)); c.closePath(); c.fill();
      c.globalAlpha = 1;
      if (p.shield > 0) { c.strokeStyle = `rgba(160,220,255,${0.6 + 0.3 * Math.sin(t * 10)})`; c.fillStyle = 'rgba(120,200,255,.15)'; c.lineWidth = 4; c.beginPath(); c.arc(x, y, r + 11, 0, TWO_PI); c.fill(); c.stroke(); }
      if (p.pw) { c.fillStyle = PU[p.pw].c; c.beginPath(); c.arc(x, y - r - 14, 5, 0, TWO_PI); c.fill(); }
      if (isMe) { c.fillStyle = '#fff'; c.font = '800 13px system-ui'; c.textAlign = 'center'; c.fillText('YOU', x, y + r + 20); }
    }

    // ---------------- HUD ----------------
    updateHud() {
      const R = this.R, T = R.target, h = this.h;
      const me = this.meRow ? this.meRow.energy : 0, op = this.buf.length ? this.buf[this.buf.length - 1].rows[1 - this.you].energy : 0;
      const sec = Math.max(0, Math.ceil(this.left / R.tick)), key = `${me}|${op}|${sec}|${this.me.pw}|${Math.round(BR.net.rtt)}`;
      h.dashCd.style.strokeDashoffset = (100.5 * (1 - this.me.dcd / R.dash_cd)).toFixed(1); h.dash.classList.toggle('cd', this.me.dcd > 0);
      if (key === this.hudKey) return; this.hudKey = key;
      h.barMe.style.width = Math.min(100, me / T * 100) + '%'; h.barOp.style.width = Math.min(100, op / T * 100) + '%'; h.numMe.textContent = me; h.numOp.textContent = op;
      h.time.textContent = `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`; h.time.classList.toggle('low', sec <= 10 && this.state === 'playing');
      if (sec <= 10 && sec > 0 && sec !== this.lowWarned && this.state === 'playing') { this.lowWarned = sec; BR.audio.warn(); }
      h.pw.disabled = !this.me.pw; h.pw.firstElementChild.textContent = this.me.pw ? PU[this.me.pw].n : 'POWER';
      h.net.textContent = Math.round(BR.net.rtt) + ' ms';
    }
  }
  BR.Game = Game;
})(window);
