/* App controller: auth, navigation, matchmaking, match flow. Results/wallet live in wallet.js. */
(function (g) {
  const BR = g.BR, $ = BR.$, ui = BR.ui, net = BR.net, A = BR.audio;
  BR.BUILD = g.BR_BUILD || 'web';
  const S = BR.S = { user: null, bal: { available: 0, locked: 0 }, tiers: [], feeBps: 1500, mode: 'sandbox', match: null, game: null, inMatch: false, queueTier: null, regMode: false, walletTab: 'hist', cfg: null, lastWasPractice: false };

  const hud = () => ({ me: $('hud-me'), op: $('hud-op'), barMe: $('bar-me'), barOp: $('bar-op'), numMe: $('num-me'), numOp: $('num-op'), time: $('hud-time'),
    pot: $('hud-pot'), net: $('hud-net'), pw: $('b-pw'), dash: $('b-dash'), dashCd: $('dash-cd') });

  BR.setBal = function (b) {
    if (b) S.bal = { available: b.available, locked: b.locked };
    $('h-bal').textContent = BR.birr(S.bal.available); $('st-bal').textContent = BR.birr(S.bal.available);
    $('w-avail').textContent = BR.birr(S.bal.available, 2); $('w-locked').textContent = BR.birr(S.bal.locked, 2);
  };
  function setBanner() {
    const b = $('banner');
    b.textContent = S.mode === 'sandbox' ? 'SANDBOX · PLAY CREDITS ONLY · NO REAL MONEY' : '18+ · PLAY RESPONSIBLY'; b.classList.remove('hidden');
    $('w-mode').textContent = S.mode === 'sandbox' ? 'Sandbox play credits – not real money' : 'Real-money wallet';
    $('h-foot').innerHTML = (S.mode === 'sandbox' ? 'Sandbox build: credits have no cash value.<br>' : '') + '18+ only · Play responsibly · The server decides every result';
  }

  // ---------------- auth ----------------
  function authMode(reg) {
    S.regMode = reg; $('tab-login').classList.toggle('on', !reg); $('tab-reg').classList.toggle('on', reg); $('reg-only').classList.toggle('hidden', !reg);
    $('a-go').textContent = reg ? 'Create account' : 'Sign in'; $('a-pass').autocomplete = reg ? 'new-password' : 'current-password'; $('a-err').textContent = '';
  }
  $('tab-login').onclick = () => authMode(false); $('tab-reg').onclick = () => authMode(true);
  function srvLabel() { $('a-server-v').textContent = BR.server.get() || 'not set'; }
  $('a-server').onclick = async () => {
    const v = await ui.prompt('Game server address (e.g. http://192.168.1.20:8080)', BR.server.get()); if (v !== null) { BR.server.set(v); srvLabel(); }
  };
  $('f-auth').onsubmit = async (e) => {
    e.preventDefault(); A.init(); const err = $('a-err'); err.textContent = ''; $('a-go').disabled = true;
    try {
      const body = { username: $('a-user').value.trim(), password: $('a-pass').value, device: 'android' };
      if (S.regMode) {
        body.dob = $('a-dob').value; body.country = $('a-cc').value; body.accept_terms = $('a-terms').checked;
        if (!body.dob) throw { message: 'Enter your date of birth' }; if (!body.accept_terms) throw { message: 'You must accept the terms (18+)' };
      }
      const r = await BR.api('POST', S.regMode ? '/api/auth/register' : '/api/auth/login', body);
      localStorage.setItem('br_token', r.token); boot();
    } catch (x) { err.textContent = x.message || 'Failed'; } finally { $('a-go').disabled = false; }
  };
  BR.signOut = function () { BR.api('POST', '/api/auth/logout').catch(() => {}); localStorage.removeItem('br_token'); net.close(); stopGame(); ui.show('auth'); };

  // ---------------- boot / connection ----------------
  async function boot() {
    srvLabel();
    if (!localStorage.getItem('br_token')) return ui.show('auth');
    try {
      const cfg = await BR.api('GET', '/api/config'); S.cfg = cfg; S.mode = cfg.mode; S.feeBps = cfg.fee_bps; S.tiers = cfg.tiers; setBanner();
      await BR.api('GET', '/api/me');
    } catch (x) {
      if (x.code === 'unauthorized') { localStorage.removeItem('br_token'); return ui.show('auth'); }
      ui.show('auth'); $('a-err').textContent = x.message; return;
    }
    net.connect();
  }
  net.on('open', (m) => {
    $('conn').classList.add('hidden'); S.user = m.user; S.tiers = m.tiers; S.feeBps = m.fee_bps; S.mode = m.mode; setBanner(); BR.setBal(m.balance);
    $('h-name').textContent = m.user.username; $('h-av').textContent = m.user.username[0].toUpperCase(); $('h-rating').textContent = m.user.rating;
    if (ui.current === 'auth') ui.show('home');
    else if (ui.current === 'mm' && !S.inMatch) { S.queueTier = null; ui.toast('Connection was lost – please search again'); ui.show(S.lastWasPractice ? 'home' : 'stake'); }
  });
  net.on('close', () => { if (localStorage.getItem('br_token')) $('conn').classList.remove('hidden'); });
  net.on('kicked', () => { ui.toast('Signed in on another device'); localStorage.removeItem('br_token'); net.close(); stopGame(); ui.show('auth'); });
  net.on('error', (m) => {
    if (m.code === 'unauthorized') { localStorage.removeItem('br_token'); net.close(); ui.show('auth'); return; }
    if (['bad_build', 'bad_protocol'].includes(m.code)) { net.close(); ui.toast(m.msg, 6000); return; }
    S.queueTier = null; ui.toast(m.msg || m.code, 3600);
    if (ui.current === 'mm' && !S.inMatch) ui.show(S.lastWasPractice ? 'home' : 'stake');
  });
  net.on('balance', (m) => BR.setBal(m));

  // ---------------- navigation ----------------
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-go]'); if (!b) return; A.init(); A.click();
    const to = b.dataset.go; if (to === 'wallet') BR.openWallet(); else ui.show(to);
  });
  $('h-play').onclick = () => { A.init(); A.click(); renderTiers(); ui.show('stake'); };
  $('h-practice').onclick = () => { A.init(); S.lastWasPractice = true; queue(0); };
  function renderTiers() {
    const box = $('tiers'); box.innerHTML = ''; $('st-fee').textContent = (S.feeBps / 100).toString();
    for (const t of S.tiers) {
      const pot = t * 2, fee = Math.floor(pot * S.feeBps / 10000), prize = pot - fee, ok = S.bal.available >= t;
      const d = document.createElement('button'); d.className = 'tier' + (ok ? '' : ' lock');
      d.innerHTML = `<small>ENTRY</small><b>${BR.birr(t)}</b><small>ETB</small><div class="win">Win ${BR.birr(prize)}</div>`;
      d.onclick = () => { A.init(); A.click(); if (!ok) return ui.toast('Not enough balance – add credits in Wallet'); S.lastWasPractice = false; queue(t); };
      box.appendChild(d);
    }
    $('st-note').innerHTML = `Pot = 2 × entry. The ${(S.feeBps / 100)}% platform fee is taken from the pot; the winner receives the rest.<br>Draws, no-shows and server faults are refunded in full.`;
  }
  function queue(tier) {
    S.queueTier = tier; $('mm-vs').classList.add('hidden'); $('mm-prize').classList.add('hidden'); $('mm-cancel').classList.remove('hidden');
    $('mm-title').textContent = tier ? 'Finding opponent…' : 'Starting practice…'; $('mm-tier').textContent = tier ? BR.birr(tier) + ' ETB' : 'free';
    ui.show('mm'); net.send({ t: 'queue', tier });
  }
  net.on('queued', () => { if (ui.current !== 'mm') ui.show('mm'); });
  $('mm-cancel').onclick = () => { net.send({ t: 'cancel' }); S.queueTier = null; ui.show(S.lastWasPractice ? 'home' : 'stake'); };
  net.on('queue_cancelled', () => { S.queueTier = null; });

  // ---------------- match flow ----------------
  function ensureGame() { if (!S.game) S.game = new BR.Game($('cv'), hud()); return S.game; }
  function stopGame() { if (S.game) S.game.stop(); S.inMatch = false; ui.setOverlay(''); }
  BR.stopGame = stopGame;
  net.on('match_found', (m) => {
    S.match = m; S.inMatch = true; S.queueTier = null; ui.setOverlay('');
    if (m.resume && m.phase !== 'lobby') {       // reconnected into a live match
      const gm = ensureGame(); ui.show('game'); gm.start(m); gm.seq = m.seq || 0;
      gm.setState(m.phase === 'playing' ? 'playing' : 'countdown'); if (m.phase !== 'playing') ui.setOverlay('GET READY'); return;
    }
    $('mm-title').textContent = 'Opponent found'; $('mm-vs').classList.remove('hidden'); $('mm-cancel').classList.add('hidden');
    $('vs-me').textContent = m.me.name; $('vs-me-r').textContent = 'Rating ' + m.me.rating;
    $('vs-op').textContent = m.opp.name + (m.opp.bot ? ' 🤖' : ''); $('vs-op-r').textContent = 'Rating ' + m.opp.rating;
    if (m.tier) { $('mm-prize').textContent = `Entry ${BR.birr(m.tier)} locked · Prize ${BR.birr(m.prize, 2)} ETB`; $('mm-prize').classList.remove('hidden'); }
    ui.show('mm'); A.powerup(); ensureGame().start(m); S.game.setState('lobby');
    setTimeout(() => { if (S.inMatch && S.match === m) { ui.show('game'); ui.setOverlay('GET READY', 'Left thumb: move · right: BLADE / DASH'); net.send({ t: 'ready' }); } }, 1500);
  });
  net.on('cancelled', () => { stopGame(); ui.toast('Opponent did not join. Your entry was refunded.', 4200); ui.show('home'); });
  net.on('countdown', (m) => { if (ui.current !== 'game') ui.show('game'); ui.setOverlay(String(m.n)); A.tick(m.n); if (S.game) S.game.setState('countdown'); });
  net.on('go', () => {
    ui.setOverlay('GO!'); A.tick(0); if (S.game) { S.game.setState('playing'); S.game.acc = 0; }
    setTimeout(() => { if (S.game && S.game.state === 'playing') ui.setOverlay(''); }, 600);
  });
  net.on('s', (m) => { if (S.game && S.inMatch) S.game.onSnapshot(m); });
  net.on('opp', (m) => {
    if (m.connected) { ui.setOverlay(''); ui.toast('Opponent is back'); }
    else ui.setOverlay('Opponent disconnected', `Waiting up to ${Math.round(m.grace_ms / 1000)}s – you win if they do not return`, true);
  });
  $('g-surrender').onclick = async () => {
    const ok = await ui.modal('<b>Forfeit this match?</b><br><span class="muted">You lose your entry and the opponent wins.</span>', [['Keep playing', false], ['Forfeit', true, 'danger']]);
    if (ok) net.send({ t: 'surrender' });
  };
  document.addEventListener('visibilitychange', () => { if (!document.hidden && localStorage.getItem('br_token') && !net.open) net.connect(); });
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  addEventListener('online', () => { if (localStorage.getItem('br_token') && !net.open) net.connect(); });
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
  srvLabel(); setTimeout(boot, 0);
})(window);
