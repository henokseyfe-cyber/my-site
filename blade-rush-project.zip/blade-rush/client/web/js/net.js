/* API + WebSocket client with auto-reconnect, RTT measurement, and server clock estimation. */
(function (g) {
  const BR = g.BR = g.BR || {};
  const PROTOCOL = 1;

  BR.server = {
    get() {
      let v = localStorage.getItem('br_server');
      if (!v && g.BR_DEFAULT_SERVER) v = g.BR_DEFAULT_SERVER;
      if (!v && /^https?:$/.test(location.protocol)) v = location.origin;
      return (v || '').replace(/\/+$/, '');
    },
    set(v) { v = (v || '').trim().replace(/\/+$/, ''); if (v && !/^https?:\/\//.test(v)) v = 'http://' + v; localStorage.setItem('br_server', v); return v; },
    ws() { return this.get().replace(/^http/, 'ws') + '/ws'; },
  };

  BR.api = async function (method, path, body) {
    const base = BR.server.get();
    if (!base) throw { code: 'no_server', message: 'Set the server address first' };
    const h = { 'Content-Type': 'application/json' };
    const t = localStorage.getItem('br_token'); if (t) h.Authorization = 'Bearer ' + t;
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 12000);
    let r;
    try { r = await fetch(base + path, { method, headers: h, body: body ? JSON.stringify(body) : undefined, signal: ctl.signal }); }
    catch (e) { throw { code: 'network', message: 'Cannot reach the server at ' + base }; }
    finally { clearTimeout(to); }
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw { code: j.error || 'http_' + r.status, message: j.message || 'Request failed', status: r.status };
    return j;
  };

  class Net {
    constructor() {
      this.ws = null; this.handlers = {}; this.rtt = 60; this.open = false; this.want = false;
      this.retry = 0; this.timer = null; this.pingTimer = null; this.lastRx = 0;
    }
    on(t, fn) { this.handlers[t] = fn; return this; }
    emit(t, m) { const f = this.handlers[t]; if (f) try { f(m); } catch (e) { console.error(t, e); } }
    connect() {
      this.want = true; if (this.ws) return;
      const token = localStorage.getItem('br_token'); if (!token) return;
      let ws; try { ws = new WebSocket(BR.server.ws()); } catch (e) { return this.scheduleRetry(); }
      this.ws = ws;
      ws.onopen = () => { ws.send(JSON.stringify({ t: 'auth', v: PROTOCOL, token, build: BR.BUILD || 'web', device: 'web' })); };
      ws.onmessage = (ev) => {
        this.lastRx = performance.now();
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === 'hello') { this.open = true; this.retry = 0; this.startPing(); this.emit('open', m); }
        else if (m.t === 'pong') { const r = performance.now() - m.c; this.rtt = this.rtt * 0.7 + r * 0.3; }
        this.emit(m.t, m);
      };
      ws.onclose = () => { const was = this.open; this.open = false; this.ws = null; clearInterval(this.pingTimer); this.emit('close', { was }); if (this.want) this.scheduleRetry(); };
      ws.onerror = () => {};
    }
    scheduleRetry() { clearTimeout(this.timer); const d = Math.min(4000, 400 * Math.pow(1.6, this.retry++)); this.timer = setTimeout(() => this.connect(), d); }
    startPing() { clearInterval(this.pingTimer); this.pingTimer = setInterval(() => this.send({ t: 'ping', c: performance.now() }), 2000); }
    send(o) { if (this.ws && this.ws.readyState === 1) { this.ws.send(JSON.stringify(o)); return true; } return false; }
    close() { this.want = false; clearTimeout(this.timer); clearInterval(this.pingTimer); if (this.ws) { try { this.ws.close(); } catch (e) {} } this.ws = null; this.open = false; }
  }
  BR.net = new Net();
})(window);
