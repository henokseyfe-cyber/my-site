/* Client-side mirror of server/bladerush/game/sim.py::step_player (movement, dash, attack state).
   Used ONLY for prediction. The server is authoritative and overwrites this on every snapshot. */
(function (g) {
  const BR = g.BR = g.BR || {};
  const hyp = Math.hypot;

  function normInput(inp) {
    let mx = +inp.mx || 0, my = +inp.my || 0, m = hyp(mx, my);
    if (m < 0.12) return [0, 0, 0];
    if (m > 1) { mx /= m; my /= m; m = 1; }
    return [mx, my, m];
  }

  function resolveStatic(p, R) {
    const r = R.player_r, a = R.arena;
    p.x = Math.min(Math.max(p.x, r), a - r); p.y = Math.min(Math.max(p.y, r), a - r);
    for (const [ox, oy, orad] of R.pillars) {
      let dx = p.x - ox, dy = p.y - oy, d = hyp(dx, dy); const mn = orad + r;
      if (d < mn) {
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        p.x = ox + dx / d * mn; p.y = oy + dy / d * mn;
      }
    }
    p.x = Math.min(Math.max(p.x, r), a - r); p.y = Math.min(Math.max(p.y, r), a - r);
  }

  BR.stepPlayer = function (p, inp, R) {
    const dt = 1 / R.tick;
    const hasting = p.haste > 0;
    if (p.haste > 0) p.haste--;
    if (p.dcd > 0) p.dcd--;
    if (p.stun > 0) {
      p.stun--;
      p.x += p.kx * dt; p.y += p.ky * dt;
      p.kx *= R.knock_decay; p.ky *= R.knock_decay;
      resolveStatic(p, R); return;
    }
    const [mx, my, m] = normInput(inp);
    if (p.atk > 0) { p.atk++; if (p.atk > R.windup + R.recover) p.atk = 0; }
    if (inp.d && p.dash === 0 && p.dcd === 0 && (p.atk === 0 || p.atk > R.windup)) {
      p.atk = 0; p.dash = R.dash_ticks; p.dcd = R.dash_cd;
      if (m > 0) { p.dx = mx / m; p.dy = my / m; } else { p.dx = p.fx; p.dy = p.fy; }
      p.fx = p.dx; p.fy = p.dy;
    } else if (inp.a && p.atk === 0 && p.dash === 0) {
      const ax = +inp.ax || 0, ay = +inp.ay || 0, am = hyp(ax, ay);
      if (am > 1e-6) { p.fx = ax / am; p.fy = ay / am; }
      p.atk = 1;
    }
    if (p.dash > 0) {
      p.x += p.dx * R.dash_speed * dt; p.y += p.dy * R.dash_speed * dt; p.dash--;
    } else {
      const sp = R.speed * (hasting ? R.haste_mult : 1) * (p.atk > 0 ? R.atk_move_mult : 1);
      p.x += mx * sp * dt; p.y += my * sp * dt;
      if (m > 0 && p.atk === 0) { p.fx = mx / m; p.fy = my / m; }
    }
    resolveStatic(p, R);
  };

  // snapshot row -> player object
  BR.fromRow = function (r) {
    return { x: r[0], y: r[1], fx: r[2], fy: r[3], energy: r[4], dash: r[5], dx: r[6], dy: r[7], dcd: r[8], atk: r[9],
             stun: r[10], kx: r[11], ky: r[12], haste: r[13], shield: r[14], rage: r[15], inv: r[16], pw: r[17] };
  };
})(window);
