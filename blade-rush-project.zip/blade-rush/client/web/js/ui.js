/* Small UI helpers: screens, toast, modal, formatting. */
(function (g) {
  const BR = g.BR = g.BR || {};
  const $ = (id) => document.getElementById(id);
  BR.$ = $;
  BR.birr = (minor, dec) => { const v = minor / 100; return v.toLocaleString('en-US', { minimumFractionDigits: dec == null ? (Number.isInteger(v) ? 0 : 2) : dec, maximumFractionDigits: 2 }); };
  BR.ui = {
    current: 'auth',
    show(name) {
      document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
      const el = $('s-' + name); el.classList.remove('hidden'); this.current = name; el.scrollTop = 0;
    },
    toast(msg, ms) {
      const t = $('toast'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(this._tt);
      this._tt = setTimeout(() => t.classList.add('hidden'), ms || 2800);
    },
    modal(html, buttons) {
      return new Promise((res) => {
        $('m-body').innerHTML = html; const box = $('m-btns'); box.innerHTML = '';
        buttons.forEach(([label, val, cls]) => { const b = document.createElement('button'); b.className = 'btn ' + (cls || 'ghost'); b.textContent = label;
          b.onclick = () => { $('modal').classList.add('hidden'); res(val); }; box.appendChild(b); });
        $('modal').classList.remove('hidden');
      });
    },
    prompt(title, def) {
      return new Promise((res) => {
        $('m-body').innerHTML = `<b>${this.esc(title)}</b><input id="m-in" value="${this.esc(def || '')}" inputmode="decimal" style="margin-top:10px;width:100%">`;
        const box = $('m-btns'); box.innerHTML = '';
        const mk = (label, ok, cls) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = label;
          b.onclick = () => { const v = $('m-in').value; $('modal').classList.add('hidden'); res(ok ? v : null); }; box.appendChild(b); };
        mk('Cancel', false, 'ghost'); mk('OK', true, 'primary'); $('modal').classList.remove('hidden');
      });
    },
    esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); },
    setOverlay(text, sub, small) {
      const o = $('overlay'), t = $('ov-text'); if (!text) { o.classList.add('hidden'); return; }
      o.classList.remove('hidden'); t.textContent = text; t.className = small ? 'sm' : ''; void t.offsetWidth; if (!small) t.classList.add('pop'); $('ov-sub').textContent = sub || '';
    },
  };
})(window);
