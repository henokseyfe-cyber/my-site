/* Results screen, wallet, history, responsible-gaming screens. */
(function (g) {
  const BR = g.BR, $ = BR.$, ui = BR.ui, net = BR.net, A = BR.audio, S = BR.S;

  // ---------------- results ----------------
  let rmTimer = null;
  net.on('result', (m) => {
    S.inMatch = true; if (S.game) { S.game.setState('ended'); S.game.releaseStick(); } BR.setBal(m.balance); $('h-rating').textContent = m.rating;
    ui.setOverlay(m.outcome === 'win' ? 'VICTORY' : m.outcome === 'loss' ? 'DEFEAT' : 'DRAW', '', false);
    if (m.outcome === 'win') A.win(); else if (m.outcome === 'loss') A.lose(); else A.click();
    setTimeout(() => {
      ui.setOverlay(''); const mine = m.energy[m.you], theirs = m.energy[1 - m.you];
      const b = $('r-badge'); b.className = 'r-badge ' + m.outcome; b.textContent = m.outcome === 'win' ? 'VICTORY' : m.outcome === 'loss' ? 'DEFEAT' : 'DRAW';
      $('r-me').textContent = mine; $('r-op').textContent = theirs; $('r-opn').textContent = ((S.match && S.match.opp.name) || 'RIVAL').toUpperCase();
      const rm = $('r-money');
      const why = { target: 'First to 100 energy', time: 'Time expired', forfeit: 'A player left the match', abandoned: 'Match abandoned – refunded' }[m.reason] || m.reason;
      if (!m.tier) { rm.className = 'r-money'; rm.innerHTML = `Practice match<small>${why}</small>`; }
      else if (m.held) { rm.className = 'r-money'; rm.innerHTML = `Under review<small>Your result is being checked. Entries stay locked until the review completes.</small>`; }
      else if (m.status === 'refunded' || m.outcome === 'draw') { rm.className = 'r-money'; rm.innerHTML = `Entry refunded<small>${why}</small>`; }
      else if (m.net > 0) { rm.className = 'r-money pos'; rm.innerHTML = `+${BR.birr(m.net, 2)} ETB<small>Prize ${BR.birr(m.prize, 2)} · platform fee ${BR.birr(m.fee, 2)} · ${why}</small>`; }
      else { rm.className = 'r-money neg'; rm.innerHTML = `${BR.birr(m.net, 2)} ETB<small>${why}</small>`; }
      const st = m.stats;
      $('r-stats').innerHTML = `<div><b>${st.hits}</b>hits</div><div><b>${st.orbs}</b>orbs</div><div><b>${st.dodges}</b>dodges</div><div><b>${st.blocks}</b>blocks</div>`;
      const rb = $('r-rematch'); rb.textContent = m.held ? 'REMATCH UNAVAILABLE' : 'REMATCH'; rb.disabled = !!m.held;
      ui.show('result'); startRm(m.rematch_ms);
    }, 1600);
  });
  function startRm(ms) {
    clearInterval(rmTimer); const end = performance.now() + ms, el = $('r-rm'); el.textContent = '';
    rmTimer = setInterval(() => { const s = Math.ceil((end - performance.now()) / 1000); el.textContent = s > 0 ? `Rematch offer expires in ${s}s` : ''; if (s <= 0) clearInterval(rmTimer); }, 250);
  }
  $('r-rematch').onclick = () => { A.init(); A.click(); net.send({ t: 'rematch' }); const b = $('r-rematch'); b.disabled = true; b.textContent = 'WAITING FOR OPPONENT…'; };
  net.on('rematch', (m) => {
    const b = $('r-rematch');
    if (m.state === 'offered') ui.toast('Opponent wants a rematch!');
    if (m.state === 'declined') { ui.toast('Opponent left'); b.disabled = true; b.textContent = 'OPPONENT LEFT'; }
    if (m.state === 'expired') { b.disabled = true; b.textContent = 'REMATCH EXPIRED'; S.inMatch = false; }
    if (m.state === 'failed') { ui.toast('Rematch could not start (balance or limits)'); b.disabled = true; b.textContent = 'REMATCH UNAVAILABLE'; S.inMatch = false; }
  });
  $('r-home').onclick = () => { net.send({ t: 'leave' }); BR.stopGame(); clearInterval(rmTimer); ui.show('home'); };

  // ---------------- wallet / history ----------------
  BR.openWallet = async function () {
    ui.show('wallet'); BR.setBal();
    try { const w = await BR.api('GET', '/api/wallet'); BR.setBal(w.balance); S.txs = w.transactions; } catch (x) { ui.toast(x.message); }
    try { const h = await BR.api('GET', '/api/matches'); S.hist = h.matches; } catch (x) {}
    renderList();
  };
  const KIND = { stake_lock: 'Entry locked', payout: 'Prize', refund: 'Entry refunded', deposit: 'Deposit', sandbox_credit: 'Play credits', withdrawal_reserve: 'Withdrawal requested', withdrawal: 'Withdrawal', withdrawal_release: 'Withdrawal returned' };
  function renderList() {
    $('wt-hist').classList.toggle('on', S.walletTab === 'hist'); $('wt-tx').classList.toggle('on', S.walletTab === 'tx');
    const box = $('w-list'); box.innerHTML = '';
    const fmt = (t) => new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    if (S.walletTab === 'hist') {
      if (!(S.hist || []).length) box.innerHTML = '<div class="muted center">No matches yet. Play one!</div>';
      for (const m of S.hist || []) {
        const d = document.createElement('div'); d.className = 'row-i'; const cls = m.net > 0 ? 'pos' : m.net < 0 ? 'neg' : '';
        d.innerHTML = `<div><b>${ui.esc(m.result.toUpperCase())}</b> vs ${ui.esc(m.opponent)}<small>${fmt(m.at)} · ${m.tier ? BR.birr(m.tier) + ' ETB entry' : 'practice'} · ${m.energy[0]}–${m.energy[1]}</small></div><div class="amt ${cls}">${m.tier ? (m.net > 0 ? '+' : '') + BR.birr(m.net, 2) : '–'}</div>`;
        box.appendChild(d);
      }
    } else {
      if (!(S.txs || []).length) box.innerHTML = '<div class="muted center">No transactions.</div>';
      for (const t of S.txs || []) {
        const d = document.createElement('div'); d.className = 'row-i';
        d.innerHTML = `<div><b>${ui.esc(KIND[t.kind] || t.kind)}</b><small>${fmt(t.created_at)} · ${ui.esc(t.id.slice(0, 11))}</small></div><div class="amt ${t.amount > 0 ? 'pos' : 'neg'}">${t.amount > 0 ? '+' : ''}${BR.birr(t.amount, 2)}</div>`;
        box.appendChild(d);
      }
    }
  }
  $('wt-hist').onclick = () => { S.walletTab = 'hist'; renderList(); }; $('wt-tx').onclick = () => { S.walletTab = 'tx'; renderList(); };
  $('w-dep').onclick = async () => {
    const amt = await ui.prompt(S.mode === 'sandbox' ? 'Add how many play credits (Birr)?' : 'Deposit amount (Birr)', '100'); if (!amt) return;
    const minor = Math.round(parseFloat(amt) * 100); if (!(minor > 0)) return ui.toast('Enter a valid amount');
    const key = 'dep-' + Date.now() + '-' + Math.random().toString(36).slice(2, 10);
    try {
      const r = await BR.api('POST', '/api/wallet/deposit', { amount: minor, idempotency_key: key });
      if (r.checkout_url) { location.href = r.checkout_url; return; }
      ui.toast(r.status === 'succeeded' ? 'Credits added' : 'Deposit pending'); BR.openWallet();
    } catch (x) { ui.toast(x.message); }
  };
  $('w-rg').onclick = openRG;
  async function openRG() {
    ui.show('rg');
    try {
      const m = await BR.api('GET', '/api/me'), l = m.limits;
      $('l-stake').value = l.daily_stake / 100; $('l-loss').value = l.daily_loss / 100; $('l-dep').value = l.daily_deposit / 100; $('l-min').value = l.daily_minutes;
      $('l-used').textContent = `Today: entered ${BR.birr(l.used.stake)} · net loss ${BR.birr(l.used.loss)} · played ${l.used.minutes} min` + (l.pending ? ' · an increase is pending (cooling-off)' : '');
      $('l-msg').textContent = m.exclusion_until > Date.now() ? 'Self-excluded until ' + new Date(m.exclusion_until).toLocaleString() : '';
    } catch (x) { ui.toast(x.message); }
  }
  $('l-save').onclick = async () => {
    try {
      await BR.api('PUT', '/api/limits', { daily_stake: Math.round($('l-stake').value * 100), daily_loss: Math.round($('l-loss').value * 100), daily_deposit: Math.round($('l-dep').value * 100), daily_minutes: parseInt($('l-min').value, 10) });
      ui.toast('Limits saved (increases apply after a cooling-off period)'); openRG();
    } catch (x) { ui.toast(x.message); }
  };
  $('x-go').onclick = async () => {
    const d = parseInt($('x-days').value, 10);
    if (await ui.modal(`<b>Self-exclude for ${d >= 3650 ? 'a very long time' : d + ' day(s)'}?</b><br><span class="muted">You will not be able to play staked matches. This cannot be undone.</span>`, [['Cancel', false], ['Confirm', true, 'danger']])) {
      try { await BR.api('POST', '/api/self-exclude', { days: d }); ui.toast('Self-exclusion active'); openRG(); } catch (x) { ui.toast(x.message); }
    }
  };
  $('k-go').onclick = async () => {
    try { const r = await BR.api('POST', '/api/kyc/start'); ui.toast(r.status === 'verified' ? 'Identity verified' : 'Verification submitted – pending review'); if (r.url) location.href = r.url; } catch (x) { ui.toast(x.message); }
  };
  $('lo-go').onclick = BR.signOut;
})(window);
