# REST API  (JSON, `Authorization: Bearer <token>`; errors: `{"error":"code","message":"..."}`)
All money is integer **santim** (1 Birr = 100). The client can *request*; only the server's wallet service moves money.

| Method & path | Auth | Purpose |
|---|---|---|
| GET `/api/health`, `/api/config` | – | liveness, tiers, fee_bps, mode, min age |
| POST `/api/auth/register` | – | `username,password,dob(YYYY-MM-DD),country,accept_terms` – rejects under-18 |
| POST `/api/auth/login`, `/api/auth/logout` | – / user | session tokens (only an HMAC of the token is stored) |
| GET `/api/me` | user | profile, balances, limits + usage, exclusion |
| GET `/api/wallet` | user | balances + ledger lines |
| GET `/api/matches` | user | match history (result, net, opponent) |
| POST `/api/wallet/deposit` | user | `amount, idempotency_key`; sandbox credits instantly, real mode → provider checkout + webhook |
| POST `/api/wallet/withdraw` | user | `amount, idempotency_key`; reserved in ledger, completed by provider (disabled in sandbox) |
| POST `/api/payments/webhook` | provider signature | HMAC-verified, idempotent confirmation |
| POST `/api/kyc/start` | user | starts verification with the configured provider |
| PUT `/api/limits` | user | daily entry / loss / deposit / minutes; decreases immediate, increases after cool-off |
| POST `/api/self-exclude` | user | `days` 1..3650 |
| GET `/api/leaderboard` | – | top ratings |
| GET `/admin/reviews`, POST `/admin/reviews/{id}` `{action: pay|refund}` | `X-Admin-Token` | held matches |
| POST `/admin/users/{id}/kyc`, `/admin/users/{id}/ban` | admin | |
| GET `/admin/reconcile`, `/admin/stats` | admin | ledger sum + balances check, audit-chain verification |
