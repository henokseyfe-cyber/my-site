# Architecture
```
 Android APK (WebView shell) ─┐         ┌────────────────────────────── server/bladerush ───────────────────────────┐
 Browser / installed PWA ─────┼─ HTTPS ─┤ net/httpd.py     HTTP + static + WS upgrade (asyncio, no deps)             │
                              └─ WSS ───┤ api.py           REST: auth, wallet, limits, KYC, admin                    │
                                        │ net/gameserver.py matchmaking, match runner (30 Hz), reconnect, rematch    │
                                        │ game/sim.py      authoritative deterministic simulation (+ bot.py)         │
                                        │ services/wallet.py   double-entry immutable ledger (ONLY writer of money)  │
                                        │ services/matches.py  lock → settle/refund (CAS + idempotency keys)         │
                                        │ services/compliance.py age · KYC · jurisdiction · limits · self-exclusion  │
                                        │ services/risk.py     anti-cheat / collusion scoring → review hold          │
                                        │ services/payments.py + providers.py   pluggable regulated PSP / KYC        │
                                        │ services/audit.py    hash-chained audit log                                │
                                        └──────────────── db.py ── PostgreSQL (prod) / SQLite (dev, tests) ─────────┘
```
## Money flow (never touched by the client)
1. `queue` → compliance check (age, KYC, jurisdiction, limits, exclusion) + balance check.
2. Pair found → **one DB transaction**: create match row (unique random id + seed) → re-check compliance → `lock_stake` for both (available → locked). Any failure rolls back everything.
3. Match ends on the server → risk analysis → `settle`: compare-and-set `status` to `settled`, then one `payout:<match_id>` transaction: winner's locked + loser's locked → winner available (pot − fee) + `platform:fee`.
4. Draw / lobby timeout / abandoned / server error / restart → `refund:<match_id>:<user>` (idempotent). Startup recovery refunds any match left `locked/playing`.
5. Risk score ≥ threshold → status `review`; funds stay locked until an admin pays or refunds.

Fee: `fee = floor(2·stake·fee_bps/10000)`, prize = pot − fee (rounded in the player's favour). 25 Birr entry → pot 50, fee 7.50, prize 42.50.

## Why this prevents double payment / races
* `ledger_transactions.idempotency_key` is UNIQUE → replaying a key is a no-op returning the original tx.
* User balance updates are `UPDATE … SET balance=balance+? WHERE balance+?>=0` + CHECK constraint → no negative balance, no lost update.
* Settlement is gated by `UPDATE matches SET status='settled' … WHERE status IN (...)` (rowcount must be 1).
* Ledger/audit rows are protected by DB triggers (no UPDATE/DELETE). `/admin/reconcile` re-derives every balance from entries.

## Anti-cheat (server-side; see services/risk.py)
Input validation (types, finite numbers, strictly increasing `seq`, per-connection flood limit, bounded queue) · speed is enforced by the simulation itself (stick vector is re-normalised, positions are never accepted) · reaction-time analysis (dash ≤ 100 ms after *every* swing) · metronomic attack timing · perfect-aim ratios · same-IP pairing block · repeat-pairing limit per 24 h · dumping / stationary-loser detection (win-trading) · disconnect abuse · build allow-list + protocol version · one live session per account. High scores **hold funds for human review** rather than auto-confiscating.
