# Compliance & responsible gaming

**This software is not a licence to operate.** Paid-entry, winner-takes-pot contests are regulated gambling or skill-gaming in most countries, including Ethiopia. Before enabling `STAKE_MODE=real` you must obtain the required licence/permit, use a licensed payment provider and KYC vendor, and get local legal advice (including on whether a skill-contest exemption applies). The repository ships in **sandbox mode (play credits, no cash value)** and refuses real mode without the gates in DEPLOYMENT.md §4. Nothing here bypasses those rules.

Implemented controls
* 18+ (configurable `MIN_AGE`): date of birth + explicit terms acceptance at sign-up; re-checked on every staked queue and match creation.
* KYC gate (`REQUIRE_KYC`) before staking, depositing, withdrawing; provider interface, status stored (no identity documents in our DB).
* Jurisdiction allow-list/deny-list by registered country (`REAL_MONEY_COUNTRIES`, `BLOCKED_REGIONS`) and optional request-country check. Production should add IP geolocation and device checks at your edge.
* Limits: daily entry, daily net loss, daily deposit, daily play minutes. Lowering is instant; raising is delayed (`LIMIT_INCREASE_COOLDOWN_S`, default 24 h).
* Self-exclusion (1 day … 10 years), enforced server-side on queue, match creation and deposits.
* Audit: every registration, login failure, limit change, exclusion, lock, settlement, refund, admin action → hash-chained `audit_log`.
Not included (needed for a licence): AML transaction monitoring and reporting, tax handling, dispute workflow UI, age/ID document vendor integration, reality-check pop-ups, data-protection/retention policy.
