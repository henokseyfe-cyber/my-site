# Deployment

## 1. Run locally (SQLite, sandbox credits)
```bash
cd server && python3 -m unittest discover -s tests      # 39 tests
cd .. && ./tools/run_dev.sh                             # prints http://<LAN-IP>:8080
```
Open that address in the phone's Chrome (same Wi-Fi) → menu → *Add to Home screen* installs it full-screen.

## 2. Production (Docker + PostgreSQL)
```bash
cp .env.example .env     # set POSTGRES_PASSWORD, ADMIN_TOKEN, TOKEN_PEPPER (>=32 chars each), APP_ENV=production
docker compose up -d --build
```
Put TLS in front (Caddy / nginx / cloud LB) and set `TRUST_PROXY=true`. Forward WebSocket upgrades on `/ws`, idle timeout ≥ 60 s.
Caddy example: `play.example.com { reverse_proxy game:8080 }`.
One process hosts all live matches (state is in memory). Scale by sharding tiers/regions over several instances with a shared PostgreSQL; the matchmaker then needs a shared queue (Redis) – not included.

## 3. Android APK
Requires JDK 17 + Android SDK (platform 34, build-tools 34) + Gradle 8.7:
```bash
SERVER_URL=http://192.168.1.20:8080 ./tools/build_apk.sh          # debug APK (cleartext allowed for LAN testing)
# output: android/app/build/outputs/apk/debug/app-debug.apk  → adb install, or copy to the phone
```
No local SDK? Push this repo to GitHub → *Actions → Build Android APK → Run workflow* (enter the server URL) → download the artifact.
Release: `RELEASE=1 SERVER_URL=https://play.example.com BR_KEYSTORE=… BR_KEYSTORE_PASSWORD=… BR_KEY_ALIAS=… BR_KEY_PASSWORD=… ./tools/build_apk.sh` (https only; keystore from env, never committed). Set `ALLOWED_BUILDS=android-1.0.0` on the server to reject other clients.

## 4. Going real-money (read docs/COMPLIANCE.md first)
`STAKE_MODE=real` makes the server **refuse to start** unless: `APP_ENV=production`, `GAMING_LICENSE_REFERENCE`, `REAL_MONEY_COUNTRIES`, a non-sandbox `PAYMENT_PROVIDER` + `PAYMENT_WEBHOOK_SECRET`, `REQUIRE_KYC=true`, and a non-sandbox `KYC_PROVIDER`. Real-money bots are impossible (`bot_forbidden`).
Implement your licensed provider by subclassing `PaymentProvider` / `KycProvider` in `services/providers.py` and registering it – the wallet and game code do not change.
