# WebSocket protocol v1  (`ws(s)://host/ws`, JSON text frames)

The server is authoritative. The client sends **inputs only**; it never sends positions, hits, energy or results.

## Handshake
1. Client opens the socket and **within 8 s** sends `{"t":"auth","v":1,"token":"<session>","build":"android-1.0.0"}`.
2. Server replies `hello` (user, balance, tiers, fee_bps, mode, tick) or `error` + close (`4001` bad token, `4002` protocol, `4003` build not allowed, `4004` signed in elsewhere).
3. If the user has a live match, the server immediately re-sends `match_found` with `"resume":true` (reconnect).

## Client → Server
| t | fields | notes |
|---|---|---|
| `ping` | `c` (client clock) | answered by `pong` (RTT) |
| `queue` | `tier` (santim; `0` = practice) | compliance + balance pre-checked |
| `cancel` | – | leave the queue |
| `ready` | – | client loaded; match starts when both are ready (lobby timeout → refund) |
| `in` | `seq` (strictly increasing int), `mx,my` (-1..1), `ax,ay` (aim), `a` attack, `d` dash, `p` use power-up | 30/s. Out-of-order/replayed `seq`, NaN, bools, flood → ignored + risk score |
| `surrender` | – | forfeit |
| `rematch` / `leave` | – | on the results screen |

## Server → Client
| t | meaning |
|---|---|
| `hello` | session established |
| `queued` / `queue_cancelled` | matchmaking state |
| `match_found` | `id, you(0/1), tier, pot, fee, prize, fee_bps, opp{name,rating,bot}, rules{...}` – stakes are **already locked** |
| `countdown` `{n}` / `go` | 3-2-1 then play |
| `s` | snapshot every 2 ticks (15 Hz): `tk, left, p[2][18 fields], o[orbs], e[events], ack` |
| `opp` | opponent `connected` true/false + `grace_ms` |
| `result` | outcome, energies, prize, fee, net, balance, rating, stats, `held` (under risk review) |
| `rematch` | `offered / waiting / declined / expired / failed` |
| `cancelled` | lobby timeout – stakes refunded |
| `balance`, `pong`, `error{code,msg}`, `kicked` | – |

Snapshot player row: `[x,y,fx,fy,energy,dash,dx,dy,dcd,atk,stun,kx,ky,haste,shield,rage,inv,powerup]`.
Orb row: `[id,x,y,kind]` (0 small, 1 big, 2 shield, 3 haste, 4 rage). `ack` = last input `seq` the server applied for you.

## Netcode
* Server tick 30 Hz, snapshots 15 Hz, deterministic seeded simulation (`game/sim.py`).
* **Prediction:** client runs the same movement step (`js/sim.js`) on every input, keeps unacked inputs, and on each snapshot rewinds to the server state and replays them; the small error is blended out (hard snap if > 120 px).
* **Interpolation:** opponent and remote events are rendered ~4 ticks (≈130 ms) in the past between two snapshots.
* Input bunching is merged server-side so a one-shot (attack/dash) is never lost; a missing input repeats the last stick state.
* Disconnect: 15 s grace; no packets for 6 s counts as a dead link. Not back in time → forfeit (loser's stake goes to the winner under the normal 15 % rule). Both gone → `abandoned` → refund both.
