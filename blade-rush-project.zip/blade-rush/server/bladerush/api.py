"""REST API. Thin: validation + auth + rate limits, then delegate to services. Never edits balances directly."""
from __future__ import annotations
import hmac, time
from .config import Config
from .net.httpd import HttpError, Request, Server
from .services import auth, audit, compliance, matches, payments, wallet
from .services.providers import KYC_PROVIDERS
from .services.security import RateLimiter


def install(srv: Server, cfg: Config, db, gs):
    rl = RateLimiter()

    async def run(fn):
        import asyncio
        def call():
            with db.tx() as c: return fn(c)
        return await asyncio.to_thread(call)

    def limit(req: Request, name: str, n: int, per: float, key: str | None = None):
        if not rl.allow(f"{name}:{key or req.ip}", n, per): raise HttpError(429, "rate_limited", "Too many requests, slow down")

    async def need_user(req: Request) -> dict:
        u = await run(lambda c: auth.user_for_token(c, cfg, req.bearer))
        if not u: raise HttpError(401, "unauthorized", "Sign in required")
        req.user = u; return u

    def admin(req: Request):
        limit(req, "admin", 30, 60)
        tok = req.headers.get("x-admin-token", "")
        if not tok or not hmac.compare_digest(tok, cfg.admin_token): raise HttpError(403, "forbidden", "Admin token required")

    def wrap_errors(fn):
        async def inner(req):
            try: return await fn(req)
            except auth.AuthError as e: raise HttpError(e.status, e.code, e.msg)
            except payments.PayError as e: raise HttpError(e.status, e.code, e.msg)
            except compliance.Blocked as e: raise HttpError(403, e.code, e.msg)
            except matches.MatchError as e: raise HttpError(400, e.code, e.msg)
            except wallet.WalletError as e: raise HttpError(402, e.code, str(e))
        return inner

    def R(method, path):
        def deco(fn): srv.route(method, path, wrap_errors(fn)); return fn
        return deco

    # ---------------- public ----------------
    @R("GET", "/api/health")
    async def health(req): return {"ok": True, "mode": cfg.stake_mode, "time": int(time.time() * 1000)}

    @R("GET", "/api/config")
    async def config(req):
        return {"mode": cfg.stake_mode, "tiers": list(cfg.entry_tiers), "fee_bps": cfg.fee_bps, "min_age": cfg.min_age,
                "currency": "ETB", "minor_per_unit": 100, "require_kyc": cfg.require_kyc, "protocol": 1,
                "match_seconds": cfg.match_seconds, "target_energy": cfg.target_energy,
                "real_money_countries": list(cfg.real_money_countries) if cfg.stake_mode == "real" else [],
                "notice": ("SANDBOX: play credits only, no real money." if cfg.stake_mode == "sandbox" else
                           "Real-money play. 18+ only. Play responsibly.")}

    @R("POST", "/api/auth/register")
    async def register(req):
        limit(req, "reg", 8, 3600)
        b = req.json()
        return 200, await run(lambda c: auth.register(c, cfg, b, req.ip))

    @R("POST", "/api/auth/login")
    async def login(req):
        limit(req, "login", 10, 300)
        b = req.json(); limit(req, "loginu", 8, 300, str(b.get("username", "")).lower()[:20])
        return await run(lambda c: auth.login(c, cfg, b, req.ip))

    @R("POST", "/api/auth/logout")
    async def logout(req):
        await need_user(req); await run(lambda c: auth.logout(c, cfg, req.bearer)); return {"ok": True}

    # ---------------- player ----------------
    @R("GET", "/api/me")
    async def me(req):
        u = await need_user(req)
        def f(c):
            return {"user": auth.public_user(u), "balance": wallet.balances(c, u["id"]),
                    "limits": _limits_view(c, u["id"]), "exclusion_until": compliance.exclusion_until(c, u["id"])}
        return await run(f)

    def _limits_view(c, uid):
        l = compliance.get_limits(c, cfg, uid)
        return {"daily_stake": l["daily_stake"], "daily_loss": l["daily_loss"], "daily_deposit": l["daily_deposit"], "daily_minutes": l["daily_minutes"],
                "pending": l["pending_json"], "pending_effective_at": l["pending_effective_at"],
                "used": {"stake": compliance.staked_today(c, uid), "loss": max(0, compliance.net_loss_today(c, uid)), "minutes": round(compliance.minutes_today(c, uid), 1)}}

    @R("GET", "/api/wallet")
    async def wallet_get(req):
        u = await need_user(req)
        def f(c):
            rows = c.all("SELECT t.id, t.kind, t.match_id, t.created_at, e.amount, e.account FROM ledger_transactions t "
                         "JOIN ledger_entries e ON e.tx_id=t.id WHERE t.user_id=? AND e.account=? ORDER BY t.created_at DESC, e.id DESC LIMIT 60", (u["id"], wallet.avail(u["id"])))
            return {"balance": wallet.balances(c, u["id"]), "transactions": rows, "mode": cfg.stake_mode}
        return await run(f)

    @R("GET", "/api/matches")
    async def my_matches(req):
        u = await need_user(req)
        def f(c):
            rows = c.all("SELECT m.id, m.tier, m.status, m.winner, m.end_reason, m.e1, m.e2, m.prize, m.fee, m.p1, m.p2, m.created_at, m.ended_at, "
                         "a.username AS n1, b.username AS n2 FROM matches m JOIN users a ON a.id=m.p1 LEFT JOIN users b ON b.id=m.p2 "
                         "WHERE m.p1=? OR m.p2=? ORDER BY m.created_at DESC LIMIT 50", (u["id"], u["id"]))
            out = []
            for m in rows:
                mine = 0 if m["p1"] == u["id"] else 1
                opp = (m["n2"] if mine == 0 else m["n1"]) or ("Shadow-Bot" if m["tier"] == 0 else "House Rival")
                if m["status"] == "settled": res = "win" if m["winner"] == u["id"] else ("loss" if m["winner"] else "draw")
                elif m["status"] in ("refunded", "void"): res = "refunded"
                else: res = m["status"]
                net = 0
                if m["tier"] and m["status"] == "settled": net = (m["prize"] - m["tier"]) if m["winner"] == u["id"] else -m["tier"]
                out.append({"id": m["id"], "tier": m["tier"], "result": res, "opponent": opp, "energy": [m["e1"], m["e2"]][::(1 if mine == 0 else -1)],
                            "net": net, "reason": m["end_reason"], "at": m["created_at"]})
            return {"matches": out}
        return await run(f)

    @R("POST", "/api/wallet/deposit")
    async def deposit(req):
        u = await need_user(req); limit(req, "dep", 10, 600, u["id"])
        b = req.json(); r = await run(lambda c: payments.request_deposit(c, cfg, u["id"], b))
        await gs.push_balance(u["id"]); return r

    @R("POST", "/api/wallet/withdraw")
    async def withdraw(req):
        u = await need_user(req); limit(req, "wd", 5, 600, u["id"])
        b = req.json(); r = await run(lambda c: payments.request_withdrawal(c, cfg, u["id"], b))
        await gs.push_balance(u["id"]); return r

    @R("POST", "/api/payments/webhook")
    async def webhook(req):
        limit(req, "wh", 300, 60)
        r = await run(lambda c: payments.handle_webhook(c, cfg, req.headers, req.body))
        return r

    @R("POST", "/api/kyc/start")
    async def kyc_start(req):
        u = await need_user(req); limit(req, "kyc", 5, 3600, u["id"])
        prov = KYC_PROVIDERS.get(cfg.kyc_provider)
        if not prov: raise HttpError(503, "kyc_unavailable", "KYC provider not configured")
        res = prov().start(u)
        def f(c):
            c.execute("UPDATE users SET kyc_status=? WHERE id=? AND kyc_status<>'verified'", (res["status"], u["id"]))
            audit.log(c, f"user:{u['id']}", "kyc_started", u["id"], {"provider": cfg.kyc_provider, "status": res["status"]})
        await run(f); return res

    @R("PUT", "/api/limits")
    async def set_limits(req):
        u = await need_user(req); b = req.json()
        def f(c):
            compliance.set_limits(c, cfg, u["id"], {k: b[k] for k in ("daily_stake", "daily_loss", "daily_deposit", "daily_minutes") if isinstance(b.get(k), int) and not isinstance(b.get(k), bool)})
            return _limits_view(c, u["id"])
        return await run(f)

    @R("POST", "/api/self-exclude")
    async def self_exclude(req):
        u = await need_user(req); b = req.json()
        days = b.get("days")
        if not isinstance(days, int) or isinstance(days, bool) or not 1 <= days <= 3650: raise HttpError(400, "bad_days", "days must be 1..3650")
        until = await run(lambda c: compliance.self_exclude(c, u["id"], days)); return {"until": until}

    @R("GET", "/api/leaderboard")
    async def leaderboard(req):
        return await run(lambda c: {"top": c.all("SELECT username, rating FROM users WHERE status='active' ORDER BY rating DESC LIMIT 20")})

    # ---------------- admin (separate secret; never exposed to the game client) ----------------
    @R("GET", "/admin/reviews")
    async def reviews(req):
        admin(req)
        return await run(lambda c: {"matches": c.all("SELECT id,tier,p1,p2,winner,e1,e2,risk_score,risk_flags,ip1,ip2,created_at FROM matches WHERE status='review' ORDER BY created_at"),
                                   "events": c.all("SELECT * FROM risk_events ORDER BY id DESC LIMIT 50")})

    @R("POST", "/admin/reviews/{id}")
    async def resolve(req):
        admin(req); b = req.json()
        return await run(lambda c: matches.admin_resolve(c, cfg, req.params["id"], str(b.get("action")), "admin"))

    @R("POST", "/admin/users/{id}/kyc")
    async def admin_kyc(req):
        admin(req); b = req.json(); st = b.get("status")
        if st not in ("verified", "rejected", "pending", "none"): raise HttpError(400, "bad_status", "bad status")
        def f(c):
            c.execute("UPDATE users SET kyc_status=? WHERE id=?", (st, req.params["id"])); audit.log(c, "admin", "kyc_set", req.params["id"], {"status": st}); return {"ok": True}
        return await run(f)

    @R("POST", "/admin/users/{id}/ban")
    async def admin_ban(req):
        admin(req)
        def f(c):
            c.execute("UPDATE users SET status='banned' WHERE id=?", (req.params["id"],)); c.execute("UPDATE sessions SET revoked=1 WHERE user_id=?", (req.params["id"],))
            audit.log(c, "admin", "ban", req.params["id"], {}); return {"ok": True}
        return await run(f)

    @R("GET", "/admin/reconcile")
    async def reconcile(req):
        admin(req); return await run(lambda c: {"ledger": wallet.reconcile(c), "audit": audit.verify(c)})

    @R("GET", "/admin/stats")
    async def stats(req):
        admin(req)
        return await run(lambda c: {"live_matches": len(gs.all_matches), "connections": len(gs.conns), "queues": {str(k): len(v) for k, v in gs.queues.items()},
                                   "fees_collected": int(c.scalar("SELECT balance FROM accounts WHERE name=?", (wallet.FEE,))),
                                   "matches_total": c.scalar("SELECT COUNT(*) FROM matches")})
