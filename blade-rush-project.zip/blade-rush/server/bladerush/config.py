"""Central configuration. Every secret comes from environment variables; nothing is hardcoded."""
from __future__ import annotations
import os, secrets, sys
from dataclasses import dataclass

MINOR = 100  # 1 Birr = 100 santim. All money in the system is an integer number of santim.


def _s(n, d=""): return os.environ.get(n, d).strip()
def _i(n, d): return int(_s(n, str(d)))
def _f(n, d): return float(_s(n, str(d)))
def _b(n, d): return _s(n, str(d)).lower() in ("1", "true", "yes", "on")
def _l(n, d): return tuple(x.strip() for x in _s(n, d).split(",") if x.strip())


class ConfigError(RuntimeError):
    pass


@dataclass(frozen=True)
class Config:
    env: str; host: str; port: int; database_url: str; web_root: str
    stake_mode: str; license_reference: str; entry_tiers: tuple; fee_bps: int
    min_age: int; require_kyc: bool; real_money_countries: tuple; blocked_regions: tuple
    default_daily_loss: int; default_daily_stake: int; default_daily_deposit: int
    default_daily_play_minutes: int; limit_increase_cooldown_s: int; sandbox_start_credit: int
    payment_provider: str; kyc_provider: str
    admin_token: str; webhook_secret: str; token_pepper: str
    trust_proxy: bool; allowed_origins: tuple; allowed_builds: tuple
    block_same_ip: bool; max_pair_matches_24h: int
    match_seconds: int; target_energy: int; lobby_timeout_s: float; countdown_s: int
    reconnect_grace_s: float; rematch_window_s: float; review_threshold: int; kick_threshold: int
    session_days: int; sandbox_bot_fill_s: float; sandbox_topup_max: int

    @property
    def is_prod(self): return self.env == "production"

    @classmethod
    def from_env(cls) -> "Config":
        env = _s("APP_ENV", "development")
        mode = _s("STAKE_MODE", "sandbox")
        if mode not in ("sandbox", "real"):
            raise ConfigError("STAKE_MODE must be 'sandbox' or 'real'")
        fee = _i("PLATFORM_FEE_BPS", 1500)  # 1500 bps = 15%
        if not 0 <= fee <= 5000:
            raise ConfigError("PLATFORM_FEE_BPS must be within 0..5000")
        tiers = tuple(int(float(x) * MINOR) for x in _l("ENTRY_TIERS_BIRR", "10,25,50,100,250"))
        admin, pepper = _s("ADMIN_TOKEN"), _s("TOKEN_PEPPER")
        if env == "production":
            if len(admin) < 32 or len(pepper) < 32:
                raise ConfigError("production requires ADMIN_TOKEN and TOKEN_PEPPER of >= 32 chars")
        else:
            if not admin:
                admin = secrets.token_urlsafe(24)
                print(f"[dev] generated ephemeral ADMIN_TOKEN={admin}", file=sys.stderr)
            pepper = pepper or "dev-pepper-not-for-production"
        provider = _s("PAYMENT_PROVIDER", "sandbox")
        cfg = cls(
            env=env, host=_s("HOST", "0.0.0.0"), port=_i("PORT", 8080),
            database_url=_s("DATABASE_URL", "sqlite:///bladerush.db"),
            web_root=_s("WEB_ROOT", os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "client", "web"))),
            stake_mode=mode, license_reference=_s("GAMING_LICENSE_REFERENCE"),
            entry_tiers=tiers, fee_bps=fee, min_age=_i("MIN_AGE", 18),
            require_kyc=_b("REQUIRE_KYC", mode == "real"),
            real_money_countries=tuple(c.upper() for c in _l("REAL_MONEY_COUNTRIES", "")),
            blocked_regions=tuple(c.upper() for c in _l("BLOCKED_REGIONS", "")),
            default_daily_loss=_i("DEFAULT_DAILY_LOSS_BIRR", 2000) * MINOR,
            default_daily_stake=_i("DEFAULT_DAILY_STAKE_BIRR", 5000) * MINOR,
            default_daily_deposit=_i("DEFAULT_DAILY_DEPOSIT_BIRR", 5000) * MINOR,
            default_daily_play_minutes=_i("DEFAULT_DAILY_PLAY_MINUTES", 120),
            limit_increase_cooldown_s=_i("LIMIT_INCREASE_COOLDOWN_S", 86400),
            sandbox_start_credit=_i("SANDBOX_START_CREDIT_BIRR", 500) * MINOR,
            payment_provider=provider,
            kyc_provider=_s("KYC_PROVIDER", "sandbox" if mode == "sandbox" else "manual"),
            admin_token=admin, webhook_secret=_s("PAYMENT_WEBHOOK_SECRET"), token_pepper=pepper,
            trust_proxy=_b("TRUST_PROXY", False), allowed_origins=_l("ALLOWED_ORIGINS", ""),
            allowed_builds=_l("ALLOWED_BUILDS", ""),
            block_same_ip=_b("BLOCK_SAME_IP", env == "production"),
            max_pair_matches_24h=_i("MAX_PAIR_MATCHES_24H", 6),
            match_seconds=_i("MATCH_SECONDS", 90), target_energy=_i("TARGET_ENERGY", 100),
            lobby_timeout_s=_f("LOBBY_TIMEOUT_S", 12), countdown_s=_i("COUNTDOWN_S", 3),
            reconnect_grace_s=_f("RECONNECT_GRACE_S", 15), rematch_window_s=_f("REMATCH_WINDOW_S", 20),
            review_threshold=_i("REVIEW_THRESHOLD", 100), kick_threshold=_i("KICK_THRESHOLD", 100),
            session_days=_i("SESSION_DAYS", 30),
            sandbox_bot_fill_s=(_f("SANDBOX_BOT_FILL_S", 12) if mode == "sandbox" else 0.0),
            sandbox_topup_max=_i("SANDBOX_TOPUP_MAX_BIRR", 1000) * MINOR,
        )
        if mode == "real":
            # Hard gates: the server refuses to run real-money play without legal/payment prerequisites.
            if not cfg.is_prod: raise ConfigError("STAKE_MODE=real requires APP_ENV=production")
            if not cfg.license_reference: raise ConfigError("STAKE_MODE=real requires GAMING_LICENSE_REFERENCE (your operating licence id)")
            if provider == "sandbox": raise ConfigError("STAKE_MODE=real requires a regulated PAYMENT_PROVIDER, not 'sandbox'")
            if not cfg.real_money_countries: raise ConfigError("STAKE_MODE=real requires REAL_MONEY_COUNTRIES (jurisdictions where you are licensed)")
            if not cfg.webhook_secret: raise ConfigError("STAKE_MODE=real requires PAYMENT_WEBHOOK_SECRET")
            if not cfg.require_kyc: raise ConfigError("STAKE_MODE=real requires REQUIRE_KYC=true")
            if cfg.kyc_provider == "sandbox": raise ConfigError("STAKE_MODE=real requires a real KYC_PROVIDER")
        return cfg
