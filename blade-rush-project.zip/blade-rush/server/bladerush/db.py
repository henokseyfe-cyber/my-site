"""Database access. SQLite (dev/tests) and PostgreSQL (production) behind one small interface.
Money safety never relies on read-then-write: balance changes are single conditional UPDATEs
inside one transaction, protected by CHECK constraints and UNIQUE idempotency keys."""
from __future__ import annotations
import os, re, sqlite3, threading
from contextlib import contextmanager

_SQL = os.path.join(os.path.dirname(__file__), "sql")

# Immutability: ledger rows can be inserted, never updated or deleted.
SQLITE_TRIGGERS = [
    "CREATE TRIGGER IF NOT EXISTS ledger_entries_no_update BEFORE UPDATE ON ledger_entries BEGIN SELECT RAISE(ABORT,'ledger is immutable'); END",
    "CREATE TRIGGER IF NOT EXISTS ledger_entries_no_delete BEFORE DELETE ON ledger_entries BEGIN SELECT RAISE(ABORT,'ledger is immutable'); END",
    "CREATE TRIGGER IF NOT EXISTS ledger_tx_no_update BEFORE UPDATE ON ledger_transactions BEGIN SELECT RAISE(ABORT,'ledger is immutable'); END",
    "CREATE TRIGGER IF NOT EXISTS ledger_tx_no_delete BEFORE DELETE ON ledger_transactions BEGIN SELECT RAISE(ABORT,'ledger is immutable'); END",
    "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT,'audit log is immutable'); END",
    "CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT,'audit log is immutable'); END",
]
PG_TRIGGERS = [
    "CREATE OR REPLACE FUNCTION br_immutable() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'ledger/audit rows are immutable'; END $$ LANGUAGE plpgsql",
    "DROP TRIGGER IF EXISTS t_le ON ledger_entries", "CREATE TRIGGER t_le BEFORE UPDATE OR DELETE ON ledger_entries FOR EACH ROW EXECUTE FUNCTION br_immutable()",
    "DROP TRIGGER IF EXISTS t_lt ON ledger_transactions", "CREATE TRIGGER t_lt BEFORE UPDATE OR DELETE ON ledger_transactions FOR EACH ROW EXECUTE FUNCTION br_immutable()",
    "DROP TRIGGER IF EXISTS t_al ON audit_log", "CREATE TRIGGER t_al BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION br_immutable()",
]


def render_schema(dialect: str) -> list[str]:
    with open(os.path.join(_SQL, "schema.sql"), encoding="utf-8") as f: raw = f.read()
    raw = re.sub(r"--[^\n]*", "", raw)
    auto = "INTEGER PRIMARY KEY AUTOINCREMENT" if dialect == "sqlite" else "BIGSERIAL PRIMARY KEY"
    stmts = [s.strip() for s in raw.replace("{AUTOID}", auto).split(";") if s.strip()]
    return stmts + (SQLITE_TRIGGERS if dialect == "sqlite" else PG_TRIGGERS)


class IntegrityError(Exception):
    pass


class Conn:
    """Transaction-scoped handle. SQL uses '?' placeholders for both dialects."""
    def __init__(self, raw, dialect): self.raw, self.dialect = raw, dialect

    def _q(self, sql): return sql if self.dialect == "sqlite" else sql.replace("?", "%s")

    def execute(self, sql, params=()):
        cur = self.raw.cursor()
        try:
            params = tuple(params)
            if self.dialect == "postgres" and not params: cur.execute(sql)       # no placeholder parsing => literal % is safe
            else: cur.execute(self._q(sql), params)
        except Exception as e:  # normalise unique/check violations
            n = type(e).__name__
            if n in ("IntegrityError", "UniqueViolation", "CheckViolation", "ForeignKeyViolation"):
                raise IntegrityError(str(e)) from e
            raise
        return cur

    @staticmethod
    def _norm(v):  # PostgreSQL returns Decimal for SUM(); keep integers integers (money is integer santim)
        return int(v) if type(v).__name__ == "Decimal" and v == int(v) else v

    def one(self, sql, params=()):
        cur = self.execute(sql, params); r = cur.fetchone()
        if r is None: return None
        cols = [d[0] for d in cur.description]; return {k: self._norm(v) for k, v in zip(cols, r)}

    def all(self, sql, params=()):
        cur = self.execute(sql, params); cols = [d[0] for d in cur.description]
        return [{k: self._norm(v) for k, v in zip(cols, r)} for r in cur.fetchall()]

    def scalar(self, sql, params=(), default=0):
        cur = self.execute(sql, params); r = cur.fetchone()
        if r is None or r[0] is None: return default
        v = r[0]
        return int(v) if type(v).__name__ == "Decimal" and v == int(v) else v


class Database:
    def __init__(self, url: str):
        self.url, self._lock = url, threading.RLock()
        if url.startswith("sqlite"):
            self.dialect = "sqlite"
            path = url.split("sqlite:///", 1)[1] if "sqlite:///" in url else ":memory:"
            self.raw = sqlite3.connect(path, isolation_level=None, check_same_thread=False)
            self.raw.execute("PRAGMA foreign_keys=ON"); self.raw.execute("PRAGMA journal_mode=WAL" if path != ":memory:" else "PRAGMA journal_mode=MEMORY")
            self.raw.execute("PRAGMA busy_timeout=5000")
        elif url.startswith("postgres"):
            import psycopg  # pip install "psycopg[binary]"
            self.dialect = "postgres"
            self.raw = psycopg.connect(url, autocommit=True)
        else:
            raise ValueError("DATABASE_URL must be sqlite:/// or postgresql://")
        self._depth = 0

    def migrate(self):
        with self.tx() as c:
            for s in render_schema(self.dialect): c.execute(s)

    @contextmanager
    def tx(self):
        """One serialised ACID transaction. Re-entrant: nested calls join the outer transaction."""
        with self._lock:
            if self._depth:
                self._depth += 1
                try: yield Conn(self.raw, self.dialect)
                finally: self._depth -= 1
                return
            self.raw.cursor().execute("BEGIN IMMEDIATE" if self.dialect == "sqlite" else "BEGIN")
            self._depth = 1
            try:
                yield Conn(self.raw, self.dialect)
                self.raw.cursor().execute("COMMIT")
            except BaseException:
                self.raw.cursor().execute("ROLLBACK"); raise
            finally:
                self._depth = 0

    def close(self): self.raw.close()
