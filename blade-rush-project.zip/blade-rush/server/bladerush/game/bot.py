"""Practice-mode bot. It plays through the exact same input path as a human (no extra powers)."""
from __future__ import annotations
import math, random
from .sim import Sim, ORB_BIG


class Bot:
    def __init__(self, seed: str, level: float = 0.6):
        self.rng = random.Random("bot" + seed); self.level = level
        self.dodge_cd = 0

    def think(self, sim: Sim, me: int) -> dict:
        R, rng = sim.R, self.rng
        p, o = sim.players[me], sim.players[1 - me]
        inp = {"mx": 0.0, "my": 0.0, "a": False, "d": False, "p": False, "ax": p.fx, "ay": p.fy}
        dx, dy = o.x - p.x, o.y - p.y; dist = math.hypot(dx, dy) or 1.0
        if self.dodge_cd > 0: self.dodge_cd -= 1
        # use stored power-up when fighting
        if p.pw and dist < 200 and rng.random() < 0.1: inp["p"] = True
        # dodge incoming swing
        if 0 < o.atk <= R["windup"] and dist < R["atk_range"] + 50 and p.dcd == 0 and self.dodge_cd == 0 and rng.random() < 0.18 * self.level + 0.05:
            inp["d"] = True; self.dodge_cd = 20
            inp["mx"], inp["my"] = -dy / dist, dx / dist   # sidestep
            return inp
        # attack
        if dist < R["atk_range"] * 0.9 and p.atk == 0 and p.stun == 0 and rng.random() < 0.22 * self.level + 0.05:
            inp["a"] = True; inp["ax"], inp["ay"] = dx / dist, dy / dist
            inp["mx"], inp["my"] = dx / dist * 0.3, dy / dist * 0.3
            return inp
        # choose goal: aggressive when ahead or opponent is close, otherwise collect
        tx, ty = o.x, o.y
        if p.energy < o.energy + 10 or dist > 220:
            best = None
            for orb in sim.orbs:
                if orb[3] > 1 and p.pw: continue
                d = math.hypot(orb[1] - p.x, orb[2] - p.y) - (25 if orb[3] == ORB_BIG else 0) - (15 if orb[3] > 1 else 0)
                if best is None or d < best[0]: best = (d, orb)
            if best and (dist > 120 or p.energy < o.energy): tx, ty = best[1][1], best[1][2]
        gx, gy = tx - p.x, ty - p.y; gd = math.hypot(gx, gy) or 1.0
        s = 0.85 + 0.15 * self.level
        inp["mx"], inp["my"] = gx / gd * s, gy / gd * s
        # keep out of the opponent's swing arc while it winds up
        if 0 < o.atk <= R["windup"] and dist < R["atk_range"] + 40:
            inp["mx"], inp["my"] = -dx / dist, -dy / dist
        return inp
