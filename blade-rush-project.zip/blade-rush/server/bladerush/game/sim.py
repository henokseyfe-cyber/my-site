"""Authoritative Blade Rush simulation. Pure, deterministic (seeded), no I/O.

The *movement* part (step_player) is mirrored 1:1 in client/web/js/sim.js for client-side prediction.
Everything that decides outcomes (hits, orbs, energy, power-ups, win) exists ONLY here.
"""
from __future__ import annotations
import math, random

RULES = {
    "tick": 30, "arena": 800, "player_r": 18, "orb_r": 10,
    "speed": 250.0, "haste_mult": 1.4, "atk_move_mult": 0.45,
    "dash_ticks": 5, "dash_speed": 720.0, "dash_cd": 54,
    "windup": 5, "recover": 10, "atk_range": 78.0, "atk_cos": 0.42,   # cos(65deg)
    "steal": 8, "rage_mult": 1.5, "stun_ticks": 6, "knock": 420.0, "knock_decay": 0.8, "inv_ticks": 12,
    "block_stun": 10, "shield_ticks": 90, "haste_ticks": 120, "rage_ticks": 150,
    "orb_small": 3, "orb_big": 15, "orb_every": 60, "orb_max": 10,
    "big_orb_ticks": [450, 1200, 1950], "pu_ticks": [300, 840, 1380, 1920],
    "pillars": [[250, 250, 34], [550, 250, 34], [250, 550, 34], [550, 550, 34]],
    "snap_every": 2,
}
ORB_SMALL, ORB_BIG, PU_SHIELD, PU_HASTE, PU_RAGE = 0, 1, 2, 3, 4
PU_TYPES = (PU_SHIELD, PU_HASTE, PU_RAGE)


def make_rules(match_seconds=90, target=100) -> dict:
    r = dict(RULES); r["match_ticks"] = int(match_seconds * r["tick"]); r["target"] = target
    return r


class Player:
    __slots__ = ("x", "y", "fx", "fy", "dash", "dx", "dy", "dcd", "atk", "stun", "kx", "ky", "haste",
                 "shield", "rage", "inv", "pw", "energy", "stats")

    def __init__(self, x, y, fx, fy):
        self.x, self.y, self.fx, self.fy = x, y, fx, fy
        self.dash = self.dcd = self.atk = self.stun = self.haste = self.shield = self.rage = self.inv = self.pw = 0
        self.dx = self.dy = self.kx = self.ky = 0.0
        self.energy = 0
        self.stats = dict(swings=0, hits=0, taken=0, blocks=0, dodges=0, orbs=0, dashes=0, powerups=0,
                          dist=0.0, idle=0, stolen=0)


def norm_input(inp):
    mx, my = float(inp.get("mx", 0)), float(inp.get("my", 0))
    m = math.hypot(mx, my)
    if m < 0.12: return 0.0, 0.0, 0.0
    if m > 1.0: mx, my, m = mx / m, my / m, 1.0
    return mx, my, m


def resolve_static(p, R):
    r, a = R["player_r"], R["arena"]
    p.x = min(max(p.x, r), a - r); p.y = min(max(p.y, r), a - r)
    for ox, oy, orad in R["pillars"]:
        dx, dy = p.x - ox, p.y - oy
        d = math.hypot(dx, dy); mn = orad + r
        if d < mn:
            if d < 1e-6: dx, dy, d = 1.0, 0.0, 1.0
            p.x = ox + dx / d * mn; p.y = oy + dy / d * mn
    p.x = min(max(p.x, r), a - r); p.y = min(max(p.y, r), a - r)


def step_player(p: Player, inp: dict, R: dict) -> None:
    """One tick of movement/dash/attack-state for one player. Mirrored in sim.js — keep in sync."""
    dt = 1.0 / R["tick"]
    ox, oy = p.x, p.y
    hasting = p.haste > 0
    if p.haste > 0: p.haste -= 1
    if p.dcd > 0: p.dcd -= 1
    if p.stun > 0:
        p.stun -= 1
        p.x += p.kx * dt; p.y += p.ky * dt
        p.kx *= R["knock_decay"]; p.ky *= R["knock_decay"]
        resolve_static(p, R); p.stats["dist"] += math.hypot(p.x - ox, p.y - oy)
        return
    mx, my, m = norm_input(inp)
    if p.atk > 0:
        p.atk += 1
        if p.atk > R["windup"] + R["recover"]: p.atk = 0
    if inp.get("d") and p.dash == 0 and p.dcd == 0 and (p.atk == 0 or p.atk > R["windup"]):
        p.atk = 0; p.dash = R["dash_ticks"]; p.dcd = R["dash_cd"]
        if m > 0: p.dx, p.dy = mx / m, my / m
        else: p.dx, p.dy = p.fx, p.fy
        p.fx, p.fy = p.dx, p.dy
        p.stats["dashes"] += 1
    elif inp.get("a") and p.atk == 0 and p.dash == 0:
        ax, ay = float(inp.get("ax", 0)), float(inp.get("ay", 0))
        am = math.hypot(ax, ay)
        if am > 1e-6: p.fx, p.fy = ax / am, ay / am
        p.atk = 1
        p.stats["swings"] += 1
    if p.dash > 0:
        p.x += p.dx * R["dash_speed"] * dt; p.y += p.dy * R["dash_speed"] * dt; p.dash -= 1
    else:
        sp = R["speed"] * (R["haste_mult"] if hasting else 1.0) * (R["atk_move_mult"] if p.atk > 0 else 1.0)
        p.x += mx * sp * dt; p.y += my * sp * dt
        if m > 0 and p.atk == 0:
            p.fx, p.fy = mx / m, my / m
    resolve_static(p, R)
    p.stats["dist"] += math.hypot(p.x - ox, p.y - oy)
    if m == 0 and not p.dash and not p.atk: p.stats["idle"] += 1


class Sim:
    def __init__(self, seed: str, R: dict):
        self.R = R
        self.rng = random.Random(seed)
        a = R["arena"]
        self.players = [Player(150.0, a / 2, 1.0, 0.0), Player(a - 150.0, a / 2, -1.0, 0.0)]
        self.orbs: list[list] = []     # [id, x, y, kind]
        self._oid = 0
        self.tick = 0
        self.events: list[dict] = []
        self.log = {"swings": [[], []], "dashes": [[], []]}   # tick lists for anti-cheat analysis
        self.finished = False
        self.winner: int | None = None     # 0|1|None(draw)
        self.reason = ""
        self._spawn_pair(ORB_SMALL); self._spawn_pair(ORB_SMALL); self._spawn_pair(ORB_SMALL)

    # ---- spawning (always mirrored through the arena centre => perfectly fair) ----
    def _free(self, x, y):
        for ox, oy, orad in self.R["pillars"]:
            if math.hypot(x - ox, y - oy) < orad + 36: return False
        return True

    def _add_orb(self, x, y, kind):
        self._oid += 1; self.orbs.append([self._oid, round(x, 1), round(y, 1), kind])

    def _spawn_pair(self, kind):
        a = self.R["arena"]
        for _ in range(40):
            x, y = self.rng.uniform(60, a - 60), self.rng.uniform(60, a - 60)
            if self._free(x, y) and math.hypot(x - a / 2, y - a / 2) > 90: break
        else:
            x, y = 120.0, 400.0
        self._add_orb(x, y, kind); self._add_orb(a - x, a - y, kind)

    def _spawn_schedule(self):
        R, t = self.R, self.tick
        if t % R["orb_every"] == 0 and sum(1 for o in self.orbs if o[3] == ORB_SMALL) < R["orb_max"]:
            self._spawn_pair(ORB_SMALL)
        if t in R["big_orb_ticks"]: self._add_orb(R["arena"] / 2, R["arena"] / 2, ORB_BIG)
        if t in R["pu_ticks"]: self._spawn_pair(self.rng.choice(PU_TYPES))

    # ---- one authoritative tick ----
    def step(self, inputs: list[dict]) -> None:
        if self.finished: return
        R = self.R
        for i, p in enumerate(self.players):
            inp = inputs[i]
            was_dash = p.dash
            step_player(p, inp, R)
            if p.dash and not was_dash:
                self.events.append({"k": "dash", "i": i}); self.log["dashes"][i].append(self.tick)
            if p.atk == 1:
                self.events.append({"k": "swing", "i": i, "fx": round(p.fx, 3), "fy": round(p.fy, 3)})
                self.log["swings"][i].append(self.tick)
            if inp.get("p") and p.pw and p.stun == 0: self._use_powerup(i)
        self._separate()
        for i, p in enumerate(self.players):
            if p.atk == R["windup"]: self._resolve_attack(i)
        self._collect()
        for p in self.players:
            if p.inv > 0: p.inv -= 1
            if p.shield > 0: p.shield -= 1
            if p.rage > 0: p.rage -= 1
        self.tick += 1
        self._spawn_schedule()
        self._check_end()

    def _separate(self):
        a, b = self.players; r2 = self.R["player_r"] * 2
        dx, dy = b.x - a.x, b.y - a.y; d = math.hypot(dx, dy)
        if d < r2 and a.dash == 0 and b.dash == 0:
            if d < 1e-6: dx, dy, d = 1.0, 0.0, 1.0
            push = (r2 - d) / 2
            a.x -= dx / d * push; a.y -= dy / d * push; b.x += dx / d * push; b.y += dy / d * push
            resolve_static(a, self.R); resolve_static(b, self.R)

    def _use_powerup(self, i):
        p, R = self.players[i], self.R
        kind = p.pw; p.pw = 0
        if kind == PU_SHIELD: p.shield = R["shield_ticks"]
        elif kind == PU_HASTE: p.haste = R["haste_ticks"]
        elif kind == PU_RAGE: p.rage = R["rage_ticks"]
        p.stats["powerups"] += 1
        self.events.append({"k": "use", "i": i, "t": kind})

    def _resolve_attack(self, i):
        R = self.R; a, b = self.players[i], self.players[1 - i]
        dx, dy = b.x - a.x, b.y - a.y; d = math.hypot(dx, dy)
        if d > R["atk_range"] + R["player_r"]: return
        if d > 1e-6 and (dx / d * a.fx + dy / d * a.fy) < R["atk_cos"]: return
        j = 1 - i; ux, uy = (dx / d, dy / d) if d > 1e-6 else (a.fx, a.fy)
        if b.dash > 0:
            b.stats["dodges"] += 1
            self.events.append({"k": "dodge", "i": j, "x": round(b.x, 1), "y": round(b.y, 1)}); return
        if b.shield > 0:
            b.shield = 0; b.stats["blocks"] += 1
            a.atk = R["windup"] + 1; a.stun = R["block_stun"]; a.kx, a.ky = -ux * R["knock"] * 0.6, -uy * R["knock"] * 0.6
            self.events.append({"k": "block", "i": j, "x": round(b.x, 1), "y": round(b.y, 1)}); return
        if b.inv > 0: return
        mult = R["rage_mult"] if a.rage > 0 else 1.0
        amt = min(int(round(R["steal"] * mult)), b.energy)
        b.energy -= amt; a.energy += amt
        b.stun = R["stun_ticks"]; b.atk = 0; b.dash = 0
        b.kx, b.ky = ux * R["knock"], uy * R["knock"]; b.inv = R["inv_ticks"]
        a.stats["hits"] += 1; a.stats["stolen"] += amt; b.stats["taken"] += 1
        self.events.append({"k": "hit", "a": i, "b": j, "amt": amt, "x": round(b.x, 1), "y": round(b.y, 1)})

    def _collect(self):
        R = self.R; reach = R["player_r"] + R["orb_r"]; keep = []
        for o in self.orbs:
            taker = None
            # nearest player wins ties; a power-up is skipped if the slot is full
            best = None
            for i, p in enumerate(self.players):
                d = math.hypot(p.x - o[1], p.y - o[2])
                if d <= reach and (best is None or d < best[0]): best = (d, i)
            if best:
                i = best[1]; p = self.players[i]; kind = o[3]
                if kind in (ORB_SMALL, ORB_BIG):
                    v = R["orb_small"] if kind == ORB_SMALL else R["orb_big"]
                    p.energy += v; p.stats["orbs"] += 1
                    self.events.append({"k": "orb", "i": i, "v": v, "x": o[1], "y": o[2]}); continue
                if p.pw == 0:
                    p.pw = kind
                    self.events.append({"k": "pu", "i": i, "t": kind, "x": o[1], "y": o[2]}); continue
            keep.append(o)
        self.orbs = keep

    def _check_end(self):
        R = self.R; e0, e1 = self.players[0].energy, self.players[1].energy
        if e0 >= R["target"] or e1 >= R["target"]:
            self._finish(0 if e0 > e1 else 1 if e1 > e0 else None, "target")
        elif self.tick >= R["match_ticks"]:
            self._finish(0 if e0 > e1 else 1 if e1 > e0 else None, "time")

    def _finish(self, winner, reason):
        self.finished, self.winner, self.reason = True, winner, reason
        self.events.append({"k": "end", "w": winner, "r": reason})

    def forfeit(self, loser: int):
        if not self.finished: self._finish(1 - loser, "forfeit")

    # ---- wire format ----
    def snapshot(self) -> dict:
        def pj(p: Player):
            return [round(p.x, 2), round(p.y, 2), round(p.fx, 3), round(p.fy, 3), p.energy, p.dash,
                    round(p.dx, 3), round(p.dy, 3), p.dcd, p.atk, p.stun, round(p.kx, 1), round(p.ky, 1),
                    p.haste, p.shield, p.rage, p.inv, p.pw]
        ev, self.events = self.events, []
        return {"t": "s", "tk": self.tick, "left": max(0, self.R["match_ticks"] - self.tick),
                "p": [pj(p) for p in self.players], "o": self.orbs, "e": ev}
