"""Entry point: python -m bladerush.main"""
from __future__ import annotations
import asyncio, signal, sys
from .api import install
from .config import Config, ConfigError
from .db import Database
from .net.gameserver import GameServer
from .net.httpd import Server
from .services import wallet


async def serve(cfg: Config | None = None, db: Database | None = None, ready: asyncio.Event | None = None):
    cfg = cfg or Config.from_env()
    db = db or Database(cfg.database_url); db.migrate()
    gs = GameServer(cfg, db)
    srv = Server(cfg, gs.handle_ws)
    install(srv, cfg, db, gs)
    await gs.start()
    s = await srv.start()
    print(f"Blade Rush server on {cfg.host}:{cfg.port}  mode={cfg.stake_mode}  env={cfg.env}  fee={cfg.fee_bps/100:.2f}%  tiers={[t//100 for t in cfg.entry_tiers]}", flush=True)
    if ready: ready.set()
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try: asyncio.get_running_loop().add_signal_handler(sig, stop.set)
        except (NotImplementedError, RuntimeError): pass
    try: await stop.wait()
    except asyncio.CancelledError: pass
    finally:
        print("shutting down: refunding in-flight matches...", flush=True)
        await gs.stop(); s.close(); db.close()


def main():
    try: asyncio.run(serve())
    except ConfigError as e:
        print(f"CONFIG ERROR: {e}", file=sys.stderr); sys.exit(2)


if __name__ == "__main__":
    main()
