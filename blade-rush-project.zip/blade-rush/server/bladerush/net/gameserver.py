"""Real-time game server: WebSocket sessions, matchmaking, authoritative match runner, reconnect, rematch.

WebSocket protocol v1 (JSON text frames, see docs/PROTOCOL.md):
  C->S  auth | ping | queue | cancel | ready | in | rematch | leave | surrender
  S->C  hello | queued | match_found | countdown | go | s (snapshot) | opp | result | rematch | balance | error | pong | kicked
"""
from __future__ import annotations
import asyncio, collections, json, math, time, traceback
from ..config import Config
from ..db import Database
from ..game import sim as simmod
from ..game.bot import Bot
from ..services import auth, audit, compliance, matches, risk, wallet
from ..services.matches import BOT_ID, MatchError

PROTOCOL = 1
MAX_CONNS_PER_IP = 8
TICK = 30


def dumps(o): return json.dumps(o, separators=(",", ":"))


class Conn:
    def __init__(self, ws, ip):
        self.ws, self.ip = ws, ip
        self.user: dict | None = None
        self.match: "Match | None" = None
        self.slot: int = -1
        self.queued_tier: int | None = None
        self.last_rx = time.monotonic()
        self.guard = risk.LiveGuard()
        self.alive = True

    def send(self, obj): self.ws.send_nowait(dumps(obj))
    def err(self, code, msg): self.send({"t": "error", "code": code, "msg": msg})


class Slot:
    def __init__(self, uid, name, rating, bot=False, ip=None):
        self.uid, self.name, self.rating, self.bot, self.ip = uid, name, rating, bot, ip
        self.conn: Conn | None = None
        self.q: collections.deque = collections.deque(maxlen=10)
        self.last: dict = {"mx": 0.0, "my": 0.0, "ax": 1.0, "ay": 0.0}
        self.ack = 0
        self.ready = bot
        self.disc_at: float | None = None
        self.disc_count = 0
        self.guard = risk.LiveGuard()
        self.surrender = False
        self.rematch = False
        self.left = False
        self.result_msg: dict | None = None

    @property
    def connected(self): return self.bot or (self.conn is not None and self.conn.alive and not self.conn.ws.closed)

    def next_input(self) -> dict:
        """One input per tick. If the network bunched packets up, merge the extras so no one-shot (attack/dash/power) is lost."""
        if not self.q:
            return {"mx": self.last["mx"], "my": self.last["my"], "ax": self.last["ax"], "ay": self.last["ay"]}
        inp = self.q.popleft()
        while len(self.q) > 2:
            nx = self.q.popleft()
            nx["a"] = nx["a"] or inp["a"]; nx["d"] = nx["d"] or inp["d"]; nx["p"] = nx["p"] or inp["p"]
            inp = nx
        self.ack = inp["seq"]; self.last = inp
        return inp


class Match:
    def __init__(self, gs: "GameServer", info: dict, slots: list[Slot]):
        self.gs, self.cfg, self.info, self.slots = gs, gs.cfg, info, slots
        self.id, self.tier = info["id"], info["tier"]
        self.R = simmod.make_rules(gs.cfg.match_seconds, gs.cfg.target_energy)
        self.sim = simmod.Sim(info["seed"], self.R)
        self.bot = Bot(info["seed"], 0.55) if any(s.bot for s in slots) else None
        self.phase = "lobby"
        self.task: asyncio.Task | None = None
        self.result: dict | None = None

    def humans(self): return [(i, s) for i, s in enumerate(self.slots) if not s.bot]

    def send(self, i, obj):
        c = self.slots[i].conn
        if c and c.alive: c.send(obj)

    def bcast(self, obj):
        for i, _ in self.humans(): self.send(i, obj)

    def found_payload(self, i):
        o = self.slots[1 - i]
        pot, fee, prize = wallet.split_pot(self.tier, self.info["fee_bps"]) if self.tier else (0, 0, 0)
        return {"t": "match_found", "id": self.id, "you": i, "tier": self.tier, "pot": pot, "fee": fee, "prize": prize,
                "fee_bps": self.info["fee_bps"], "opp": {"name": o.name, "rating": o.rating, "bot": o.bot},
                "me": {"name": self.slots[i].name, "rating": self.slots[i].rating},
                "rules": dict(self.R), "phase": self.phase, "lobby_ms": int(self.cfg.lobby_timeout_s * 1000)}

    def start(self): self.task = asyncio.create_task(self._guarded())

    async def _guarded(self):
        try:
            await self.run()
        except asyncio.CancelledError:
            await self._safe_refund("server_shutdown"); raise
        except Exception:
            traceback.print_exc()
            await self._safe_refund("server_error")
            self.bcast({"t": "error", "code": "server_error", "msg": "Match aborted, stakes refunded"})
        finally:
            self.phase = "closed"
            self.gs.release(self)

    async def _safe_refund(self, reason):
        try: await self.gs.run_db(lambda c: matches.refund(c, self.id, reason))
        except Exception: traceback.print_exc()
        for _, s in self.humans(): await self.gs.push_balance(s.uid)

    async def run(self):
        gs = self.gs
        for i, _ in self.humans(): self.send(i, self.found_payload(i))
        deadline = time.monotonic() + self.cfg.lobby_timeout_s
        while not all(s.ready and s.connected for s in self.slots):
            if time.monotonic() > deadline:
                await self._safe_refund("lobby_timeout")
                self.bcast({"t": "cancelled", "id": self.id, "reason": "opponent_unavailable", "tier": self.tier})
                await gs.run_db(lambda c: audit.log(c, "system:match", "lobby_timeout", self.id, {}))
                return
            await asyncio.sleep(0.1)
        self.phase = "countdown"
        await gs.run_db(lambda c: matches.mark_playing(c, self.id))
        for n in range(self.cfg.countdown_s, 0, -1):
            self.bcast({"t": "countdown", "n": n}); await asyncio.sleep(1.0)
        self.bcast({"t": "go"})
        self.phase = "playing"
        await self.play_loop()
        self.phase = "settling"
        await self.finish()
        self.phase = "results"
        await self.rematch_window()

    async def play_loop(self):
        sim, R, cfg = self.sim, self.R, self.cfg
        loop = asyncio.get_running_loop(); dt = 1.0 / TICK
        nxt = loop.time()
        while not sim.finished:
            now = time.monotonic()
            gone = []
            for i, s in enumerate(self.slots):
                if s.bot: continue
                if s.conn and s.conn.alive and now - s.conn.last_rx > 6.0:    # silent link => treat as disconnected
                    s.conn.alive = False
                    try: s.conn.ws.w.close()
                    except Exception: pass
                if not s.connected and s.disc_at is None:
                    s.disc_at = now; s.disc_count += 1
                    self.send(1 - i, {"t": "opp", "connected": False, "grace_ms": int(cfg.reconnect_grace_s * 1000)})
                if s.connected and s.disc_at is not None:
                    s.disc_at = None; self.send(1 - i, {"t": "opp", "connected": True})
                if s.surrender or (s.disc_at is not None and now - s.disc_at > cfg.reconnect_grace_s): gone.append(i)
            if len(gone) == 2:
                sim.finished, sim.winner, sim.reason = True, None, "abandoned"; break
            if gone:
                sim.forfeit(gone[0])
            else:
                ins = []
                for i, s in enumerate(self.slots):
                    if s.bot: ins.append(self.bot.think(sim, i))
                    elif not s.connected: ins.append({"mx": 0.0, "my": 0.0, "ax": s.last["ax"], "ay": s.last["ay"]})
                    else: ins.append(s.next_input())
                sim.step(ins)
            if sim.tick % R["snap_every"] == 0 or sim.finished: self.broadcast_snapshot()
            nxt += dt
            lag = nxt - loop.time()
            if lag > 0: await asyncio.sleep(lag)
            elif lag < -0.25: nxt = loop.time()       # overloaded: drop catch-up instead of spiralling

    def broadcast_snapshot(self):
        snap = self.sim.snapshot()
        for _, s in self.humans():
            if s.conn and s.conn.alive:
                snap["ack"] = s.ack
                s.conn.send(snap)

    async def finish(self):
        gs, sim = self.gs, self.sim
        seconds = int(sim.tick / TICK)
        e1, e2 = sim.players[0].energy, sim.players[1].energy
        res = {"winner": sim.winner, "reason": sim.reason, "e1": e1, "e2": e2, "seconds": seconds}
        meta = {"tier": self.tier, "practice": self.tier == 0, "bots": [s.bot for s in self.slots],
                "ips": [s.ip for s in self.slots], "guards": [s.guard for s in self.slots],
                "disconnects": [s.disc_count for s in self.slots], "pair_limit": self.cfg.max_pair_matches_24h}

        def work(c):
            if sim.reason == "abandoned":
                matches.refund(c, self.id, "abandoned")
                return matches._public(c, self.id), {"flags": [], "score": 0}
            if not any(s.bot for s in self.slots):
                meta["pair_recent"] = matches.pair_recent(c, self.slots[0].uid, self.slots[1].uid) - 1
            an = risk.analyse_match(sim, meta)
            return matches.settle(c, self.cfg, self.id, res, an), an
        try:
            final, an = await gs.run_db(work)
        except Exception:
            traceback.print_exc(); await self._safe_refund("settle_error")
            final, an = {"status": "refunded", "prize": 0, "fee": 0}, {"score": 0, "flags": []}
        w = sim.winner
        self.result = {"final": final, "score": an["score"]}
        status = final["status"]
        for i, s in self.humans():
            me = sim.players[i]
            if w is None or status == "refunded": outcome = "draw"
            else: outcome = "win" if w == i else "loss"
            net = 0
            if status == "settled" and self.tier and w is not None:
                net = (final["prize"] - self.tier) if w == i else -self.tier
            bal, rating = await gs.run_db(lambda c, u=s.uid: (wallet.balances(c, u), c.scalar("SELECT rating FROM users WHERE id=?", (u,), 1000)))
            s.result_msg = {"t": "result", "id": self.id, "tier": self.tier, "status": status, "outcome": outcome,
                            "reason": sim.reason, "energy": [e1, e2], "you": i,
                            "prize": final.get("prize", 0) if outcome == "win" else 0, "fee": final.get("fee", 0), "net": net,
                            "held": status == "review", "balance": bal, "rating": rating,
                            "stats": {k: me.stats[k] for k in ("hits", "orbs", "dodges", "blocks", "stolen", "taken")},
                            "rematch_ms": int(self.cfg.rematch_window_s * 1000)}
            self.send(i, s.result_msg)

    async def rematch_window(self):
        end = time.monotonic() + self.cfg.rematch_window_s
        hs = [s for _, s in self.humans()]
        while time.monotonic() < end:
            if all(s.rematch for s in hs) or any(s.left for s in hs): break
            if all(not s.connected for s in hs): return
            await asyncio.sleep(0.15)
        ok = (all(s.rematch for s in hs) and not any(s.left for s in hs) and all(s.connected for s in hs)
              and self.result["final"]["status"] in ("settled", "refunded"))
        if ok:
            await self.gs.start_rematch(self)
        else:
            for i, _ in self.humans(): self.send(i, {"t": "rematch", "state": "expired"})


class GameServer:
    def __init__(self, cfg: Config, db: Database):
        self.cfg, self.db = cfg, db
        self.conns: dict[str, Conn] = {}
        self.ip_count: collections.Counter = collections.Counter()
        self.queues: dict[int, list[dict]] = {t: [] for t in (0, *cfg.entry_tiers)}
        self.active: dict[str, Match] = {}
        self.all_matches: set[Match] = set()
        self.mm_task: asyncio.Task | None = None
        self.stats = {"matches": 0, "connections": 0}

    async def run_db(self, fn):
        def call():
            with self.db.tx() as c: return fn(c)
        return await asyncio.to_thread(call)

    async def start(self):
        refunded = await self.run_db(matches.recover_after_crash)
        if refunded: print(f"[recover] refunded {len(refunded)} interrupted matches")
        self.mm_task = asyncio.create_task(self.matchmaker())

    async def stop(self):
        if self.mm_task: self.mm_task.cancel()
        tasks = [m.task for m in self.all_matches if m.task]
        for t in tasks: t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    def release(self, m: Match):
        for s in m.slots:
            if self.active.get(s.uid) is m: del self.active[s.uid]
        for _, s in m.humans():
            if s.conn and s.conn.match is m: s.conn.match, s.conn.slot = None, -1
        self.all_matches.discard(m)

    async def push_balance(self, uid):
        c = self.conns.get(uid)
        if c and c.alive:
            b = await self.run_db(lambda cn: wallet.balances(cn, uid)); c.send({"t": "balance", **b})

    # ---------- websocket session ----------
    async def handle_ws(self, ws):
        ip = ws.peer; conn = Conn(ws, ip)
        if self.ip_count[ip] >= MAX_CONNS_PER_IP:
            return await ws.close(1013, "too many connections")
        self.ip_count[ip] += 1; self.stats["connections"] += 1
        try:
            if not await self._auth(conn): return
            while conn.alive:
                try: raw = await asyncio.wait_for(ws.recv(), 25)
                except asyncio.TimeoutError: break
                conn.last_rx = time.monotonic()
                if not conn.guard.on_message(): continue
                await self._on_message(conn, raw)
        except Exception as e:
            if type(e).__name__ != "WSClosed": traceback.print_exc()
        finally:
            self.ip_count[ip] -= 1
            await self._cleanup(conn)

    async def _auth(self, conn: Conn) -> bool:
        ws = conn.ws
        try: msg = json.loads(await asyncio.wait_for(ws.recv(), 8))
        except Exception:
            await ws.close(4000, "auth required"); return False
        if not isinstance(msg, dict) or msg.get("t") != "auth":
            await ws.close(4000, "auth required"); return False
        if msg.get("v") != PROTOCOL:
            conn.err("bad_protocol", "Please update the app"); await ws.close(4002, "protocol"); return False
        if self.cfg.allowed_builds and str(msg.get("build", "")) not in self.cfg.allowed_builds:
            conn.err("bad_build", "This app version is not allowed. Please update."); await ws.close(4003, "build"); return False
        user = await self.run_db(lambda c: auth.user_for_token(c, self.cfg, str(msg.get("token", ""))))
        if not user:
            conn.err("unauthorized", "Please sign in again"); await ws.close(4001, "unauthorized"); return False
        conn.user = user; uid = user["id"]
        old = self.conns.get(uid)
        if old is not None and old is not conn:
            old.send({"t": "kicked", "reason": "signed_in_elsewhere"})
            await self._detach(old); old.alive = False
            try: await old.ws.close(4004, "replaced")
            except Exception: pass
        self.conns[uid] = conn
        bal = await self.run_db(lambda c: wallet.balances(c, uid))
        conn.send({"t": "hello", "protocol": PROTOCOL, "user": auth.public_user(user), "balance": bal,
                   "tiers": list(self.cfg.entry_tiers), "fee_bps": self.cfg.fee_bps, "mode": self.cfg.stake_mode,
                   "tick": TICK, "server_ms": int(time.time() * 1000)})
        m = self.active.get(uid)
        if m and m.phase != "closed":
            for i, s in enumerate(m.slots):
                if s.uid == uid:
                    s.conn, conn.match, conn.slot = conn, m, i
                    s.q.clear()
                    if m.phase == "results" and s.result_msg:
                        conn.send(s.result_msg)
                    else:
                        p = m.found_payload(i); p["phase"] = m.phase; p["resume"] = True; p["seq"] = s.guard.last_seq; conn.send(p)
                    break
        return True

    async def _detach(self, conn: Conn):
        m = conn.match
        if m and 0 <= conn.slot < 2 and m.slots[conn.slot].conn is conn: m.slots[conn.slot].conn = None
        self._dequeue(conn)

    async def _cleanup(self, conn: Conn):
        conn.alive = False
        if conn.user and self.conns.get(conn.user["id"]) is conn: del self.conns[conn.user["id"]]
        await self._detach(conn)
        try: await conn.ws.close()
        except Exception: pass

    # ---------- inbound ----------
    async def _on_message(self, conn: Conn, raw: str):
        try:
            msg = json.loads(raw)
            t = msg["t"]
            if not isinstance(t, str): raise ValueError
        except Exception:
            conn.guard.hit("bad_packet"); return
        m = conn.match
        if t == "in":
            if not m or m.phase not in ("playing", "countdown"): return
            s = m.slots[conn.slot]
            inp = self._clean_input(msg, s)
            if inp is None: return
            if len(s.q) == s.q.maxlen: s.guard.hit("queue_overflow")
            s.q.append(inp)
        elif t == "ping":
            conn.send({"t": "pong", "c": msg.get("c"), "s": int(time.time() * 1000)})
        elif t == "queue":
            await self._on_queue(conn, msg.get("tier"))
        elif t == "cancel":
            self._dequeue(conn); conn.send({"t": "queue_cancelled"})
        elif t == "ready":
            if m and m.phase == "lobby": m.slots[conn.slot].ready = True
        elif t == "surrender":
            if m and m.phase == "playing": m.slots[conn.slot].surrender = True
        elif t == "rematch":
            if m and m.phase == "results":
                m.slots[conn.slot].rematch = True
                other = m.slots[1 - conn.slot]
                if other.bot: other.rematch = True
                else: m.send(1 - conn.slot, {"t": "rematch", "state": "offered"})
                conn.send({"t": "rematch", "state": "waiting"})
        elif t == "leave":
            if m and m.phase == "results":
                m.slots[conn.slot].left = True
                m.send(1 - conn.slot, {"t": "rematch", "state": "declined"})
                conn.match, conn.slot = None, -1
        else:
            conn.guard.hit("unknown_type")

    @staticmethod
    def _num(v, lo, hi):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v): raise ValueError
        return max(lo, min(hi, float(v)))

    def _clean_input(self, msg, s: Slot):
        try:
            seq = msg["seq"]
            if not s.guard.check_seq(seq): return None
            mx, my = self._num(msg.get("mx", 0), -2, 2), self._num(msg.get("my", 0), -2, 2)
            if math.hypot(mx, my) > 1.05: s.guard.hit("over_speed_input")   # sim normalises it anyway: speed can't be gained
            return {"seq": seq, "mx": mx, "my": my, "a": msg.get("a") is True, "d": msg.get("d") is True, "p": msg.get("p") is True,
                    "ax": self._num(msg.get("ax", 0), -1.5, 1.5), "ay": self._num(msg.get("ay", 0), -1.5, 1.5)}
        except (KeyError, ValueError, TypeError):
            s.guard.hit("bad_packet"); return None

    # ---------- matchmaking ----------
    def _dequeue(self, conn: Conn):
        if conn.queued_tier is None: return
        self.queues[conn.queued_tier] = [e for e in self.queues[conn.queued_tier] if e["conn"] is not conn]
        conn.queued_tier = None

    async def _on_queue(self, conn: Conn, tier):
        uid = conn.user["id"]
        if conn.match is not None and conn.match.phase != "closed": return conn.err("in_match", "Finish your current match first")
        if conn.queued_tier is not None: return conn.err("already_queued", "Already searching")
        if not isinstance(tier, int) or isinstance(tier, bool) or tier not in self.queues: return conn.err("bad_tier", "Unknown entry tier")

        def pre(c):
            compliance.check_can_play(c, self.cfg, uid, tier)
            if tier and wallet.balances(c, uid)["available"] < tier: raise compliance.Blocked("insufficient_funds", "Not enough balance for this entry")
            return c.one("SELECT rating FROM users WHERE id=?", (uid,))["rating"]
        try: rating = await self.run_db(pre)
        except compliance.Blocked as e: return conn.err(e.code, e.msg)
        if tier == 0: return await self._start(0, [(conn, rating), None])
        conn.queued_tier = tier
        self.queues[tier].append({"conn": conn, "uid": uid, "rating": rating, "since": time.monotonic(), "ip": conn.ip})
        conn.send({"t": "queued", "tier": tier})

    async def matchmaker(self):
        while True:
            try:
                await asyncio.sleep(0.5)
                for tier, q in self.queues.items():
                    if tier == 0 or not q: continue
                    self.queues[tier] = [e for e in q if e["conn"].alive]
                    await self._match_tier(tier)
            except asyncio.CancelledError: raise
            except Exception: traceback.print_exc()

    async def _match_tier(self, tier):
        """Rating-window matchmaking: window widens with wait time. Oldest ticket first."""
        now = time.monotonic(); q = sorted(self.queues[tier], key=lambda e: e["since"])
        for a in q:
            window_a = 150 + 75 * (now - a["since"])
            for b in q:
                if b is a or a["uid"] == b["uid"]: continue
                window = max(window_a, 150 + 75 * (now - b["since"]))
                if abs(a["rating"] - b["rating"]) > window: continue
                if self.cfg.block_same_ip and a["ip"] == b["ip"]: continue
                if await self.run_db(lambda c: matches.pair_recent(c, a["uid"], b["uid"])) >= self.cfg.max_pair_matches_24h: continue
                self.queues[tier] = [e for e in self.queues[tier] if e is not a and e is not b]
                a["conn"].queued_tier = b["conn"].queued_tier = None
                await self._start(tier, [(a["conn"], a["rating"]), (b["conn"], b["rating"])])
                return await self._match_tier(tier)
            # SANDBOX ONLY: after a wait, play a clearly-labelled house bot so a lone tester can always try the game.
            if self.cfg.sandbox_bot_fill_s and now - a["since"] >= self.cfg.sandbox_bot_fill_s:
                self.queues[tier] = [e for e in self.queues[tier] if e is not a]; a["conn"].queued_tier = None
                await self._start(tier, [(a["conn"], a["rating"]), None])
                return await self._match_tier(tier)

    async def _start(self, tier, ents):
        """ents = [(conn, rating), (conn, rating) | None(bot)]. Creates + locks stakes atomically, spawns the runner."""
        a, b = ents
        p1 = a[0].user["id"]
        p2 = b[0].user["id"] if b else (BOT_ID if tier > 0 else None)
        try:
            info = await self.run_db(lambda c: matches.create_match(c, self.cfg, tier, p1, p2, a[0].ip, b[0].ip if b else None))
        except MatchError as e:
            for cn, rating in [x for x in ents if x]:
                if cn.user["id"] == e.uid or e.uid is None:
                    cn.err(e.code, e.msg)
                else:   # the other player did nothing wrong: back to the front of the queue
                    cn.err("match_failed", "Opponent could not be matched; searching again")
                    cn.queued_tier = tier
                    self.queues[tier].append({"conn": cn, "uid": cn.user["id"], "rating": rating, "since": time.monotonic() - 5, "ip": cn.ip})
                    cn.send({"t": "queued", "tier": tier})
            return None
        slots = []
        for x in (a, b):
            if x is None: slots.append(Slot(BOT_ID, "Shadow-Bot" if tier == 0 else "House Rival", 1000, bot=True))
            else: slots.append(Slot(x[0].user["id"], x[0].user["username"], x[1], ip=x[0].ip))
        m = Match(self, info, slots)
        for i, x in enumerate((a, b)):
            if x is None: continue
            cn = x[0]; slots[i].conn, cn.match, cn.slot = cn, m, i
            self.active[slots[i].uid] = m
        self.all_matches.add(m); self.stats["matches"] += 1
        for _, s in m.humans(): await self.push_balance(s.uid)
        m.start()
        return m

    async def start_rematch(self, old: Match):
        ents = [None if s.bot else (s.conn, s.rating) for s in old.slots]
        if ents[0] is None: ents = [ents[1], None]
        old.phase = "closed"
        for cn, _ in [e for e in ents if e]: cn.match, cn.slot = None, -1
        for s in old.slots: self.active.pop(s.uid, None)
        m = await self._start(old.tier, ents)
        if not m:
            for cn, _ in [e for e in ents if e]: cn.send({"t": "rematch", "state": "failed"})
