"""Tiny asyncio HTTP/1.1 server: JSON routes, static files, WebSocket upgrade, CORS, security headers."""
from __future__ import annotations
import asyncio, json, mimetypes, os, re, time
from urllib.parse import urlsplit, parse_qs
from .ws import WebSocket, accept_key

MAX_HEADER, MAX_BODY = 16 * 1024, 64 * 1024
STATUS = {200: "OK", 101: "Switching Protocols", 204: "No Content", 400: "Bad Request", 401: "Unauthorized", 402: "Payment Required",
          403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 409: "Conflict", 413: "Payload Too Large",
          429: "Too Many Requests", 500: "Internal Server Error", 503: "Service Unavailable"}
mimetypes.add_type("application/javascript", ".js"); mimetypes.add_type("image/svg+xml", ".svg")


class Request:
    def __init__(self, method, path, query, headers, body, ip):
        self.method, self.path, self.query, self.headers, self.body, self.ip = method, path, query, headers, body, ip
        self.params: dict = {}; self.user = None

    def json(self) -> dict:
        try:
            d = json.loads(self.body or b"{}")
            if not isinstance(d, dict): raise ValueError
            return d
        except Exception:
            raise HttpError(400, "bad_json", "Body must be a JSON object")

    @property
    def bearer(self) -> str:
        h = self.headers.get("authorization", "")
        return h[7:].strip() if h.lower().startswith("bearer ") else ""


class HttpError(Exception):
    def __init__(self, status, code, msg): super().__init__(msg); self.status, self.code, self.msg = status, code, msg


class Server:
    def __init__(self, cfg, ws_handler):
        self.cfg, self.ws_handler = cfg, ws_handler
        self.routes: list[tuple[str, re.Pattern, callable]] = []
        self.web_root = os.path.realpath(cfg.web_root)

    def route(self, method: str, pattern: str, fn):
        rx = re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$")
        self.routes.append((method, rx, fn))

    def client_ip(self, headers, peer) -> str:
        if self.cfg.trust_proxy:
            xf = headers.get("x-forwarded-for", "")
            if xf: return xf.split(",")[0].strip()
        return peer

    # ---- plumbing ----
    async def start(self):
        self.srv = await asyncio.start_server(self._conn, self.cfg.host, self.cfg.port, limit=64 * 1024, backlog=256)
        return self.srv

    async def _conn(self, reader, writer):
        peer = (writer.get_extra_info("peername") or ("?",))[0]
        try:
            try: head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
            except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, asyncio.TimeoutError, ConnectionError): return
            if len(head) > MAX_HEADER: return await self._send(writer, 400, {"error": "headers_too_large"})
            lines = head.decode("latin-1").split("\r\n")
            try: method, target, _ = lines[0].split(" ", 2)
            except ValueError: return await self._send(writer, 400, {"error": "bad_request"})
            headers = {}
            for ln in lines[1:]:
                if ":" in ln: k, v = ln.split(":", 1); headers[k.strip().lower()] = v.strip()
            u = urlsplit(target); ip = self.client_ip(headers, peer)
            if headers.get("upgrade", "").lower() == "websocket" and u.path == "/ws":
                return await self._upgrade(reader, writer, headers, ip)
            body = b""
            n = int(headers.get("content-length", "0") or 0) if headers.get("content-length", "0").isdigit() else -1
            if n < 0 or n > MAX_BODY: return await self._send(writer, 413, {"error": "payload_too_large"})
            if n: body = await asyncio.wait_for(reader.readexactly(n), 10)
            await self._dispatch(writer, Request(method.upper(), u.path, {k: v[0] for k, v in parse_qs(u.query).items()}, headers, body, ip))
        except (asyncio.TimeoutError, asyncio.IncompleteReadError, ConnectionError, OSError):
            pass
        except Exception as e:  # never leak internals
            import traceback; traceback.print_exc()
            try: await self._send(writer, 500, {"error": "internal"})
            except Exception: pass
        finally:
            try: writer.close()
            except Exception: pass

    def _cors(self, headers) -> dict:
        o = headers.get("origin")
        if not o: return {}
        # Auth is by bearer token (no cookies), so reflecting the origin does not enable CSRF.
        if o == "null" or not self.cfg.allowed_origins or o in self.cfg.allowed_origins:
            return {"Access-Control-Allow-Origin": o, "Vary": "Origin",
                    "Access-Control-Allow-Headers": "authorization, content-type", "Access-Control-Allow-Methods": "GET, POST, PUT, OPTIONS",
                    "Access-Control-Max-Age": "600"}
        return {}

    async def _dispatch(self, writer, req: Request):
        cors = self._cors(req.headers)
        if req.method == "OPTIONS": return await self._send(writer, 204, None, cors)
        for method, rx, fn in self.routes:
            m = rx.match(req.path)
            if m and method == req.method:
                req.params = m.groupdict()
                try:
                    res = await fn(req)
                    status, payload = res if isinstance(res, tuple) else (200, res)
                    return await self._send(writer, status, payload, cors)
                except HttpError as e:
                    return await self._send(writer, e.status, {"error": e.code, "message": e.msg}, cors)
        if any(rx.match(req.path) for _, rx, _ in self.routes):
            return await self._send(writer, 405, {"error": "method_not_allowed"}, cors)
        if req.method == "GET" and not req.path.startswith(("/api/", "/admin/")):
            return await self._static(writer, req.path, cors)
        await self._send(writer, 404, {"error": "not_found"}, cors)

    SEC = {"X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
           "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; media-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src * ws: wss:; frame-ancestors 'none'"}

    async def _send(self, writer, status, payload, extra=None, ctype="application/json", raw: bytes | None = None, cache="no-store"):
        body = raw if raw is not None else (b"" if payload is None else json.dumps(payload, separators=(",", ":")).encode())
        h = {"Content-Type": ctype, "Content-Length": str(len(body)), "Cache-Control": cache, "Connection": "close", **self.SEC, **(extra or {})}
        writer.write((f"HTTP/1.1 {status} {STATUS.get(status, 'OK')}\r\n" + "".join(f"{k}: {v}\r\n" for k, v in h.items()) + "\r\n").encode() + body)
        await writer.drain()

    async def _static(self, writer, path, cors):
        rel = os.path.normpath(path.lstrip("/") or "index.html")
        full = os.path.realpath(os.path.join(self.web_root, rel))
        if os.path.isdir(full): full = os.path.join(full, "index.html")
        if not full.startswith(self.web_root + os.sep) and full != self.web_root or not os.path.isfile(full):
            if "." not in os.path.basename(rel): full = os.path.join(self.web_root, "index.html")   # SPA fallback
            else: return await self._send(writer, 404, {"error": "not_found"}, cors)
        if not os.path.isfile(full): return await self._send(writer, 404, {"error": "not_found"}, cors)
        with open(full, "rb") as f: data = f.read()
        ct = mimetypes.guess_type(full)[0] or "application/octet-stream"
        await self._send(writer, 200, None, cors, ctype=ct + ("; charset=utf-8" if ct.startswith("text/") or "javascript" in ct else ""), raw=data,
                         cache="no-cache")

    async def _upgrade(self, reader, writer, headers, ip):
        origin = headers.get("origin")
        if origin and self.cfg.allowed_origins and origin not in self.cfg.allowed_origins and origin != "null":
            return await self._send(writer, 403, {"error": "origin_not_allowed"})
        key = headers.get("sec-websocket-key")
        if not key: return await self._send(writer, 400, {"error": "bad_request"})
        writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Accept: {accept_key(key)}\r\n\r\n").encode())
        await writer.drain()
        sock = writer.get_extra_info("socket")
        try:
            import socket; sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception: pass
        ws = WebSocket(reader, writer, ip); ws.meta["headers"] = headers
        await self.ws_handler(ws)
