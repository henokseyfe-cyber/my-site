"""Minimal RFC 6455 WebSocket server codec on asyncio streams (no third-party dependency)."""
from __future__ import annotations
import asyncio, base64, hashlib, struct

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_FRAME = 16 * 1024


class WSClosed(Exception):
    pass


def accept_key(key: str) -> str:
    return base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()


def encode_frame(opcode: int, payload: bytes) -> bytes:
    n = len(payload)
    head = bytes([0x80 | opcode])
    if n < 126: head += bytes([n])
    elif n < 65536: head += b"\x7e" + struct.pack(">H", n)
    else: head += b"\x7f" + struct.pack(">Q", n)
    return head + payload


class WebSocket:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, peer: str):
        self.r, self.w, self.peer = reader, writer, peer
        self.closed = False
        self.meta: dict = {}

    async def _read_frame(self):
        b = await self.r.readexactly(2)
        fin, op = b[0] & 0x80, b[0] & 0x0F
        masked, n = b[1] & 0x80, b[1] & 0x7F
        if not masked: raise WSClosed("client frames must be masked")
        if n == 126: n = struct.unpack(">H", await self.r.readexactly(2))[0]
        elif n == 127: n = struct.unpack(">Q", await self.r.readexactly(8))[0]
        if n > MAX_FRAME: raise WSClosed("frame too large")
        mask = await self.r.readexactly(4)
        data = bytearray(await self.r.readexactly(n))
        if n:  # fast unmask using big ints
            m = int.from_bytes((mask * (n // 4 + 1))[:n], "big")
            data = bytearray((int.from_bytes(data, "big") ^ m).to_bytes(n, "big"))
        return bool(fin), op, bytes(data)

    async def recv(self) -> str:
        """Returns the next text message; answers pings; raises WSClosed on close."""
        buf = b""
        while True:
            try: fin, op, data = await self._read_frame()
            except (asyncio.IncompleteReadError, ConnectionError, OSError) as e: raise WSClosed(str(e))
            if op == 0x8: raise WSClosed("close frame")
            if op == 0x9: await self._send_raw(0xA, data); continue
            if op == 0xA: continue
            if op in (0x1, 0x0):
                buf += data
                if len(buf) > MAX_FRAME: raise WSClosed("message too large")
                if fin:
                    try: return buf.decode("utf-8")
                    except UnicodeDecodeError: raise WSClosed("bad utf-8")
                continue
            raise WSClosed("unsupported opcode")

    async def _send_raw(self, op, payload):
        if self.closed: return
        try:
            self.w.write(encode_frame(op, payload))
            if self.w.transport.get_write_buffer_size() > 256 * 1024:  # slow consumer => drop it
                self.closed = True; self.w.close(); return
            await self.w.drain()
        except (ConnectionError, OSError):
            self.closed = True

    async def send(self, text: str): await self._send_raw(0x1, text.encode())

    def send_nowait(self, text: str) -> None:
        """Never blocks the game loop. A client that cannot keep up (>256KB buffered) is dropped."""
        if self.closed: return
        try:
            self.w.write(encode_frame(0x1, text.encode()))
            if self.w.transport.get_write_buffer_size() > 256 * 1024:
                self.closed = True; self.w.close()
        except Exception:
            self.closed = True

    async def close(self, code=1000, reason=""):
        if not self.closed:
            try: self.w.write(encode_frame(0x8, struct.pack(">H", code) + reason.encode()[:100])); await self.w.drain()
            except Exception: pass
        self.closed = True
        try: self.w.close()
        except Exception: pass
