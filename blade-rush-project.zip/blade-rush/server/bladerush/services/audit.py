"""Append-only, hash-chained audit log. Editing or deleting any row breaks verify()."""
from __future__ import annotations
import hashlib, json, time

GENESIS = "0" * 64


def log(c, actor: str, action: str, entity: str | None = None, details: dict | None = None) -> None:
    if c.dialect == "postgres": c.execute("SELECT pg_advisory_xact_lock(7001)")
    prev = c.one("SELECT hash FROM audit_log ORDER BY seq DESC LIMIT 1")
    prev_hash = prev["hash"] if prev else GENESIS
    ts = int(time.time() * 1000)
    body = json.dumps(details or {}, sort_keys=True, separators=(",", ":"))
    h = hashlib.sha256(f"{prev_hash}|{ts}|{actor}|{action}|{entity}|{body}".encode()).hexdigest()
    c.execute("INSERT INTO audit_log(ts,actor,action,entity,details,prev_hash,hash) VALUES (?,?,?,?,?,?,?)",
              (ts, actor, action, entity, body, prev_hash, h))


def verify(c) -> dict:
    prev, n = GENESIS, 0
    for r in c.all("SELECT * FROM audit_log ORDER BY seq"):
        exp = hashlib.sha256(f"{prev}|{r['ts']}|{r['actor']}|{r['action']}|{r['entity']}|{r['details']}".encode()).hexdigest()
        if r["prev_hash"] != prev or r["hash"] != exp:
            return {"ok": False, "broken_at": r["seq"], "checked": n}
        prev, n = r["hash"], n + 1
    return {"ok": True, "checked": n}
