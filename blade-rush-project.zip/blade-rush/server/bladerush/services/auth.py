"""Accounts and sessions."""
from __future__ import annotations
import re, time
from ..config import Config
from . import audit, wallet
from .compliance import age_years
from .security import hash_password, verify_password, new_token, token_hash, new_id

USERNAME = re.compile(r"^[A-Za-z0-9_]{3,16}$")


class AuthError(Exception):
    def __init__(self, code, msg, status=400): super().__init__(msg); self.code, self.msg, self.status = code, msg, status


def register(c, cfg: Config, body: dict, ip: str) -> dict:
    name, pw, dob, cc = str(body.get("username", "")), str(body.get("password", "")), str(body.get("dob", "")), str(body.get("country", "")).upper()
    if not USERNAME.match(name): raise AuthError("bad_username", "Username must be 3-16 letters, digits or _")
    if len(pw) < 8 or len(pw) > 128: raise AuthError("bad_password", "Password must be 8-128 characters")
    if not re.fullmatch(r"[A-Z]{2}", cc): raise AuthError("bad_country", "Choose your country")
    try: age = age_years(dob)
    except Exception: raise AuthError("bad_dob", "Date of birth must be YYYY-MM-DD")
    if age < cfg.min_age: raise AuthError("underage", f"You must be at least {cfg.min_age} years old")
    if age > 120: raise AuthError("bad_dob", "Invalid date of birth")
    if body.get("accept_terms") is not True: raise AuthError("terms", "You must accept the terms and responsible-gaming policy")
    now = int(time.time() * 1000); uid = new_id("u")
    if c.one("SELECT 1 AS x FROM users WHERE lower(username)=lower(?)", (name,)): raise AuthError("username_taken", "Username already taken", 409)
    c.execute("INSERT INTO users(id,username,pw_hash,dob,country,terms_accepted_at,created_at,last_ip) VALUES (?,?,?,?,?,?,?,?)",
              (uid, name, hash_password(pw), dob, cc, now, now, ip))
    audit.log(c, f"user:{uid}", "register", uid, {"country": cc, "ip": ip})
    if cfg.stake_mode == "sandbox":
        wallet.credit_sandbox(c, uid, cfg.sandbox_start_credit, f"sandbox-welcome:{uid}")
    return {"user_id": uid, **issue_session(c, cfg, uid, ip, body.get("device", ""))}


def issue_session(c, cfg: Config, uid: str, ip: str, device: str = "") -> dict:
    tok, now = new_token(), int(time.time() * 1000)
    c.execute("INSERT INTO sessions(token_hash,user_id,created_at,expires_at,ip,device) VALUES (?,?,?,?,?,?)",
              (token_hash(tok, cfg.token_pepper), uid, now, now + cfg.session_days * 86400_000, ip, str(device)[:80]))
    return {"token": tok}


def login(c, cfg: Config, body: dict, ip: str) -> dict:
    u = c.one("SELECT * FROM users WHERE lower(username)=lower(?)", (str(body.get("username", "")),))
    if not u or not verify_password(str(body.get("password", "")), u["pw_hash"]):
        audit.log(c, "anon", "login_failed", None, {"ip": ip, "username": str(body.get("username", ""))[:20]})
        raise AuthError("bad_credentials", "Wrong username or password", 401)
    if u["status"] != "active": raise AuthError("account_blocked", "Account is not active", 403)
    c.execute("UPDATE users SET last_ip=? WHERE id=?", (ip, u["id"]))
    audit.log(c, f"user:{u['id']}", "login", u["id"], {"ip": ip})
    return {"user_id": u["id"], **issue_session(c, cfg, u["id"], ip, body.get("device", ""))}


def user_for_token(c, cfg: Config, token: str) -> dict | None:
    if not token or len(token) > 100: return None
    now = int(time.time() * 1000)
    return c.one("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.revoked=0 AND s.expires_at>? AND u.status='active'",
                 (token_hash(token, cfg.token_pepper), now))


def logout(c, cfg: Config, token: str):
    c.execute("UPDATE sessions SET revoked=1 WHERE token_hash=?", (token_hash(token, cfg.token_pepper),))


def public_user(u: dict) -> dict:
    return {"id": u["id"], "username": u["username"], "rating": u["rating"], "country": u["country"], "kyc_status": u["kyc_status"]}
