"""Age / KYC / jurisdiction / responsible-gaming gate. Fail-closed: any doubt => no stake play."""
from __future__ import annotations
import datetime as dt, json, time
from ..config import Config, MINOR
from . import audit


class Blocked(Exception):
    def __init__(self, code, msg): super().__init__(msg); self.code, self.msg = code, msg


def age_years(dob: str, today: dt.date | None = None) -> int:
    d = dt.date.fromisoformat(dob); t = today or dt.date.today()
    return t.year - d.year - ((t.month, t.day) < (d.month, d.day))


def day_start_ms() -> int:
    now = dt.datetime.now(dt.timezone.utc)
    return int(now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000)


def get_limits(c, cfg: Config, uid: str) -> dict:
    now = int(time.time() * 1000)
    r = c.one("SELECT * FROM user_limits WHERE user_id=?", (uid,))
    if not r:
        c.execute("INSERT INTO user_limits(user_id,daily_stake,daily_loss,daily_deposit,daily_minutes,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT (user_id) DO NOTHING",
                  (uid, cfg.default_daily_stake, cfg.default_daily_loss, cfg.default_daily_deposit, cfg.default_daily_play_minutes, now))
        r = c.one("SELECT * FROM user_limits WHERE user_id=?", (uid,))
    # apply a pending (cooled-down) increase
    if r["pending_json"] and r["pending_effective_at"] and r["pending_effective_at"] <= now:
        p = json.loads(r["pending_json"])
        c.execute("UPDATE user_limits SET daily_stake=?,daily_loss=?,daily_deposit=?,daily_minutes=?,pending_json=NULL,pending_effective_at=NULL,updated_at=? WHERE user_id=?",
                  (p["daily_stake"], p["daily_loss"], p["daily_deposit"], p["daily_minutes"], now, uid))
        audit.log(c, f"user:{uid}", "limits_increase_applied", uid, p)
        r = c.one("SELECT * FROM user_limits WHERE user_id=?", (uid,))
    return r


def set_limits(c, cfg: Config, uid: str, new: dict) -> dict:
    """Decreases apply immediately. Increases wait for a cool-down (standard responsible-gaming practice)."""
    cur = get_limits(c, cfg, uid); now = int(time.time() * 1000)
    keys = ("daily_stake", "daily_loss", "daily_deposit", "daily_minutes")
    imm, pend, increased = {}, {}, False
    for k in keys:
        v = int(new.get(k, cur[k]))
        if v < 0: raise Blocked("bad_limit", "limits must be positive")
        if v <= cur[k]: imm[k] = v; pend[k] = v
        else: imm[k] = cur[k]; pend[k] = v; increased = True
    c.execute("UPDATE user_limits SET daily_stake=?,daily_loss=?,daily_deposit=?,daily_minutes=?,updated_at=? WHERE user_id=?",
              (imm["daily_stake"], imm["daily_loss"], imm["daily_deposit"], imm["daily_minutes"], now, uid))
    if increased:
        c.execute("UPDATE user_limits SET pending_json=?, pending_effective_at=? WHERE user_id=?",
                  (json.dumps(pend), now + cfg.limit_increase_cooldown_s * 1000, uid))
    audit.log(c, f"user:{uid}", "limits_changed", uid, {"applied": imm, "pending": pend if increased else None})
    return get_limits(c, cfg, uid)


def self_exclude(c, uid: str, days: int):
    now = int(time.time() * 1000)
    if days < 1: raise Blocked("bad_request", "days must be >= 1")
    until = now + days * 86400_000
    c.execute("INSERT INTO self_exclusions(user_id,until,created_at) VALUES (?,?,?)", (uid, until, now))
    audit.log(c, f"user:{uid}", "self_exclusion", uid, {"until": until})
    return until


def exclusion_until(c, uid: str) -> int:
    return int(c.scalar("SELECT MAX(until) FROM self_exclusions WHERE user_id=?", (uid,)))


def net_loss_today(c, uid: str) -> int:
    start = day_start_ms(); loss = 0
    for m in c.all("SELECT tier,winner,prize,status,p1,p2 FROM matches WHERE (p1=? OR p2=?) AND status='settled' AND settled_at>=? AND p2 IS NOT NULL", (uid, uid, start)):
        if m["winner"] == uid: loss -= (m["prize"] - m["tier"])
        elif m["winner"]: loss += m["tier"]
    return loss


def staked_today(c, uid: str) -> int:
    return int(c.scalar("SELECT SUM(tier) FROM matches WHERE (p1=? OR p2=?) AND p2 IS NOT NULL AND created_at>=? AND status NOT IN ('refunded','void')",
                        (uid, uid, day_start_ms())))


def minutes_today(c, uid: str) -> float:
    return float(c.scalar("SELECT SUM(seconds) FROM play_sessions WHERE user_id=? AND created_at>=?", (uid, day_start_ms()))) / 60.0


def check_can_play(c, cfg: Config, uid: str, tier: int, request_country: str | None = None) -> None:
    """Raises Blocked with a stable code. tier==0 is free practice (no gating beyond account status)."""
    u = c.one("SELECT * FROM users WHERE id=?", (uid,))
    if not u or u["status"] != "active": raise Blocked("account_blocked", "Account is not active")
    if tier == 0: return
    if tier not in cfg.entry_tiers: raise Blocked("bad_tier", "Unknown entry tier")
    if age_years(u["dob"]) < cfg.min_age: raise Blocked("underage", f"You must be at least {cfg.min_age}")
    ex = exclusion_until(c, uid)
    if ex > time.time() * 1000: raise Blocked("self_excluded", "Self-exclusion is active")
    if cfg.stake_mode == "real":
        cc = u["country"].upper()
        if cc in cfg.blocked_regions or cc not in cfg.real_money_countries:
            raise Blocked("jurisdiction", "Real-money play is not available in your jurisdiction")
        if request_country and request_country.upper() != cc:
            raise Blocked("jurisdiction_mismatch", "Your location does not match your registered country")
        if cfg.require_kyc and u["kyc_status"] != "verified":
            raise Blocked("kyc_required", "Identity verification is required before staking")
    lim = get_limits(c, cfg, uid)
    if staked_today(c, uid) + tier > lim["daily_stake"]: raise Blocked("limit_stake", "Daily stake limit reached")
    if net_loss_today(c, uid) + tier > lim["daily_loss"]: raise Blocked("limit_loss", "Daily loss limit reached")
    if minutes_today(c, uid) >= lim["daily_minutes"]: raise Blocked("limit_time", "Daily play-time limit reached")
