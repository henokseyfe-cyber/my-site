"""Match lifecycle in the database: create+lock, settle, refund, recover. All money moves via wallet.post
with idempotency keys derived from the match id, and the status transition is a compare-and-set, so
a double settlement (retry, crash-recover, two tasks) is impossible."""
from __future__ import annotations
import json, secrets, time
from ..config import Config
from . import audit, wallet, compliance, risk
from .security import new_id


class MatchError(Exception):
    def __init__(self, code, msg, uid=None): super().__init__(msg); self.code, self.msg, self.uid = code, msg, uid


BOT_ID = "bot_sandbox"   # sandbox-only house bot; never used when STAKE_MODE=real


def _now(): return int(time.time() * 1000)


def pair_recent(c, a: str, b: str) -> int:
    return int(c.scalar("SELECT COUNT(*) FROM matches WHERE created_at>? AND status NOT IN ('refunded','void') AND ((p1=? AND p2=?) OR (p1=? AND p2=?))",
                        (_now() - 86400_000, a, b, b, a)))


def create_match(c, cfg: Config, tier: int, p1: str, p2: str | None, ip1=None, ip2=None, countries=(None, None)) -> dict:
    """Atomically: re-check compliance for both, create the row with a unique id + seed, lock both stakes.
    Any failure rolls back the whole transaction, so you never end up with one stake locked."""
    mid = new_id("m"); seed = secrets.token_hex(16); now = _now()
    if tier > 0:
        if BOT_ID in (p1, p2):
            if cfg.stake_mode != "sandbox": raise MatchError("bot_forbidden", "Bots may never play for real stakes")
            wallet.credit_sandbox(c, BOT_ID, tier, f"botfund:{mid}")
        for uid, cc in ((p1, countries[0]), (p2, countries[1])):
            if uid == BOT_ID: continue
            try: compliance.check_can_play(c, cfg, uid, tier, cc)
            except compliance.Blocked as e: raise MatchError(e.code, e.msg, uid) from e
    c.execute("INSERT INTO matches(id,tier,fee_bps,p1,p2,status,seed,ip1,ip2,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (mid, tier, cfg.fee_bps if tier else 0, p1, p2, "locked" if tier else "playing", seed, ip1, ip2, now))
    if tier > 0:
        for uid in (p1, p2):
            try: wallet.lock_stake(c, mid, uid, tier)
            except wallet.InsufficientFunds as e: raise MatchError("insufficient_funds", "Not enough balance for this entry", uid) from e
        audit.log(c, "system:match", "stakes_locked", mid, {"tier": tier, "p1": p1, "p2": p2})
    return {"id": mid, "seed": seed, "tier": tier, "fee_bps": cfg.fee_bps if tier else 0}


def mark_playing(c, mid: str):
    c.execute("UPDATE matches SET status='playing', started_at=? WHERE id=? AND status='locked'", (_now(), mid))


def refund(c, mid: str, reason: str) -> bool:
    """Return both stakes. Idempotent; only from locked/playing/review."""
    m = c.one("SELECT * FROM matches WHERE id=?", (mid,))
    if not m: return False
    r = c.execute("UPDATE matches SET status='refunded', end_reason=?, ended_at=?, settled_at=? WHERE id=? AND status IN ('locked','playing','review')",
                  (reason, _now(), _now(), mid))
    if r.rowcount != 1: return False
    if m["tier"] > 0:
        for uid in (m["p1"], m["p2"]):
            if uid: wallet.refund_stake(c, mid, uid, m["tier"])
    audit.log(c, "system:match", "match_refunded", mid, {"reason": reason})
    return True


def settle(c, cfg: Config, mid: str, sim_result: dict, analysis: dict, *, force: str | None = None) -> dict:
    """sim_result: {winner: 0|1|None, reason, e1, e2, seconds:[..]}. Returns the final public record.
    Decides: draw -> refund; high risk -> hold in 'review'; else pay winner. Exactly-once by CAS + idempotency keys."""
    m = c.one("SELECT * FROM matches WHERE id=?", (mid,))
    if not m: raise MatchError("no_match", "unknown match")
    if m["status"] in ("settled", "refunded", "void"):
        return _public(c, mid)           # idempotent replay
    now = _now(); winner_idx = sim_result["winner"]
    uids = [m["p1"], m["p2"]]
    c.execute("UPDATE matches SET e1=?, e2=?, risk_score=?, risk_flags=? WHERE id=?",
              (sim_result["e1"], sim_result["e2"], analysis["score"], json.dumps([f["kind"] for f in analysis["flags"]]), mid))
    if analysis["flags"]: risk.record(c, mid, analysis, uids)
    if m["p2"] is None:   # practice: nothing financial
        c.execute("UPDATE matches SET status='settled', winner=?, end_reason=?, ended_at=?, settled_at=? WHERE id=? AND status='playing'",
                  (uids[winner_idx] if winner_idx == 0 else None, sim_result["reason"], now, now, mid))
        return _public(c, mid)
    for i, uid in enumerate(uids):    # play-time accounting for responsible gaming
        c.execute("INSERT INTO play_sessions(user_id,match_id,seconds,created_at) VALUES (?,?,?,?)", (uid, mid, int(sim_result.get("seconds", 0)), now))
    if force != "pay" and analysis["score"] >= cfg.review_threshold and winner_idx is not None:
        r = c.execute("UPDATE matches SET status='review', winner=?, end_reason=?, ended_at=? WHERE id=? AND status IN ('playing','locked')",
                      (uids[winner_idx], sim_result["reason"], now, mid))
        if r.rowcount == 1: audit.log(c, "system:risk", "match_held_for_review", mid, {"score": analysis["score"]})
        return _public(c, mid)
    if winner_idx is None:
        refund(c, mid, "draw"); return _public(c, mid)
    winner, loser = uids[winner_idx], uids[1 - winner_idx]
    r = c.execute("UPDATE matches SET status='settled', winner=?, end_reason=?, ended_at=?, settled_at=? WHERE id=? AND status IN ('playing','locked','review')",
                  (winner, sim_result["reason"], now, now, mid))
    if r.rowcount != 1: return _public(c, mid)     # someone else settled first
    pot, fee, prize = wallet.pay_winner(c, mid, winner, loser, m["tier"], m["fee_bps"])
    c.execute("UPDATE matches SET prize=?, fee=? WHERE id=?", (prize, fee, mid))
    _rating(c, winner, loser)
    audit.log(c, "system:match", "match_settled", mid, {"winner": winner, "prize": prize, "fee": fee, "reason": sim_result["reason"]})
    return _public(c, mid)


def _rating(c, w: str, l: str):
    rw = c.scalar("SELECT rating FROM users WHERE id=?", (w,), 1000); rl = c.scalar("SELECT rating FROM users WHERE id=?", (l,), 1000)
    exp = 1 / (1 + 10 ** ((rl - rw) / 400)); d = round(24 * (1 - exp))
    c.execute("UPDATE users SET rating=rating+? WHERE id=?", (d, w)); c.execute("UPDATE users SET rating=CASE WHEN rating-? < 100 THEN 100 ELSE rating-? END WHERE id=?", (d, d, l))


def admin_resolve(c, cfg: Config, mid: str, action: str, admin: str) -> dict:
    m = c.one("SELECT * FROM matches WHERE id=?", (mid,))
    if not m or m["status"] != "review": raise MatchError("not_in_review", "match is not awaiting review")
    audit.log(c, f"admin:{admin}", "review_" + action, mid, {})
    if action == "refund": refund(c, mid, "admin_refund")
    elif action == "pay":
        idx = 0 if m["winner"] == m["p1"] else 1
        settle(c, cfg, mid, {"winner": idx, "reason": m["end_reason"] or "review", "e1": m["e1"], "e2": m["e2"]}, {"score": 0, "flags": []}, force="pay")
    else: raise MatchError("bad_action", "action must be pay or refund")
    return _public(c, mid)


def recover_after_crash(c) -> list[str]:
    """On startup any match still locked/playing was interrupted by a server fault -> refund both players."""
    out = []
    for m in c.all("SELECT id FROM matches WHERE status IN ('locked','playing')"):
        if refund(c, m["id"], "server_restart"): out.append(m["id"])
    return out


def _public(c, mid: str) -> dict:
    m = c.one("SELECT * FROM matches WHERE id=?", (mid,))
    return {k: m[k] for k in ("id", "tier", "fee_bps", "p1", "p2", "status", "winner", "end_reason", "e1", "e2", "prize", "fee", "created_at", "ended_at")}
