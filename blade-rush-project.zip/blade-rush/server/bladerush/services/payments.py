"""Deposits / withdrawals through a pluggable provider. The client only ever *requests*; money moves
(a) in sandbox mode: instantly with play credits, (b) in real mode: only after a verified provider webhook."""
from __future__ import annotations
import time
from ..config import Config
from . import audit, wallet, compliance
from .providers import PAYMENT_PROVIDERS
from .security import new_id


class PayError(Exception):
    def __init__(self, code, msg, status=400): super().__init__(msg); self.code, self.msg, self.status = code, msg, status


def _now(): return int(time.time() * 1000)


def provider(cfg: Config):
    cls = PAYMENT_PROVIDERS.get(cfg.payment_provider)
    if not cls: raise PayError("provider_unavailable", "Payment provider is not configured", 503)
    return cls()


def _amount(v, cfg: Config) -> int:
    if not isinstance(v, int) or isinstance(v, bool) or v <= 0 or v > 10_000_000_00: raise PayError("bad_amount", "Amount must be a positive integer (santim)")
    return v


def _key(body) -> str:
    k = str(body.get("idempotency_key", ""))
    if not (8 <= len(k) <= 80): raise PayError("bad_key", "idempotency_key (8-80 chars) is required")
    return k


def deposit_today(c, uid) -> int:
    return int(c.scalar("SELECT SUM(amount) FROM payment_intents WHERE user_id=? AND direction='deposit' AND status IN ('pending','succeeded') AND created_at>=?", (uid, compliance.day_start_ms())))


def request_deposit(c, cfg: Config, uid: str, body: dict) -> dict:
    amt, key = _amount(body.get("amount"), cfg), _key(body)
    old = c.one("SELECT * FROM payment_intents WHERE idempotency_key=?", (f"{uid}:{key}",))
    if old: return _intent_public(old)                              # idempotent replay
    u = c.one("SELECT * FROM users WHERE id=?", (uid,))
    if cfg.stake_mode == "real":
        if u["country"] not in cfg.real_money_countries or u["country"] in cfg.blocked_regions: raise PayError("jurisdiction", "Not available in your jurisdiction", 403)
        if cfg.require_kyc and u["kyc_status"] != "verified": raise PayError("kyc_required", "Verify your identity before depositing", 403)
    else:
        if amt > cfg.sandbox_topup_max: raise PayError("topup_limit", "Sandbox top-up too large")
    if compliance.exclusion_until(c, uid) > _now(): raise PayError("self_excluded", "Self-exclusion is active", 403)
    lim = compliance.get_limits(c, cfg, uid)
    if deposit_today(c, uid) + amt > lim["daily_deposit"]: raise PayError("limit_deposit", "Daily deposit limit reached", 403)
    iid, now = new_id("pi"), _now()
    c.execute("INSERT INTO payment_intents(id,user_id,direction,amount,provider,status,idempotency_key,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
              (iid, uid, "deposit", amt, cfg.payment_provider, "pending", f"{uid}:{key}", now, now))
    p = provider(cfg)
    res = p.create_deposit({"id": iid, "user_id": uid, "amount": amt})
    c.execute("UPDATE payment_intents SET provider_ref=?, updated_at=? WHERE id=?", (res["provider_ref"], now, iid))
    audit.log(c, f"user:{uid}", "deposit_requested", iid, {"amount": amt, "provider": p.name})
    if res["status"] == "succeeded" and not p.async_confirm: _confirm_deposit(c, iid)
    row = c.one("SELECT * FROM payment_intents WHERE id=?", (iid,))
    return {**_intent_public(row), "checkout_url": res.get("checkout_url")}


def _confirm_deposit(c, iid: str):
    r = c.execute("UPDATE payment_intents SET status='succeeded', updated_at=? WHERE id=? AND status='pending'", (_now(), iid))
    if r.rowcount != 1: return                                       # already processed
    i = c.one("SELECT * FROM payment_intents WHERE id=?", (iid,))
    if i["provider"] == "sandbox": wallet.credit_sandbox(c, i["user_id"], i["amount"], f"deposit:{iid}")
    else: wallet.deposit(c, i["user_id"], i["amount"], f"deposit:{iid}", i["provider_ref"])
    audit.log(c, "system:payments", "deposit_confirmed", iid, {"amount": i["amount"]})


def request_withdrawal(c, cfg: Config, uid: str, body: dict) -> dict:
    amt, key = _amount(body.get("amount"), cfg), _key(body)
    old = c.one("SELECT * FROM payment_intents WHERE idempotency_key=?", (f"{uid}:{key}",))
    if old: return _intent_public(old)
    u = c.one("SELECT * FROM users WHERE id=?", (uid,))
    if cfg.stake_mode == "sandbox": raise PayError("sandbox", "Play credits cannot be withdrawn", 403)
    if cfg.require_kyc and u["kyc_status"] != "verified": raise PayError("kyc_required", "Verify your identity before withdrawing", 403)
    iid, now = new_id("pi"), _now()
    try: wallet.withdrawal_reserve(c, uid, amt, f"wdres:{iid}", iid)
    except wallet.InsufficientFunds: raise PayError("insufficient_funds", "Insufficient balance", 402)
    c.execute("INSERT INTO payment_intents(id,user_id,direction,amount,provider,status,idempotency_key,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
              (iid, uid, "withdrawal", amt, cfg.payment_provider, "pending", f"{uid}:{key}", now, now))
    res = provider(cfg).create_payout({"id": iid, "user_id": uid, "amount": amt})
    c.execute("UPDATE payment_intents SET provider_ref=? WHERE id=?", (res["provider_ref"], iid))
    audit.log(c, f"user:{uid}", "withdrawal_requested", iid, {"amount": amt})
    if res["status"] == "succeeded": _finish_withdrawal(c, iid, True)
    elif res["status"] == "failed": _finish_withdrawal(c, iid, False)
    return _intent_public(c.one("SELECT * FROM payment_intents WHERE id=?", (iid,)))


def _finish_withdrawal(c, iid: str, ok: bool):
    r = c.execute("UPDATE payment_intents SET status=?, updated_at=? WHERE id=? AND status='pending'", ("succeeded" if ok else "failed", _now(), iid))
    if r.rowcount != 1: return
    i = c.one("SELECT * FROM payment_intents WHERE id=?", (iid,))
    (wallet.withdrawal_complete if ok else wallet.withdrawal_release)(c, i["user_id"], i["amount"], f"wd{'done' if ok else 'rel'}:{iid}", iid)
    audit.log(c, "system:payments", "withdrawal_" + ("completed" if ok else "released"), iid, {"amount": i["amount"]})


def handle_webhook(c, cfg: Config, headers: dict, body: bytes) -> dict:
    ev = provider(cfg).parse_webhook(headers, body, cfg.webhook_secret)
    if not ev: raise PayError("bad_signature", "invalid webhook", 401)
    i = c.one("SELECT * FROM payment_intents WHERE provider=? AND provider_ref=?", (cfg.payment_provider, ev["provider_ref"]))
    if not i or i["direction"] != ev["direction"]: raise PayError("unknown_intent", "unknown reference", 404)
    if ev["direction"] == "deposit":
        if ev["status"] == "succeeded": _confirm_deposit(c, i["id"])
        elif ev["status"] == "failed": c.execute("UPDATE payment_intents SET status='failed' WHERE id=? AND status='pending'", (i["id"],))
    else:
        _finish_withdrawal(c, i["id"], ev["status"] == "succeeded") if ev["status"] in ("succeeded", "failed") else None
    return {"ok": True}


def _intent_public(i): return {"id": i["id"], "direction": i["direction"], "amount": i["amount"], "status": i["status"], "created_at": i["created_at"]}
