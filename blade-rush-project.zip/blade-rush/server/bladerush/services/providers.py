"""Payment / KYC provider interfaces. Real, licensed providers plug in by implementing these classes
and registering them in PAYMENT_PROVIDERS / KYC_PROVIDERS; the wallet code does not change."""
from __future__ import annotations
import hashlib, hmac, json
from abc import ABC, abstractmethod


class PaymentProvider(ABC):
    name = "abstract"
    #: True => the provider confirms asynchronously through a signed webhook (all real providers).
    async_confirm = True

    @abstractmethod
    def create_deposit(self, intent: dict) -> dict:
        """Return {"provider_ref": str, "checkout_url": str|None, "status": "pending"|"succeeded"}."""

    @abstractmethod
    def create_payout(self, intent: dict) -> dict:
        """Return {"provider_ref": str, "status": "pending"|"succeeded"|"failed"}."""

    @abstractmethod
    def parse_webhook(self, headers: dict, body: bytes, secret: str) -> dict | None:
        """Verify the signature and return {"provider_ref","direction","status"} or None if invalid."""


class SandboxProvider(PaymentProvider):
    """PLAY-MONEY ONLY. Never moves real funds. Used when STAKE_MODE=sandbox."""
    name, async_confirm = "sandbox", False

    def create_deposit(self, intent): return {"provider_ref": "sbx_" + intent["id"], "checkout_url": None, "status": "succeeded"}
    def create_payout(self, intent): return {"provider_ref": "sbx_" + intent["id"], "status": "succeeded"}
    def parse_webhook(self, headers, body, secret): return None


class HmacWebhookProvider(PaymentProvider):
    """Reference skeleton for a real provider: signs/verifies webhooks with HMAC-SHA256 over the raw body.
    Subclass it, implement create_deposit/create_payout against the provider's REST API using credentials
    read from environment variables, and map the provider's webhook payload in parse_webhook."""
    name = "hmac"
    signature_header = "x-signature"

    def create_deposit(self, intent): raise NotImplementedError("integrate your licensed provider's checkout API here")
    def create_payout(self, intent): raise NotImplementedError("integrate your licensed provider's payout API here")

    def parse_webhook(self, headers, body, secret):
        if not secret: return None
        sig = headers.get(self.signature_header, "")
        exp = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, exp): return None
        try:
            d = json.loads(body)
            return {"provider_ref": str(d["provider_ref"]), "direction": d["direction"], "status": d["status"]}
        except Exception:
            return None


class KycProvider(ABC):
    name = "abstract"
    @abstractmethod
    def start(self, user: dict) -> dict:
        """Begin verification. Return {"status": "pending"|"verified", "url": optional hosted flow url}.
        Identity documents are handled by the provider; we store only the resulting status."""


class SandboxKyc(KycProvider):
    name = "sandbox"
    def start(self, user): return {"status": "verified", "url": None}


class ManualKyc(KycProvider):
    name = "manual"
    def start(self, user): return {"status": "pending", "url": None}  # an admin approves via /admin/users/:id/kyc


PAYMENT_PROVIDERS = {"sandbox": SandboxProvider, "hmac": HmacWebhookProvider}
KYC_PROVIDERS = {"sandbox": SandboxKyc, "manual": ManualKyc}
