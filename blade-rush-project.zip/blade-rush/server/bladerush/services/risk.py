"""Anti-cheat / fraud analysis. Runs server-side on the authoritative match record and live input stream.

Nothing here trusts the client. Scores are additive; a match whose score crosses REVIEW_THRESHOLD is NOT paid
automatically — funds stay locked and the match goes to a human review queue (no automatic confiscation,
because a false positive on real money is worse than a delayed payout)."""
from __future__ import annotations
import json, math, statistics, time
from ..game.sim import Sim
from . import audit

# Live per-connection counters feed `LiveGuard`; post-match analysis uses `analyse_match`.
WEIGHTS = dict(bad_packet=2, bad_seq=3, flood=5, queue_overflow=2, over_speed_input=1, unknown_type=2, bad_build=100)


class LiveGuard:
    """Per-player, in-match packet hygiene. Produces score + flags; never decides outcomes by itself."""
    def __init__(self):
        self.score = 0; self.flags: dict[str, int] = {}
        self.last_seq = 0; self.window_start = time.monotonic(); self.window_n = 0

    def hit(self, kind: str, n: int = 1):
        self.flags[kind] = self.flags.get(kind, 0) + n
        self.score += WEIGHTS.get(kind, 1) * n

    def on_message(self) -> bool:
        """Returns False if the connection is flooding (>120 msgs/s sustained)."""
        now = time.monotonic()
        if now - self.window_start >= 1.0: self.window_start, self.window_n = now, 0
        self.window_n += 1
        if self.window_n > 120:
            if self.window_n == 121: self.hit("flood")
            return False
        return True

    def check_seq(self, seq) -> bool:
        if not isinstance(seq, int) or isinstance(seq, bool) or seq <= self.last_seq or seq > self.last_seq + 600:
            self.hit("bad_seq"); return False
        self.last_seq = seq; return True


def _reaction_stats(swings_opp: list[int], dashes_me: list[int]) -> tuple[int, int]:
    """For every opponent swing: did I dash within 1..3 ticks (<=100ms)? Humans physically can't do this reliably."""
    fast = 0
    ds = set(dashes_me)
    for s in swings_opp:
        if any((s + k) in ds for k in (0, 1, 2, 3)): fast += 1
    return fast, len(swings_opp)


def analyse_match(sim: Sim, meta: dict) -> dict:
    """meta: tier, ips [ip1, ip2], pair_recent (matches between these 2 in 24h), guards [g0,g1], practice, disconnects[2]
    Returns {"score", "flags": [..], "per_player": [s0, s1]}."""
    flags: list[dict] = []; per = [0, 0]
    def flag(kind, pts, who=None, **d):
        flags.append({"kind": kind, "pts": pts, "who": who, **d})
        if who is None: per[0] += pts // 2; per[1] += pts - pts // 2
        else: per[who] += pts
    if meta.get("practice"):
        return {"score": 0, "flags": [], "per_player": [0, 0]}
    secs = max(sim.tick / sim.R["tick"], 1)
    st = [p.stats for p in sim.players]
    bots = meta.get("bots", [False, False])
    for i in (0, 1):
        if bots[i]: continue
        g = meta["guards"][i]
        if g.score: flag("packet_anomalies", min(g.score, 100), i, counters=g.flags)
        # --- bot / macro signatures
        fast, n = _reaction_stats(sim.log["swings"][1 - i], sim.log["dashes"][i])
        if n >= 8 and fast / n >= 0.8: flag("superhuman_reaction", 70, i, ratio=round(fast / n, 2), n=n)
        sw = sim.log["swings"][i]
        if len(sw) >= 10:
            gaps = [b - a for a, b in zip(sw, sw[1:])]
            if statistics.pstdev(gaps) < 0.35: flag("metronomic_attacks", 60, i, sd=round(statistics.pstdev(gaps), 3))
        if st[i]["swings"] >= 14 and st[i]["hits"] / st[i]["swings"] > 0.92: flag("aim_perfect", 40, i, swings=st[i]["swings"])
    # --- collusion / chip dumping / win trading
    ips = meta.get("ips") or [None, None]
    if not any(bots) and ips[0] and ips[0] == ips[1]: flag("same_ip", 60)
    if meta.get("pair_recent", 0) > meta.get("pair_limit", 6): flag("repeat_pairing", 50, pair_recent=meta["pair_recent"])
    if sim.finished and sim.reason in ("target", "time") and sim.winner is not None:
        w, l = sim.winner, 1 - sim.winner
        passive = (st[l]["swings"] <= 1 and st[l]["dashes"] == 0 and st[l]["idle"] / (secs * sim.R["tick"]) > 0.6)
        if passive and meta["tier"] > 0 and not bots[l]: flag("dumping", 80, l, idle=round(st[l]["idle"] / (secs * sim.R["tick"]), 2))
        if st[l]["dist"] < 120 and secs > 20 and meta["tier"] > 0 and not bots[l]: flag("loser_stationary", 50, l, dist=round(st[l]["dist"]))
    for i in (0, 1):
        if bots[i]: continue
        if meta.get("disconnects", [0, 0])[i] >= 3: flag("disconnect_abuse", 30, i)
    return {"score": max(per), "flags": flags, "per_player": per}


def record(c, match_id: str, result: dict, uids: list[str | None]):
    now = int(time.time() * 1000)
    for f in result["flags"]:
        uid = uids[f["who"]] if f.get("who") is not None else None
        c.execute("INSERT INTO risk_events(match_id,user_id,kind,score,detail,created_at) VALUES (?,?,?,?,?,?)",
                  (match_id, uid, f["kind"], f["pts"], json.dumps(f, sort_keys=True), now))
    per = result.get("per_player") or [result["score"] // 2, result["score"] // 2]
    for i, uid in enumerate(uids):
        if uid and per[i]:
            c.execute("UPDATE users SET risk_score=risk_score+? WHERE id=?", (per[i], uid))
    if result["flags"]:
        audit.log(c, "system:risk", "match_risk", match_id, {"score": result["score"], "flags": [f["kind"] for f in result["flags"]]})
