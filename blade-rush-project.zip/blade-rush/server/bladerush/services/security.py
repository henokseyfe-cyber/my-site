"""Password hashing, session tokens, rate limiting."""
from __future__ import annotations
import hashlib, hmac, os, secrets, time, base64
from collections import defaultdict, deque


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(h).decode()


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, s, h = stored.split("$")
        calc = hashlib.scrypt(pw.encode(), salt=base64.b64decode(s), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(h))
    except Exception:
        return False


def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(token: str, pepper: str) -> str:
    """Only an HMAC of the session token is stored, so a DB leak does not leak live sessions."""
    return hmac.new(pepper.encode(), token.encode(), hashlib.sha256).hexdigest()


def new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(12)}"


class RateLimiter:
    """Sliding-window limiter keyed by string (ip, user...)."""
    def __init__(self): self.hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str, limit: int, window: float, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        q = self.hits[key]
        while q and q[0] <= now - window: q.popleft()
        if len(q) >= limit: return False
        q.append(now); return True

    def gc(self, now: float | None = None):
        now = time.monotonic() if now is None else now
        for k in [k for k, q in self.hits.items() if not q or q[-1] < now - 3600]: del self.hits[k]
