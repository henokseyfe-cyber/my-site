"""Wallet service: double-entry, immutable, idempotent ledger.

Rules enforced here (and nowhere else):
  * Only this module writes `accounts` / `ledger_*`. Clients and the game loop never touch balances.
  * Every operation has a deterministic idempotency key; replaying it is a no-op returning the original tx.
  * Entries of a transaction sum to zero. User accounts can never go below zero (guarded UPDATE).
  * Ledger rows are protected by DB triggers against UPDATE/DELETE.
"""
from __future__ import annotations
import time
from .security import new_id
from . import audit


class WalletError(Exception):
    code = "wallet_error"


class InsufficientFunds(WalletError):
    code = "insufficient_funds"


def avail(uid): return f"user:{uid}:available"
def locked(uid): return f"user:{uid}:locked"
FEE, EXTERNAL, SANDBOX_MINT, WD_HOLD = "platform:fee", "platform:external", "platform:sandbox_mint", "platform:withdrawal_hold"


def _now(): return int(time.time() * 1000)


def post(c, key: str, kind: str, entries: list[tuple[str, int]], *, user_id=None, match_id=None, ref=None) -> tuple[str, bool]:
    """Apply a balanced set of entries atomically. Returns (tx_id, created). created=False => idempotent replay."""
    if sum(a for _, a in entries) != 0: raise WalletError("unbalanced transaction")
    if any(not isinstance(a, int) for _, a in entries): raise WalletError("amounts must be integers")
    tx_id, now = new_id("tx"), _now()
    cur = c.execute("INSERT INTO ledger_transactions(id,idempotency_key,kind,user_id,match_id,ref,created_at) VALUES (?,?,?,?,?,?,?) "
                    "ON CONFLICT (idempotency_key) DO NOTHING", (tx_id, key, kind, user_id, match_id, ref, now))
    if cur.rowcount == 0:
        return c.one("SELECT id FROM ledger_transactions WHERE idempotency_key=?", (key,))["id"], False
    for acct, amt in sorted(entries):  # fixed lock order => no deadlocks
        uid = acct.split(":")[1] if acct.startswith("user:") else None
        c.execute("INSERT INTO accounts(name,user_id,balance) VALUES (?,?,0) ON CONFLICT (name) DO NOTHING", (acct, uid))
        if acct.startswith("user:"):
            r = c.execute("UPDATE accounts SET balance=balance+? WHERE name=? AND balance+?>=0", (amt, acct, amt))
            if r.rowcount != 1: raise InsufficientFunds(acct)
        else:
            c.execute("UPDATE accounts SET balance=balance+? WHERE name=?", (amt, acct))
        c.execute("INSERT INTO ledger_entries(tx_id,account,amount,created_at) VALUES (?,?,?,?)", (tx_id, acct, amt, now))
    return tx_id, True


def balances(c, uid: str) -> dict:
    a = c.scalar("SELECT balance FROM accounts WHERE name=?", (avail(uid),))
    l = c.scalar("SELECT balance FROM accounts WHERE name=?", (locked(uid),))
    return {"available": int(a), "locked": int(l)}


def split_pot(stake: int, fee_bps: int) -> tuple[int, int, int]:
    """pot = 2*stake; fee rounded DOWN (never over-charges); prize = pot - fee. Returns (pot, fee, prize)."""
    pot = stake * 2
    fee = pot * fee_bps // 10000
    return pot, fee, pot - fee


# ---- operations -------------------------------------------------------------------------------------------
def credit_sandbox(c, uid, amount, key):
    return post(c, key, "sandbox_credit", [(SANDBOX_MINT, -amount), (avail(uid), amount)], user_id=uid)


def deposit(c, uid, amount, key, ref=None):
    """Called ONLY after a provider confirmation (webhook) or by the sandbox provider."""
    return post(c, key, "deposit", [(EXTERNAL, -amount), (avail(uid), amount)], user_id=uid, ref=ref)


def withdrawal_reserve(c, uid, amount, key, ref=None):
    return post(c, key, "withdrawal_reserve", [(avail(uid), -amount), (WD_HOLD, amount)], user_id=uid, ref=ref)


def withdrawal_complete(c, uid, amount, key, ref=None):
    return post(c, key, "withdrawal", [(WD_HOLD, -amount), (EXTERNAL, amount)], user_id=uid, ref=ref)


def withdrawal_release(c, uid, amount, key, ref=None):
    return post(c, key, "withdrawal_release", [(WD_HOLD, -amount), (avail(uid), amount)], user_id=uid, ref=ref)


def lock_stake(c, match_id, uid, stake):
    return post(c, f"lock:{match_id}:{uid}", "stake_lock", [(avail(uid), -stake), (locked(uid), stake)], user_id=uid, match_id=match_id)


def refund_stake(c, match_id, uid, stake):
    return post(c, f"refund:{match_id}:{uid}", "refund", [(locked(uid), -stake), (avail(uid), stake)], user_id=uid, match_id=match_id)


def pay_winner(c, match_id, winner, loser, stake, fee_bps):
    pot, fee, prize = split_pot(stake, fee_bps)
    entries = [(locked(winner), -stake), (locked(loser), -stake), (avail(winner), prize)]
    if fee: entries.append((FEE, fee))
    post(c, f"payout:{match_id}", "payout", entries, user_id=winner, match_id=match_id)
    return pot, fee, prize


def reconcile(c) -> dict:
    """Integrity check: ledger sums to zero and cached balances equal the sum of entries."""
    total = c.scalar("SELECT SUM(amount) FROM ledger_entries")
    bad = c.all("SELECT a.name, a.balance, COALESCE(s.t,0) AS ledger FROM accounts a "
                "LEFT JOIN (SELECT account, SUM(amount) t FROM ledger_entries GROUP BY account) s ON s.account=a.name "
                "WHERE a.balance <> COALESCE(s.t,0)")
    return {"ok": total == 0 and not bad, "ledger_sum": int(total), "mismatches": bad}
