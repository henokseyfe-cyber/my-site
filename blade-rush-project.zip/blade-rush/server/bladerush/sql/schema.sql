-- Blade Rush schema. Portable DDL; {AUTOID} is substituted per dialect (see db.py).
-- All money is BIGINT santim (1 Birr = 100).
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  pw_hash TEXT NOT NULL,
  dob TEXT NOT NULL,
  country TEXT NOT NULL,
  kyc_status TEXT NOT NULL DEFAULT 'none',          -- none|pending|verified|rejected
  status TEXT NOT NULL DEFAULT 'active',            -- active|banned|closed
  rating INTEGER NOT NULL DEFAULT 1000,
  risk_score INTEGER NOT NULL DEFAULT 0,
  strikes INTEGER NOT NULL DEFAULT 0,
  terms_accepted_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  last_ip TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  created_at BIGINT NOT NULL, expires_at BIGINT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
  ip TEXT, device TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- Wallet: double-entry. accounts hold a cached balance, ledger_entries are the immutable truth.
CREATE TABLE IF NOT EXISTS accounts (
  name TEXT PRIMARY KEY,                            -- user:<id>:available | user:<id>:locked | platform:fee | platform:external | platform:sandbox_mint
  user_id TEXT,
  balance BIGINT NOT NULL DEFAULT 0,
  CHECK (balance >= 0 OR name LIKE 'platform:%')
);
CREATE TABLE IF NOT EXISTS ledger_transactions (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,             -- same key => same effect, applied exactly once
  kind TEXT NOT NULL,                               -- deposit|withdrawal|stake_lock|payout|refund|fee|sandbox_credit
  user_id TEXT, match_id TEXT, ref TEXT,
  created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger_entries (
  id {AUTOID},
  tx_id TEXT NOT NULL REFERENCES ledger_transactions(id),
  account TEXT NOT NULL REFERENCES accounts(name),
  amount BIGINT NOT NULL,                           -- signed; entries of one tx sum to 0
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entries_account ON ledger_entries(account, id);
CREATE INDEX IF NOT EXISTS idx_entries_tx ON ledger_entries(tx_id);
CREATE INDEX IF NOT EXISTS idx_ltx_user ON ledger_transactions(user_id, created_at);

CREATE TABLE IF NOT EXISTS payment_intents (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, direction TEXT NOT NULL,   -- deposit|withdrawal
  amount BIGINT NOT NULL, provider TEXT NOT NULL, provider_ref TEXT,
  status TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_intent_provider_ref ON payment_intents(provider, provider_ref);

CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY,
  tier BIGINT NOT NULL,                             -- stake per player (santim); 0 = practice
  fee_bps INTEGER NOT NULL,
  p1 TEXT NOT NULL, p2 TEXT,                        -- p2 NULL => practice vs server bot
  status TEXT NOT NULL,                             -- locked|playing|settled|refunded|review|void
  winner TEXT, end_reason TEXT,
  e1 INTEGER NOT NULL DEFAULT 0, e2 INTEGER NOT NULL DEFAULT 0,
  prize BIGINT NOT NULL DEFAULT 0, fee BIGINT NOT NULL DEFAULT 0,
  seed TEXT NOT NULL, risk_score INTEGER NOT NULL DEFAULT 0, risk_flags TEXT NOT NULL DEFAULT '[]',
  ip1 TEXT, ip2 TEXT,
  created_at BIGINT NOT NULL, started_at BIGINT, ended_at BIGINT, settled_at BIGINT
);
CREATE INDEX IF NOT EXISTS idx_matches_p1 ON matches(p1, created_at);
CREATE INDEX IF NOT EXISTS idx_matches_p2 ON matches(p2, created_at);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);

CREATE TABLE IF NOT EXISTS risk_events (
  id {AUTOID}, match_id TEXT, user_id TEXT, kind TEXT NOT NULL, score INTEGER NOT NULL, detail TEXT, created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_limits (
  user_id TEXT PRIMARY KEY, daily_stake BIGINT NOT NULL, daily_loss BIGINT NOT NULL,
  daily_deposit BIGINT NOT NULL, daily_minutes INTEGER NOT NULL,
  pending_json TEXT, pending_effective_at BIGINT, updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS self_exclusions (
  id {AUTOID}, user_id TEXT NOT NULL, until BIGINT NOT NULL, created_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS play_sessions (
  id {AUTOID}, user_id TEXT NOT NULL, match_id TEXT NOT NULL, seconds INTEGER NOT NULL, created_at BIGINT NOT NULL
);
-- Tamper-evident audit trail: each row hashes the previous row's hash.
CREATE TABLE IF NOT EXISTS audit_log (
  seq {AUTOID}, ts BIGINT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, entity TEXT, details TEXT NOT NULL,
  prev_hash TEXT NOT NULL, hash TEXT NOT NULL
);
