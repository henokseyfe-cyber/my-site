import asyncio, base64, json, os, struct, sys, urllib.request
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bladerush.config import Config
from bladerush.db import Database
import dataclasses


def make_cfg(**over):
    os.environ.setdefault("ADMIN_TOKEN", "x" * 40)
    cfg = Config.from_env()
    return dataclasses.replace(cfg, **over)


class WSClient:
    def __init__(self, r, w): self.r, self.w = r, w

    @classmethod
    async def connect(cls, port, token, build="test"):
        r, w = await asyncio.open_connection("127.0.0.1", port)
        key = base64.b64encode(os.urandom(16)).decode()
        w.write(f"GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n".encode())
        await w.drain(); await r.readuntil(b"\r\n\r\n")
        c = cls(r, w)
        if token: await c.send({"t": "auth", "v": 1, "token": token, "build": build})
        return c

    async def send(self, obj):
        p = json.dumps(obj).encode(); n = len(p); mask = os.urandom(4)
        head = bytes([0x81]) + (bytes([0x80 | n]) if n < 126 else b"\xfe" + struct.pack(">H", n)) + mask
        self.w.write(head + bytes(b ^ mask[i % 4] for i, b in enumerate(p))); await self.w.drain()

    async def recv(self, timeout=5):
        b = await asyncio.wait_for(self.r.readexactly(2), timeout); op = b[0] & 0xF; n = b[1] & 0x7F
        if n == 126: n = struct.unpack(">H", await self.r.readexactly(2))[0]
        elif n == 127: n = struct.unpack(">Q", await self.r.readexactly(8))[0]
        data = await self.r.readexactly(n)
        if op == 8: return {"t": "_closed", "code": struct.unpack(">H", data[:2])[0] if len(data) >= 2 else 0}
        return json.loads(data)

    async def until(self, t, timeout=10):
        end = asyncio.get_event_loop().time() + timeout
        while True:
            m = await self.recv(max(0.05, end - asyncio.get_event_loop().time()))
            if m["t"] == t or m["t"] == "_closed": return m

    def close(self): self.w.close()


def http(port, method, path, body=None, token=None, headers=None):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", method=method, data=json.dumps(body).encode() if body is not None else None)
    req.add_header("Content-Type", "application/json")
    if token: req.add_header("Authorization", "Bearer " + token)
    for k, v in (headers or {}).items(): req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=10) as r: return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
