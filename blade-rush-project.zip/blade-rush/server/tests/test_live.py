"""End-to-end: real server on a real socket, real WebSocket clients, real SQLite ledger."""
import asyncio, math, unittest, time
from helpers import make_cfg, WSClient, http
from bladerush.db import Database
from bladerush.main import serve
from bladerush.services import wallet, audit

PORT = 18765


async def signup(name, port=PORT):
    return await asyncio.to_thread(http, port, "POST", "/api/auth/register",
                                   {"username": name, "password": "password123", "dob": "1990-05-05", "country": "ET", "accept_terms": True})


class Live(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        global PORT
        PORT += 1; self.port = PORT
        self.cfg = make_cfg(port=self.port, host="127.0.0.1", database_url="sqlite:///:memory:", countdown_s=1, match_seconds=6,
                            lobby_timeout_s=3, reconnect_grace_s=1.5, rematch_window_s=4, sandbox_bot_fill_s=1.0, block_same_ip=False, target_energy=100)
        self.db = Database(self.cfg.database_url)
        ev = asyncio.Event(); self.srv = asyncio.create_task(serve(self.cfg, self.db, ev)); await ev.wait()

    async def asyncTearDown(self):
        self.srv.cancel()
        try: await self.srv
        except BaseException: pass

    def bal(self, uid):
        with self.db.tx() as c: return wallet.balances(c, uid)

    async def player(self, name):
        s, r = await signup(name, self.port); self.assertEqual(s, 200, r)
        c = await WSClient.connect(self.port, r["token"]); h = await c.until("hello"); self.assertEqual(h["t"], "hello")
        return c, r["user_id"], r["token"]

    async def drive(self, c, seq0=1, secs=8, chase=False):
        """Send ~30 inputs/s until a result arrives."""
        seq = seq0; res = None; t_end = time.monotonic() + secs
        while time.monotonic() < t_end:
            await c.send({"t": "in", "seq": seq, "mx": math.cos(seq / 20), "my": math.sin(seq / 20), "a": seq % 12 == 0, "d": seq % 40 == 0, "ax": 1, "ay": 0}); seq += 1
            try:
                while True:
                    m = await c.recv(0.033)
                    if m["t"] == "result": return m
            except (asyncio.TimeoutError, asyncio.IncompleteReadError): pass
        return res

    async def test_01_two_players_full_flow_and_money(self):
        a, ua, _ = await self.player("alice"); b, ub, _ = await self.player("bobby")
        await a.send({"t": "queue", "tier": 5000}); await b.send({"t": "queue", "tier": 5000})
        fa = await a.until("match_found", 6); fb = await b.until("match_found", 6)
        self.assertEqual(fa["id"], fb["id"]); self.assertEqual({fa["you"], fb["you"]}, {0, 1})
        self.assertEqual((fa["pot"], fa["fee"], fa["prize"]), (10000, 1500, 8500))
        self.assertEqual(self.bal(ua), {"available": 45000, "locked": 5000})       # locked BEFORE play
        await a.send({"t": "ready"}); await b.send({"t": "ready"})
        cd = await a.until("countdown", 4); self.assertEqual(cd["n"], 1)
        await a.until("go", 4)
        ra, rb = await asyncio.gather(self.drive(a), self.drive(b))
        self.assertIsNotNone(ra); self.assertIsNotNone(rb)
        self.assertEqual(ra["reason"], "time"); self.assertEqual(ra["energy"], rb["energy"])
        with self.db.tx() as c:
            m = c.one("SELECT * FROM matches WHERE id=?", (fa["id"],)); self.assertIn(m["status"], ("settled", "refunded", "review"))
            self.assertTrue(wallet.reconcile(c)["ok"]); self.assertTrue(audit.verify(c)["ok"])
            total = c.scalar("SELECT SUM(balance) FROM accounts WHERE name LIKE 'user:%'") + c.scalar("SELECT balance FROM accounts WHERE name='platform:fee'")
            self.assertEqual(total, 2 * 50000)       # money conserved
        if ra["outcome"] != "draw" and not ra["held"]:
            w = ua if (ra["outcome"] == "win") == (fa["you"] == ra["you"]) else ub
            self.assertEqual(self.bal(w)["available"], 45000 + 8500)
        a.close(); b.close()

    async def test_02_input_validation_cannot_cheat(self):
        a, ua, _ = await self.player("alice"); await a.send({"t": "queue", "tier": 0})
        await a.until("match_found", 4); await a.send({"t": "ready"}); await a.until("go", 5)
        # impossible values: huge stick vector, NaN-ish, bool, garbage types; position/energy fields must be ignored
        for i, bad in enumerate([{"mx": 1e9, "my": 1e9}, {"mx": "x"}, {"mx": True}, {"seq": 5, "mx": 5, "my": 5, "energy": 999, "x": 0}, {"t": "evil"}]):
            await a.send({"t": "in", "seq": i + 1, **bad})
        await a.send({"t": "in", "seq": 3, "mx": 1, "my": 0})     # replayed/old seq
        s = None
        for _ in range(40):
            m = await a.recv(2)
            if m["t"] == "s": s = m
            if s and s["tk"] > 20: break
        me = s["p"][0]
        self.assertLessEqual(math.hypot(me[0] - 150, me[1] - 400), 250 * (s["tk"] / 30) + 1)  # never faster than speed limit
        self.assertEqual(me[4] <= 6, True)                                                     # cannot self-award energy
        a.close()

    async def test_03_disconnect_forfeit_and_reconnect(self):
        a, ua, ta = await self.player("alice"); b, ub, tb = await self.player("bobby")
        await a.send({"t": "queue", "tier": 2500}); await b.send({"t": "queue", "tier": 2500})
        await a.until("match_found", 6); await b.until("match_found", 6)
        await a.send({"t": "ready"}); await b.send({"t": "ready"}); await a.until("go", 4)
        a.close(); await asyncio.sleep(0.4)
        a2 = await WSClient.connect(self.port, ta); await a2.until("hello")        # reconnect inside grace
        p = await a2.until("match_found", 3); self.assertTrue(p.get("resume"))
        a2.close(); await asyncio.sleep(0.2)                                        # drop again and stay away
        rb = await b.until("result", 8)
        self.assertEqual(rb["outcome"], "win"); self.assertEqual(rb["reason"], "forfeit")
        self.assertEqual(self.bal(ub)["available"], 50000 - 2500 + 4250)
        self.assertEqual(self.bal(ua), {"available": 50000 - 2500, "locked": 0})
        b.close()

    async def test_04_lobby_timeout_refunds(self):
        a, ua, _ = await self.player("alice"); b, ub, _ = await self.player("bobby")
        await a.send({"t": "queue", "tier": 1000}); await b.send({"t": "queue", "tier": 1000})
        await a.until("match_found", 6); await b.until("match_found", 6)
        await a.send({"t": "ready"})                           # b never readies
        m = await a.until("cancelled", 6); self.assertEqual(m["t"], "cancelled")
        self.assertEqual(self.bal(ua), {"available": 50000, "locked": 0}); self.assertEqual(self.bal(ub), {"available": 50000, "locked": 0})
        a.close(); b.close()

    async def test_05_insufficient_balance_rejected_and_unauth(self):
        a, ua, _ = await self.player("alice")
        await a.send({"t": "queue", "tier": 25000}); await a.until("queued", 2)     # 250 Birr, has 500 -> fine
        await a.send({"t": "cancel"}); await a.until("queue_cancelled", 2)
        with self.db.tx() as c: wallet.post(c, "drain", "withdrawal", [(wallet.avail(ua), -49000), (wallet.EXTERNAL, 49000)])
        await a.send({"t": "queue", "tier": 5000}); e = await a.until("error", 3); self.assertEqual(e["code"], "insufficient_funds")
        bad = await WSClient.connect(self.port, "garbage"); m = await bad.until("error", 3); self.assertEqual(m["code"], "unauthorized")
        a.close()

    async def test_06_practice_bot_and_sandbox_house_bot_rematch(self):
        a, ua, _ = await self.player("alice")
        await a.send({"t": "queue", "tier": 1000}); await a.until("queued", 2)
        f = await a.until("match_found", 8); self.assertTrue(f["opp"]["bot"])
        await a.send({"t": "ready"}); await a.until("go", 4)
        r = await self.drive(a); self.assertIsNotNone(r)
        await a.send({"t": "rematch"})
        f2 = await a.until("match_found", 8); self.assertNotEqual(f["id"], f2["id"])          # fresh unique match id
        await a.send({"t": "ready"}); await a.until("go", 4)
        r2 = await self.drive(a); self.assertIsNotNone(r2)
        with self.db.tx() as c: self.assertTrue(wallet.reconcile(c)["ok"])
        a.close()

    async def test_07_rest_api(self):
        s, r = await signup("dave", self.port); tok = r["token"]
        s, me = await asyncio.to_thread(http, self.port, "GET", "/api/me", None, tok); self.assertEqual(me["balance"]["available"], 50000)
        k = {"amount": 1000, "idempotency_key": "abcdefgh12"}
        s1, d1 = await asyncio.to_thread(http, self.port, "POST", "/api/wallet/deposit", k, tok)
        s2, d2 = await asyncio.to_thread(http, self.port, "POST", "/api/wallet/deposit", k, tok)
        self.assertEqual((s1, s2, d1["id"] == d2["id"]), (200, 200, True))
        s, me = await asyncio.to_thread(http, self.port, "GET", "/api/me", None, tok); self.assertEqual(me["balance"]["available"], 51000)  # credited once
        s, _ = await asyncio.to_thread(http, self.port, "POST", "/api/wallet/withdraw", {"amount": 100, "idempotency_key": "wd-key-123"}, tok); self.assertEqual(s, 403)  # sandbox
        s, _ = await asyncio.to_thread(http, self.port, "GET", "/api/me"); self.assertEqual(s, 401)
        s, _ = await asyncio.to_thread(http, self.port, "GET", "/admin/reconcile", None, None, {"x-admin-token": "wrong"}); self.assertEqual(s, 403)
        s, rec = await asyncio.to_thread(http, self.port, "GET", "/admin/reconcile", None, None, {"x-admin-token": "x" * 40}); self.assertTrue(rec["ledger"]["ok"] and rec["audit"]["ok"])
        s, _ = await asyncio.to_thread(http, self.port, "POST", "/api/wallet/deposit", {"amount": -5, "idempotency_key": "abcdefgh13"}, tok); self.assertEqual(s, 400)
        import urllib.request
        def raw(path):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5) as r: return r.status, r.read()
            except urllib.error.HTTPError as e: return e.code, e.read()
        for evil in ("/../../etc/passwd", "/..%2f..%2fetc/passwd", "/js/../../../../etc/passwd"):
            st, body = await asyncio.to_thread(raw, evil); self.assertNotIn(b"root:", body)       # traversal never leaves web root
        st, body = await asyncio.to_thread(raw, "/"); self.assertEqual(st, 200); self.assertIn(b"Blade Rush", body)
        st, body = await asyncio.to_thread(raw, "/js/game.js"); self.assertEqual(st, 200)
        s, r2 = await asyncio.to_thread(http, self.port, "POST", "/api/auth/register", {"username": "kid", "password": "password123", "dob": "2020-01-01", "country": "ET", "accept_terms": True}); self.assertEqual(r2["error"], "underage")


if __name__ == "__main__":
    unittest.main()
