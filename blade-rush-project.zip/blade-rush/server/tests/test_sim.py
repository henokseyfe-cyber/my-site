import math, unittest
from bladerush.game.sim import Sim, make_rules, step_player, Player, ORB_BIG
from bladerush.game.bot import Bot

IDLE = {"mx": 0, "my": 0}


class SimTests(unittest.TestCase):
    def setUp(self): self.R = make_rules(); self.s = Sim("seed", self.R)

    def test_speed_cap_even_with_giant_input(self):
        s = self.s
        for _ in range(30): s.step([{"mx": 99, "my": 0}, IDLE])
        self.assertLessEqual(math.hypot(s.players[0].x - 150, s.players[0].y - 400), 250 * 1.0 + 1)   # 1s at 250/s (minus collision)

    def test_walls_and_pillars_block(self):
        p = Player(20.0, 20.0, 1, 0)
        for _ in range(200): step_player(p, {"mx": -1, "my": -1}, self.R)
        self.assertGreaterEqual(p.x, 18); self.assertGreaterEqual(p.y, 18)
        q = Player(150.0, 250.0, 1, 0)
        for _ in range(120): step_player(q, {"mx": 1, "my": 0}, self.R)
        self.assertGreater(math.hypot(q.x - 250, q.y - 250), 34 + 18 - 0.01)

    def test_hit_steals_energy_and_stuns(self):
        s = self.s; a, b = s.players
        a.x, a.y, b.x, b.y = 300.0, 400.0, 350.0, 400.0; b.energy = 20; s.orbs = []
        for t in range(8): s.step([{"mx": 0, "my": 0, "a": t == 0, "ax": 1, "ay": 0}, IDLE])
        self.assertEqual((a.energy, b.energy), (8, 12)); self.assertGreater(b.stats["taken"], 0)

    def test_dash_dodges_attack(self):
        s = self.s; a, b = s.players
        a.x, a.y, b.x, b.y = 300.0, 400.0, 350.0, 400.0; b.energy = 20; s.orbs = []
        for t in range(8): s.step([{"a": t == 0, "ax": 1, "ay": 0}, {"d": t == 3, "mx": 0, "my": 1}])
        self.assertEqual(b.energy, 20); self.assertEqual(b.stats["dodges"], 1)

    def test_shield_blocks_once(self):
        s = self.s; a, b = s.players
        a.x, a.y, b.x, b.y = 300.0, 400.0, 350.0, 400.0; b.energy = 20; b.pw = 2; s.orbs = []
        s.step([IDLE, {"p": True}])
        for t in range(8): s.step([{"a": t == 0, "ax": 1, "ay": 0}, IDLE])
        self.assertEqual(b.energy, 20); self.assertEqual(b.stats["blocks"], 1)

    def test_out_of_range_misses(self):
        s = self.s; a, b = s.players
        a.x, a.y, b.x, b.y = 200.0, 400.0, 400.0, 400.0; b.energy = 20; s.orbs = []
        for t in range(8): s.step([{"a": t == 0, "ax": 1, "ay": 0}, IDLE])
        self.assertEqual(b.energy, 20)

    def test_win_at_target_and_time(self):
        s = self.s; s.players[0].energy = 99; s.orbs = [[1, s.players[0].x, s.players[0].y, 0]]
        s.step([IDLE, IDLE]); self.assertTrue(s.finished and s.winner == 0 and s.reason == "target")
        s2 = Sim("t", self.R); s2.tick = self.R["match_ticks"] - 1; s2.players[1].energy = 5; s2.step([IDLE, IDLE])
        self.assertTrue(s2.finished and s2.winner == 1 and s2.reason == "time")
        s3 = Sim("t", self.R); s3.tick = self.R["match_ticks"] - 1; s3.step([IDLE, IDLE]); self.assertIsNone(s3.winner)

    def test_orb_spawns_are_mirrored_fair(self):
        s = Sim("abc", self.R)
        for _ in range(900): s.step([IDLE, IDLE])
        pos = {(o[1], o[2], o[3]) for o in s.orbs}
        for x, y, k in pos: self.assertIn((round(800 - x, 1), round(800 - y, 1), k), pos | {(round(800 - x, 1) + d, round(800 - y, 1), k) for d in (-0.1, 0.1)})

    def test_deterministic_given_seed(self):
        def run():
            s = Sim("same", self.R); b0, b1 = Bot("a"), Bot("b")
            for _ in range(600): s.step([b0.think(s, 0), b1.think(s, 1)])
            return [round(p.x, 3) for p in s.players], [p.energy for p in s.players]
        self.assertEqual(run(), run())

    def test_bot_match_terminates_with_activity(self):
        s = Sim("bots", self.R); b0, b1 = Bot("a", .7), Bot("b", .5)
        while not s.finished: s.step([b0.think(s, 0), b1.think(s, 1)])
        self.assertLessEqual(s.tick, self.R["match_ticks"]); self.assertGreater(s.players[0].stats["orbs"] + s.players[1].stats["orbs"], 5)

    def test_forfeit(self):
        self.s.forfeit(0); self.assertEqual((self.s.winner, self.s.reason), (1, "forfeit"))


if __name__ == "__main__":
    unittest.main()
