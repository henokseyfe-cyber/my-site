import threading, unittest
from helpers import make_cfg
from bladerush.db import Database, IntegrityError
from bladerush.services import wallet, matches, audit, auth, compliance, risk
from bladerush.services.matches import MatchError
from bladerush.game.sim import Sim, make_rules


def mkdb():
    d = Database("sqlite:///:memory:"); d.migrate(); return d


def user(c, cfg, name, dob="1990-01-01", cc="ET"):
    r = auth.register(c, cfg, {"username": name, "password": "password123", "dob": dob, "country": cc, "accept_terms": True}, "1.1.1." + str(len(name)))
    return r["user_id"]


class WalletTests(unittest.TestCase):
    def setUp(self):
        self.cfg = make_cfg(); self.db = mkdb()
        with self.db.tx() as c:
            self.a = user(c, self.cfg, "alice"); self.b = user(c, self.cfg, "bobby")

    def bal(self, u):
        with self.db.tx() as c: return wallet.balances(c, u)

    def test_split_pot_15pct(self):
        self.assertEqual(wallet.split_pot(1000, 1500), (2000, 300, 1700))
        self.assertEqual(wallet.split_pot(25_00, 1500), (50_00, 7_50, 42_50))
        self.assertEqual(wallet.split_pot(1001, 1500), (2002, 300, 1702))   # fee rounds down

    def test_settlement_conserves_money(self):
        total0 = 0
        with self.db.tx() as c:
            info = matches.create_match(c, self.cfg, 5000, self.a, self.b)
            self.assertEqual(wallet.balances(c, self.a), {"available": 500_00 - 5000, "locked": 5000})
            res = matches.settle(c, self.cfg, info["id"], {"winner": 0, "reason": "target", "e1": 100, "e2": 40, "seconds": 50}, {"score": 0, "flags": []})
        self.assertEqual(res["prize"], 8500); self.assertEqual(res["fee"], 1500)
        self.assertEqual(self.bal(self.a), {"available": 500_00 - 5000 + 8500, "locked": 0})
        self.assertEqual(self.bal(self.b), {"available": 500_00 - 5000, "locked": 0})
        with self.db.tx() as c:
            self.assertEqual(c.scalar("SELECT balance FROM accounts WHERE name=?", (wallet.FEE,)), 1500)
            self.assertTrue(wallet.reconcile(c)["ok"])

    def test_double_settle_pays_once(self):
        with self.db.tx() as c:
            info = matches.create_match(c, self.cfg, 1000, self.a, self.b)
            r = {"winner": 1, "reason": "time", "e1": 10, "e2": 20, "seconds": 90}
            for _ in range(5): matches.settle(c, self.cfg, info["id"], r, {"score": 0, "flags": []})
            self.assertEqual(c.scalar("SELECT COUNT(*) FROM ledger_transactions WHERE kind='payout'"), 1)
        self.assertEqual(self.bal(self.b)["available"], 500_00 - 1000 + 1700)

    def test_concurrent_settle_threads(self):
        with self.db.tx() as c: info = matches.create_match(c, self.cfg, 1000, self.a, self.b)
        errs = []
        def go():
            try:
                with self.db.tx() as c: matches.settle(c, self.cfg, info["id"], {"winner": 0, "reason": "t", "e1": 1, "e2": 0, "seconds": 5}, {"score": 0, "flags": []})
            except Exception as e: errs.append(e)
        ts = [threading.Thread(target=go) for _ in range(8)]; [t.start() for t in ts]; [t.join() for t in ts]
        self.assertFalse(errs)
        with self.db.tx() as c: self.assertEqual(c.scalar("SELECT COUNT(*) FROM ledger_transactions WHERE kind='payout'"), 1)
        self.assertEqual(self.bal(self.a)["available"], 500_00 - 1000 + 1700)

    def test_draw_refunds_both(self):
        with self.db.tx() as c:
            info = matches.create_match(c, self.cfg, 2500, self.a, self.b)
            matches.settle(c, self.cfg, info["id"], {"winner": None, "reason": "time", "e1": 30, "e2": 30, "seconds": 90}, {"score": 0, "flags": []})
        self.assertEqual(self.bal(self.a), {"available": 500_00, "locked": 0}); self.assertEqual(self.bal(self.b), {"available": 500_00, "locked": 0})

    def test_insufficient_funds_rolls_back_atomically(self):
        with self.db.tx() as c: c_id = user(c, self.cfg, "carol")
        with self.db.tx() as c: wallet.post(c, "drain", "withdrawal", [(wallet.avail(c_id), -490_00), (wallet.EXTERNAL, 490_00)])
        with self.assertRaises(MatchError):
            with self.db.tx() as c: matches.create_match(c, self.cfg, 5000, self.a, c_id)   # a locked first, c fails => all rolled back
        self.assertEqual(self.bal(self.a), {"available": 500_00, "locked": 0})
        with self.db.tx() as c: self.assertEqual(c.scalar("SELECT COUNT(*) FROM matches"), 0)

    def test_idempotent_post_and_no_negative(self):
        with self.db.tx() as c:
            t1, new1 = wallet.deposit(c, self.a, 1000, "dep-1"); t2, new2 = wallet.deposit(c, self.a, 1000, "dep-1")
        self.assertEqual(t1, t2); self.assertTrue(new1 and not new2)
        self.assertEqual(self.bal(self.a)["available"], 500_00 + 1000)
        with self.assertRaises(wallet.InsufficientFunds):
            with self.db.tx() as c: wallet.withdrawal_reserve(c, self.a, 999_999_00, "wd-big")

    def test_unbalanced_rejected(self):
        with self.assertRaises(wallet.WalletError):
            with self.db.tx() as c: wallet.post(c, "bad", "x", [(wallet.avail(self.a), 5)])

    def test_ledger_immutable(self):
        with self.db.tx() as c: wallet.deposit(c, self.a, 100, "k1")
        for sql in ("UPDATE ledger_entries SET amount=999", "DELETE FROM ledger_entries", "DELETE FROM ledger_transactions", "UPDATE audit_log SET actor='x'"):
            with self.assertRaises(Exception):
                with self.db.tx() as c: c.execute(sql)

    def test_audit_chain_detects_tamper(self):
        with self.db.tx() as c: self.assertTrue(audit.verify(c)["ok"])
        self.db.raw.execute("DROP TRIGGER audit_no_update")
        self.db.raw.execute("UPDATE audit_log SET details='{\"evil\":1}' WHERE seq=1")
        with self.db.tx() as c: self.assertFalse(audit.verify(c)["ok"])

    def test_high_risk_held_then_admin_pays_once(self):
        with self.db.tx() as c:
            info = matches.create_match(c, self.cfg, 1000, self.a, self.b)
            r = matches.settle(c, self.cfg, info["id"], {"winner": 0, "reason": "target", "e1": 100, "e2": 0, "seconds": 40}, {"score": 150, "flags": [{"kind": "same_ip", "pts": 150, "who": None}]})
            self.assertEqual(r["status"], "review")
            self.assertEqual(wallet.balances(c, self.a)["available"], 500_00 - 1000)   # nothing paid yet
            matches.admin_resolve(c, self.cfg, info["id"], "pay", "root")
            with self.assertRaises(MatchError): matches.admin_resolve(c, self.cfg, info["id"], "refund", "root")
            self.assertEqual(c.scalar("SELECT COUNT(*) FROM ledger_transactions WHERE kind='payout'"), 1)

    def test_crash_recovery_refunds(self):
        with self.db.tx() as c:
            matches.create_match(c, self.cfg, 5000, self.a, self.b)
            self.assertEqual(len(matches.recover_after_crash(c)), 1)
            self.assertEqual(wallet.balances(c, self.a), {"available": 500_00, "locked": 0})
            self.assertEqual(matches.recover_after_crash(c), [])

    def test_match_ids_unique(self):
        with self.db.tx() as c:
            ids = {matches.create_match(c, self.cfg, 0, self.a, None)["id"] for _ in range(200)}
        self.assertEqual(len(ids), 200)


class ComplianceTests(unittest.TestCase):
    def setUp(self):
        self.cfg = make_cfg(); self.db = mkdb()
        with self.db.tx() as c: self.a = user(c, self.cfg, "alice"); self.b = user(c, self.cfg, "bobby")

    def test_underage_cannot_register(self):
        with self.assertRaises(auth.AuthError):
            with self.db.tx() as c:
                import datetime; y = datetime.date.today().year - 17
                auth.register(c, self.cfg, {"username": "kiddo", "password": "password123", "dob": f"{y}-06-01", "country": "ET", "accept_terms": True}, "9.9.9.9")

    def test_real_mode_requires_everything(self):
        from bladerush.config import Config, ConfigError
        import os
        env = dict(os.environ)
        try:
            os.environ["STAKE_MODE"] = "real"
            with self.assertRaises(ConfigError): Config.from_env()
            os.environ.update(APP_ENV="production", ADMIN_TOKEN="a" * 40, TOKEN_PEPPER="b" * 40)
            with self.assertRaises(ConfigError): Config.from_env()      # no licence
            os.environ["GAMING_LICENSE_REFERENCE"] = "LIC-1"; os.environ["PAYMENT_PROVIDER"] = "hmac"; os.environ["REAL_MONEY_COUNTRIES"] = "ET"
            os.environ["PAYMENT_WEBHOOK_SECRET"] = "s" * 32; os.environ["KYC_PROVIDER"] = "manual"
            self.assertEqual(Config.from_env().stake_mode, "real")
        finally:
            os.environ.clear(); os.environ.update(env)

    def test_real_mode_kyc_and_jurisdiction(self):
        cfg = make_cfg(stake_mode="real", require_kyc=True, real_money_countries=("ET",), env="production")
        with self.db.tx() as c:
            with self.assertRaises(compliance.Blocked) as e: compliance.check_can_play(c, cfg, self.a, 1000)
            self.assertEqual(e.exception.code, "kyc_required")
            c.execute("UPDATE users SET kyc_status='verified'"); compliance.check_can_play(c, cfg, self.a, 1000)
            c.execute("UPDATE users SET country='US' WHERE id=?", (self.a,))
            with self.assertRaises(compliance.Blocked) as e: compliance.check_can_play(c, cfg, self.a, 1000)
            self.assertEqual(e.exception.code, "jurisdiction")

    def test_limits_decrease_now_increase_later_and_exclusion(self):
        with self.db.tx() as c:
            compliance.check_can_play(c, self.cfg, self.a, 25000)
            compliance.set_limits(c, self.cfg, self.a, {"daily_stake": 20000})
            with self.assertRaises(compliance.Blocked) as e: compliance.check_can_play(c, self.cfg, self.a, 25000)
            self.assertEqual(e.exception.code, "limit_stake")
            l = compliance.set_limits(c, self.cfg, self.a, {"daily_stake": 900000})        # increase: cooling-off
            self.assertEqual(l["daily_stake"], 20000); self.assertIsNotNone(l["pending_json"])
            compliance.self_exclude(c, self.a, 7)
            with self.assertRaises(compliance.Blocked) as e: compliance.check_can_play(c, self.cfg, self.a, 1000)
            self.assertEqual(e.exception.code, "self_excluded")
            compliance.check_can_play(c, self.cfg, self.a, 0)       # practice still ok

    def test_bots_forbidden_in_real_mode(self):
        cfg = make_cfg(stake_mode="real")
        with self.assertRaises(MatchError):
            with self.db.tx() as c: matches.create_match(c, cfg, 1000, self.a, matches.BOT_ID)


class RiskTests(unittest.TestCase):
    def test_flags(self):
        R = make_rules(); s = Sim("x", R); s.tick = 2000; s.finished = True; s.winner = 0; s.reason = "target"
        s.players[1].stats.update(swings=0, dashes=0, idle=1900, dist=10.0)
        g = [risk.LiveGuard(), risk.LiveGuard()]
        out = risk.analyse_match(s, {"tier": 1000, "ips": ["1.1.1.1", "1.1.1.1"], "guards": g, "pair_recent": 9, "pair_limit": 6, "bots": [False, False]})
        kinds = {f["kind"] for f in out["flags"]}
        self.assertTrue({"same_ip", "repeat_pairing", "dumping"} <= kinds); self.assertGreaterEqual(out["score"], 100)

    def test_reaction_bot_signature(self):
        R = make_rules(); s = Sim("x", R); s.tick = 2000; s.finished = True; s.winner = 0; s.reason = "time"
        s.log["swings"][1] = list(range(100, 1100, 100)); s.log["dashes"][0] = [t + 1 for t in s.log["swings"][1]]
        out = risk.analyse_match(s, {"tier": 1000, "ips": ["1", "2"], "guards": [risk.LiveGuard(), risk.LiveGuard()], "bots": [False, False]})
        self.assertIn("superhuman_reaction", {f["kind"] for f in out["flags"]})

    def test_live_guard(self):
        g = risk.LiveGuard()
        self.assertTrue(g.check_seq(1)); self.assertFalse(g.check_seq(1)); self.assertFalse(g.check_seq(99999)); self.assertFalse(g.check_seq("1"))
        self.assertGreater(g.score, 0)


if __name__ == "__main__":
    unittest.main()
