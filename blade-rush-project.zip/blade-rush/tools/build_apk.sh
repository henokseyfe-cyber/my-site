#!/usr/bin/env bash
# Build the Android APK.  Requires: JDK 17, Android SDK (platforms;android-34, build-tools;34.0.0), Gradle 8.7+.
#   SERVER_URL=http://192.168.1.20:8080 ./tools/build_apk.sh          -> debug APK (cleartext http allowed, for LAN testing)
#   SERVER_URL=https://play.example.com RELEASE=1 BR_KEYSTORE=... BR_KEYSTORE_PASSWORD=... BR_KEY_ALIAS=... BR_KEY_PASSWORD=... ./tools/build_apk.sh
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SERVER_URL:=}"
CFG=client/web/config.js
cp "$CFG" "$CFG.bak"; trap 'mv "$CFG.bak" "$CFG"' EXIT
cat > "$CFG" <<JS
window.BR_DEFAULT_SERVER = "${SERVER_URL}";
window.BR_BUILD = "android-1.0.0";
JS
cd android
if [ -x ./gradlew ]; then G=./gradlew; else G=gradle; fi
if [ "${RELEASE:-0}" = "1" ]; then
  [[ "$SERVER_URL" == https://* ]] || { echo "release builds must use an https:// SERVER_URL"; exit 1; }
  $G --no-daemon assembleRelease; ls -l app/build/outputs/apk/release/
else
  $G --no-daemon assembleDebug;   ls -l app/build/outputs/apk/debug/
fi
