#!/usr/bin/env bash
# Start the whole stack locally (SQLite, sandbox mode).  Phone on the same Wi-Fi:  http://<this-PC-LAN-IP>:8080
cd "$(dirname "$0")/../server"
export PORT="${PORT:-8080}" DATABASE_URL="${DATABASE_URL:-sqlite:///bladerush.db}"
echo "LAN addresses:"; (hostname -I 2>/dev/null || ipconfig getifaddr en0 2>/dev/null) | tr ' ' '\n' | sed 's#^#  http://#; s#$#:'"$PORT"'#'
exec python3 -m bladerush.main
